#!/usr/bin/env python3
"""Sequential four-question extension plus a fresh ten-question replication."""
import argparse
import csv
import fcntl
import hashlib
import json
import os
import time
from datetime import datetime
from pathlib import Path

import daily_ten_tasks as tasks
import pi_daily_readonly_benchmark as engine
import reasoning_benchmark as reasoning
from qwen38_mtp_benchmark import Client, model_url

# Reuse the exact audited launch, proxy, sampling and isolation code in memory.
# Neither the original source files nor its completed report are modified.
engine.tasks = tasks
HERE = Path(__file__).resolve().parent


def save(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n')
    temporary.replace(path)


def rows(path):
    return engine.rows(path)


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def stats(data):
    inp, out = sum(r['input_eval_s'] for r in data), sum(r['output_eval_s'] for r in data)
    return {'attempted': len(data), 'verified': sum(r['verified'] for r in data),
            'full': sum(r['passed'] for r in data),
            'input_tps': sum(r['computed_input_tokens'] for r in data)/inp if inp else None,
            'output_tps': sum(r['output_tokens'] for r in data)/out if out else None,
            'mean_e2e_s': sum(r['e2e_s'] for r in data)/len(data) if data else None}


def export(master):
    manifest = json.loads((master/'manifest.json').read_text())
    baseline = rows(Path(manifest['baseline_root'])/'raw-results.jsonl')
    added, repeat = rows(master/'added/raw-results.jsonl'), rows(master/'repeat/raw-results.jsonl')
    expanded = baseline+added
    ids = [m['id'] for m in manifest['models']]
    summaries, comparisons = [], []
    for model in ids:
        old = [r for r in baseline if r['model'] == model]
        first = [r for r in expanded if r['model'] == model]
        second = [r for r in repeat if r['model'] == model]
        second_old = [r for r in second if r['task'] in {t['id'] for t in tasks.original.TASKS}]
        record = {'model': model}
        for prefix, values in [('original6', old), ('expanded10', first), ('repeat10', second), ('repeat6', second_old)]:
            record.update({prefix+'_'+key: value for key, value in stats(values).items()})
        first_map, second_map = {r['task']: r for r in first}, {r['task']: r for r in second}
        paired = []
        for task in tasks.TASKS:
            a, b = first_map.get(task['id']), second_map.get(task['id'])
            if not a or not b:
                continue
            source_same = a['expected'] == b['expected']
            item = {'model': model, 'task': task['id'], 'same_expected_reference': source_same,
                    'first_verified': a['verified'], 'repeat_verified': b['verified'],
                    'first_full': a['passed'], 'repeat_full': b['passed'],
                    'verified_agrees': a['verified'] == b['verified'], 'full_agrees': a['passed'] == b['passed'],
                    'first_e2e_s': a['e2e_s'], 'repeat_e2e_s': b['e2e_s'],
                    'e2e_ratio': b['e2e_s']/a['e2e_s'], 'first_directory': a['directory'], 'repeat_directory': b['directory']}
            comparisons.append(item)
            paired.append(item)
        record.update(paired=len(paired), full_agreement=sum(p['full_agrees'] for p in paired),
                      verified_agreement=sum(p['verified_agrees'] for p in paired),
                      changed_reference_pairs=sum(not p['same_expected_reference'] for p in paired),
                      full_flips_on_stable_reference=sum(not p['full_agrees'] and p['same_expected_reference'] for p in paired))
        old_pairs = [p for p in paired if p['task'] in {t['id'] for t in tasks.original.TASKS}]
        record.update(original6_paired=len(old_pairs), original6_full_agreement=sum(p['full_agrees'] for p in old_pairs),
                      original6_changed_reference_pairs=sum(not p['same_expected_reference'] for p in old_pairs))
        summaries.append(record)
    save(master/'summary.json', summaries)
    save(master/'paired-comparison.json', comparisons)
    datasets = [('summary.csv', summaries), ('paired-comparison.csv', comparisons)]
    outcomes = []
    for stage, data in [('original6', baseline), ('added4', added), ('repeat10', repeat)]:
        for r in data:
            outcomes.append({'stage': stage, 'model': r['model'], 'task': r['task'], 'verified': r['verified'],
                             'full': r['passed'], 'checks_passed': r['checks_passed'], 'checks_total': r['checks_total'],
                             'e2e_s': r['e2e_s'], 'input_tps': r['input_tps'], 'output_tps': r['output_tps'],
                             'error': r['error'], 'reference_hash': digest(r['expected']),
                             'expected_json': json.dumps(r['expected'], ensure_ascii=False),
                             'actual_json': json.dumps(r['answer'], ensure_ascii=False), 'directory': r['directory']})
    datasets.append(('task-outcomes.csv', outcomes))
    old = list(csv.DictReader((Path(manifest['baseline_root'])/'all-models-summary.csv').open()))
    combined = [{**r, **{k: v for k, v in next(s for s in summaries if s['model'] == r['model']).items() if k != 'model'}} for r in old]
    datasets.append(('all-models-summary.csv', combined))
    for name, data in datasets:
        if not data:
            continue
        temporary = master/(name+'.tmp')
        with temporary.open('w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=list(data[0]))
            writer.writeheader()
            writer.writerows(data)
        temporary.replace(master/name)
    fmt = lambda v: f'{v:.2f}' if v is not None else '—'
    report = ['# Ten daily questions and replication', '',
              f"Status: {manifest['status']}. New collection: {len(added)}/40 added-question trials and {len(repeat)}/100 fresh repeat trials.", '',
              'The expanded baseline keeps the original six scored results and adds four new questions. The repeat is a fresh run of all ten. Scores require correct source-grounded artifacts and actual required tool execution; full passes also require normal completion within 600 seconds and 12 model requests. Original results and failures remain unchanged.', '',
              '| Model | Original full /6 | Expanded verified /10 | Expanded full /10 | Repeat verified /10 | Repeat full /10 | Repeat input tok/s | Repeat output tok/s | Repeat mean E2E s |',
              '|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    for s in summaries:
        report.append(f"| {s['model']} | {s['original6_full']} | {s['expanded10_verified']} ({s['expanded10_attempted']} done) | {s['expanded10_full']} | {s['repeat10_verified']} ({s['repeat10_attempted']} done) | {s['repeat10_full']} | {fmt(s['repeat10_input_tps'])} | {fmt(s['repeat10_output_tps'])} | {fmt(s['repeat10_mean_e2e_s'])} |")
    report += ['', '## Original six compared with the fresh repeat', '',
               'This table compares the same six questions with the current six-question baseline. Performance means include failed tasks; partial repeat rows are labeled by their collected count.', '',
               '| Model | Original verified/full /6 | Repeat verified/full | Full outcomes agree | Changed references | Input tok/s original → repeat | Output tok/s original → repeat | Mean E2E s original → repeat |',
               '|---|---:|---:|---:|---:|---:|---:|---:|']
    for s in summaries:
        report.append(f"| {s['model']} | {s['original6_verified']}/{s['original6_full']} | {s['repeat6_verified']}/{s['repeat6_full']} ({s['repeat6_attempted']} done) | {s['original6_full_agreement']}/{s['original6_paired']} | {s['original6_changed_reference_pairs']} | {fmt(s['original6_input_tps'])} → {fmt(s['repeat6_input_tps'])} | {fmt(s['original6_output_tps'])} → {fmt(s['repeat6_output_tps'])} | {fmt(s['original6_mean_e2e_s'])} → {fmt(s['repeat6_mean_e2e_s'])} |")
    report += ['', '## Reproducibility', '',
               'Matched question prompts, original six CLI guides, seeds, native sampling/thinking budgets, limits and sandbox controls are preserved. Models run one at a time; each stage/model starts after idle unload/reload and the same warmup. Native disk/prefix caching is left at the existing server settings. E2E excludes loading, warmup and grading, includes failures and repairs; rates are native token-weighted uncached-input/output measurements.', '',
               'Live Google and home sources can change. Each trial is graded from its own immutable read receipts. The paired CSV marks whether expected reference values changed; a score flip with changed source data is not evidence of sampling instability alone. Two observations provide a reproducibility check, not a high-confidence reliability estimate.', '',
               '| Model | Full outcome agrees / paired | Verified agrees | Changed references | Full flips with stable reference |',
               '|---|---:|---:|---:|---:|']
    for s in summaries:
        report.append(f"| {s['model']} | {s['full_agreement']}/{s['paired']} | {s['verified_agreement']}/{s['paired']} | {s['changed_reference_pairs']} | {s['full_flips_on_stable_reference']} |")
    report += ['', '## Read-only boundary', '',
               'Every model tool process and child runs in the original macOS default-deny Seatbelt boundary, writing only its disposable work folder. No new network/service-control capability is added. The same broker exposes only Google GET methods/public schemas and sanitized stored Home Assistant/Frigate reads. Log analysis uses a frozen credential-redacted snapshot of the actual local file. Backup planning never copies, moves or deletes source files. The trusted grader never executes model programs.', '',
               '[Exact ten prompts and guides](questions.md) · [Per-task raw answer/timing CSV](task-outcomes.csv) · [Paired comparison CSV](paired-comparison.csv) · [Combined older and new matrix](all-models-summary.csv) · [Every new/repeated failure](failures.md) · [Raw tool transcripts](raw-transcripts.md) · [Audit](audit-latest.json) · [Preparation and controls](preparation.json)', '']
    (master/'report.md').write_text('\n'.join(report))
    questions = ['# Exact ten questions', '', 'The original six question texts and their CLI guide are unchanged.', '']
    for i, t in enumerate(tasks.TASKS, 1):
        questions += [f"## {i}. {t['id']}", '', '````text', t['prompt'], '````', '']
    questions += ['## Common suffix', '', '````text', engine.SUFFIX.strip(), '````', '',
                  '## Original six CLI guide', '', '````text', tasks.original.GUIDE, '````', '',
                  '## New four CLI guide', '', '````text', tasks.NEW_GUIDE, '````', '',
                  '## Scheduling window', '', '````json', (master/'added/scheduling-window.json').read_text(), '````', '']
    (master/'questions.md').write_text('\n'.join(questions))
    failures, raw = ['# Every new or repeated full failure', ''], ['# Raw new and repeated tool transcripts', '']
    for stage, data in [('added4', added), ('repeat10', repeat)]:
        for r in data:
            d = Path(r['directory'])
            heading = f"## {stage} / {r['model']} / {r['task']}"
            visible = (d/'final.txt').read_text()
            raw += [heading, '', f"Verified={r['verified']}; full={r['passed']}; E2E={r['e2e_s']:.2f}s.", '', '````text', visible, '````', '']
            for event in rows(d/'pi-events.jsonl'):
                if event.get('type') in ['tool_execution_start', 'tool_execution_end']:
                    raw += ['````json', json.dumps(event, indent=2, ensure_ascii=False), '````', '']
            raw += ['Actual source call journal: '+str(d/'cli-audit/calls.jsonl'), '']
            if not r['passed']:
                failures += [heading, '', 'Error: '+(r['error'] or 'normal completion with failed checks'), '',
                             f"Checks: {r['checks_passed']}/{r['checks_total']}; verified={r['verified']}.", '',
                             'Failed checks:', '', '````json', json.dumps([c for c in r['checks'] if not c['passed']], indent=2, ensure_ascii=False), '````', '',
                             'Expected:', '', '````json', json.dumps(r['expected'], indent=2, ensure_ascii=False), '````', '',
                             'Actual:', '', '````json', json.dumps(r['answer'], indent=2, ensure_ascii=False), '````', '',
                             'Visible reply:', '', '````text', visible, '````', '', 'Evidence: '+str(d), '']
    (master/'failures.md').write_text('\n'.join(failures))
    (master/'raw-transcripts.md').write_text('\n'.join(raw))


def isolate(client, model):
    reasoning.wait_idle(client, timeout=300, stable_seconds=30)
    for current in client.models():
        if current.get('loaded') and current.get('model_type') in ['llm', 'vlm']:
            reasoning.unload_one_model(client, current['id'])
    client.json(model_url(model, 'load'), {}, timeout=600)
    reasoning.complete(client, model, 'What is 1+1? Finish with FINAL: and the number.', 'on', 123,
                       max_tokens=128, thinking_budget=64)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--probe-only', action='store_true')
    args = parser.parse_args()
    master = args.root.resolve()
    lock = (master/'driver.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    manifest = json.loads((master/'manifest.json').read_text())
    assert json.loads((master/'preparation.json').read_text())['passed']
    for stage in ['added', 'repeat']:
        assert json.loads((master/stage/'safety-preflight.json').read_text())['passed']
    key = json.loads((Path.home()/'.omlx/settings.json').read_text())['auth']['api_key']
    client = Client('http://127.0.0.1:8000', key)
    if not args.probe_only:
        assert json.loads((master/'integration-probe.json').read_text())['passed']
    manifest.update(status='integration probe' if args.probe_only else 'running', worker_pid=os.getpid())
    save(master/'manifest.json', manifest)
    export(master)
    print('RESULTS '+str(master), flush=True)
    try:
        for stage in (['added'] if args.probe_only else ['added', 'repeat']):
            root = master/stage
            scheduled = tasks.NEW_TASKS if stage == 'added' else tasks.TASKS
            existing = rows(root/'raw-results.jsonl')
            done = {(r['model'], r['task']) for r in existing}
            for definition in manifest['models']:
                model = definition['id']
                if not args.probe_only and all((model, t['id']) in done for t in scheduled):
                    continue
                info = next(m for m in client.models() if m['id'] == model)
                force = bool((info.get('settings') or {}).get('force_sampling', False))
                print('MODEL START '+stage+' / '+model, flush=True)
                try:
                    if force:
                        client.json(model_url(model, 'settings'), {'force_sampling': False}, method='PUT')
                    isolate(client, model)
                    todo = [{'id': 'integration_probe', 'category': 'infrastructure', 'prompt': 'Use bash to run printf "readonly-probe\\n". Then write probe.json containing exactly {"probe":"ok"}. Do not read user data. Keep the final reply brief.'}] if args.probe_only else scheduled
                    for task in todo:
                        if (model, task['id']) in done:
                            continue
                        for attempt in range(3):
                            reasoning.wait_idle(client)
                            if attempt:
                                isolate(client, model)
                            try:
                                row = engine.run_task(client, key, info, task, root, probe=args.probe_only)
                            except (KeyError, StopIteration, ValueError) as exc:
                                raise RuntimeError('Reference/harness error; no score recorded: '+repr(exc)) from exc
                            if not row.get('infrastructure'):
                                break
                            with (root/'infrastructure-events.jsonl').open('a') as f:
                                f.write(json.dumps(row)+'\n')
                            print('INFRASTRUCTURE '+row['kind']+' '+model+' / '+task['id'], flush=True)
                        else:
                            raise reasoning.BenchmarkPaused('Repeated source or external inference changes; scored results preserved.')
                        if args.probe_only:
                            save(master/'integration-probe.json', row)
                            print('PROBE '+json.dumps({'passed': row['passed'], 'error': row['error']}), flush=True)
                            if not row['passed']:
                                raise RuntimeError('Sandboxed Pi integration probe failed.')
                            return
                        row.update(stage=stage, reference_hash=digest(row['expected']))
                        with (root/'raw-results.jsonl').open('a') as f:
                            f.write(json.dumps(row, ensure_ascii=False)+'\n')
                        done.add((model, task['id']))
                        export(master)
                        print(f"TASK {stage} | {model} | {task['id']} | verified={row['verified']} full={row['passed']} | checks={row['checks_passed']}/{row['checks_total']} | E2E={row['e2e_s']:.2f}s | in={row['input_tps']} out={row['output_tps']} | {row['error']}", flush=True)
                finally:
                    if force:
                        client.json(model_url(model, 'settings'), {'force_sampling': True}, method='PUT')
                    reasoning.unload_one_model(client, model)
                print('MODEL DONE '+stage+' / '+model, flush=True)
        manifest.update(status='complete', finished_at=datetime.now().astimezone().isoformat())
    except BaseException as exc:
        manifest.update(status='interrupted', last_error=str(exc))
        raise
    finally:
        save(master/'manifest.json', manifest)
        export(master)
    print('FINISHED '+str(master/'report.md'), flush=True)


if __name__ == '__main__':
    main()
