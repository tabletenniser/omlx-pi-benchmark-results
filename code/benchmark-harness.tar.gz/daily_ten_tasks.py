"""Four real-data daily tasks; the original six prompts and graders stay intact."""
import collections
import csv
import itertools
import json
import os
import re
import shlex
import stat
import tempfile
from datetime import datetime, time, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

import daily_readonly_tasks as original

NEW_TASKS = [
    {'id': 'mac_backup_budget', 'category': 'Optimal backup planning', 'prompt': '''Plan a read-only backup batch with a hard 20 MiB capacity (20*1024*1024 bytes). Inspect regular non-symlink files directly in Downloads and Movies, top level only. Eligible candidates have 0 < size_bytes <= capacity. Sort candidates by size descending then absolute path ascending and take the first 16 (or all if fewer). Among subsets of those candidates choose maximum total bytes <= capacity; break ties by fewest files, then lexicographically smallest sorted list of absolute paths. Do not copy, move, modify or delete any source file: this is a plan only. Save candidate_inventory.csv with path,size_bytes for every candidate, sorted by path. Create plan_backup.py and actually run python3 plan_backup.py. It must write answer.json with budget_bytes,candidate_count,candidate_total_bytes,chosen_paths (sorted),chosen_bytes,unused_bytes. Use exact integers. An exhaustive search of at most 65536 subsets is sufficient. Save all outputs only in this task folder.'''},
    {'id': 'home_camera_crosscheck', 'category': 'Home Assistant and Frigate cross-check', 'prompt': r'''Cross-check my actual Home Assistant automations against the actual stored Frigate camera configuration. Read ALL automations with home-read ha automations and read home-read frigate config. Do not contact cameras or control anything. Consider automations containing a light.turn_off action anywhere in their actions tree and at least one camera entity reference anywhere in the automation. A camera reference is an entity matching (?:binary_sensor|sensor|switch)\.([a-z0-9_]+)_(?:person_occupancy|person_count|camera_fps|detect)\b; the captured group is its camera name. Deduplicate references. Recursively find light.turn_off action objects (action or service key), and collect entity_id values from their target or data mappings; a string is one target, a list contains targets. Do not execute templates. For every selected automation report automation_id, sorted light_targets and cameras sorted by name. Each camera object has name,exists_in_frigate,detect_enabled,record_enabled,fps,input_roles. Camera overrides take precedence over explicitly configured global detect/record values; missing values become null. input_roles is the sorted union of all configured ffmpeg input roles, or [] for an unknown camera. Unknown camera settings are null. Write audit_cameras.py and actually run python3 audit_cameras.py. It must create answer.json with automation_count,automations (sorted by automation_id),referenced_camera_names (sorted),unknown_camera_names (sorted),unreferenced_frigate_cameras (sorted). Save source JSON in this disposable folder.'''},
    {'id': 'frigate_log_triage', 'category': 'Local incident log analysis', 'prompt': r'''Analyze frigate-debug-redacted.log, a frozen credential-redacted snapshot of my actual local Frigate debug log. Process the whole file using a local program; do not paste the entire log into the chat. Do not contact cameras or restart services. A parsed record is a line matching this exact Python regex: \[\d{4}-\d\d-\d\d \d\d:\d\d:\d\d\]\s+(\S+)\s+(DEBUG|INFO|WARNING|ERROR|CRITICAL)\s*:\s?(.*)$ . Capture groups are component,level,message. Other formats, including go2rtc WRN and access logs, count as unparsed lines. The UTC timestamp is the first whitespace-delimited token of each parsed line, not the bracketed local timestamp. Create analyze_log.py and actually run python3 analyze_log.py. Write answer.json with total_lines,parsed_lines,unparsed_lines,level_counts (all five levels including zeros),top_error_components (up to five objects component,error_count; sort count descending then component ascending),first_error_utc,last_error_utc,busiest_error_minute (minute_utc,error_count; earliest UTC minute breaks a count tie),crashes_by_camera (sorted by camera). Count a crash only when an ERROR message exactly matches Ffmpeg process crashed unexpectedly for CAMERA. with CAMERA matching [a-z0-9_]+. Each crash object has camera,count,first_utc,last_utc. Output timestamps as YYYY-MM-DDTHH:MM:SSZ, discarding fractional seconds; busiest minutes have seconds 00. Use null for absent first/last/busiest values. Also save errors_by_component.csv with component,error_count for EVERY component with at least one ERROR, sorted by component. Do not change the input log.'''},
    {'id': 'gws_meeting_slots', 'category': 'Calendar availability planning', 'prompt': '''Find meeting availability using my real primary Google Calendar and scheduling-window.json. The file specifies five work dates spanning the daylight-saving transition, an IANA timezone, local work hours, a meeting length, and exact API timeMin/timeMax bounds. Use the authenticated GWS CLI to fetch ALL events in those exact bounds, expanding recurrences with singleEvents=true and orderBy=startTime; follow nextPageToken. Never create/update/delete events or send invitations. Ignore cancelled events and deduplicate by event id. Unlike the earlier conflict question, an all-day event blocks every listed work date in its [start.date,end.date) range. Timed events block their [start,end) intervals; use their explicit datetime offsets, convert instants correctly, and clip to each local workday. Merge overlapping OR touching busy intervals. Create find_slots.py and actually run python3 find_slots.py. Save source JSON and answer.json. Output timezone,meeting_minutes,days (one per work date, in date order),total_free_minutes,first_three_meetings. Each day has date,busy_minutes,free_minutes,free_intervals; every free interval has start_utc,end_utc,duration_minutes, sorted by start. Include all positive free intervals, even shorter than a meeting. For each free interval long enough, propose exactly ONE meeting starting at that interval's beginning and lasting meeting_minutes; first_three_meetings are the first three proposals across the days, each with date,start_utc,end_utc. All timestamps use YYYY-MM-DDTHH:MM:SSZ. Do not mark weekends as work dates or infer holidays beyond the actual all-day events.'''},
]
TASKS = original.TASKS + NEW_TASKS
GUIDE = original.GUIDE
NEW_GUIDE = GUIDE + '''\nAdditional tasks require an actual Python script saved in this task folder and
executed with python3 SCRIPT.py. Python standard-library zoneinfo is available.
Use the exact script name requested. Write answer.json in the initial task
folder. A displayed answer or a claim that a file was saved is insufficient.
For the camera cross-check use home-read ha automations without --match so
all automations are returned. For meeting planning use scheduling-window.json,
not calendar-window.json, and maxResults <=100 with pagination when needed.
The provided log is a frozen redacted local input. Analyze it with Python;
avoid loading all 1.6MB into the model context. No extra services are exposed.
'''
SCRIPTS = {'mac_backup_budget': 'plan_backup.py', 'home_camera_crosscheck': 'audit_cameras.py',
           'frigate_log_triage': 'analyze_log.py', 'gws_meeting_slots': 'find_slots.py'}
LOG_RX = re.compile(r'\[\d{4}-\d\d-\d\d \d\d:\d\d:\d\d\]\s+(\S+)\s+(DEBUG|INFO|WARNING|ERROR|CRITICAL)\s*:\s?(.*)$')
CAMERA_RX = re.compile(r'(?:binary_sensor|sensor|switch)\.([a-z0-9_]+)_(?:person_occupancy|person_count|camera_fps|detect)\b')


def local_inventory(task):
    if task != 'mac_backup_budget':
        return original.local_inventory(task)
    rows, stamp = original.local_inventory('mac_large_files')
    candidates = sorted((r for r in rows if 0 < r['size_bytes'] <= 20*1024*1024),
                        key=lambda r: (-r['size_bytes'], r['path']))[:16]
    return sorted(candidates, key=lambda r: r['path']), stamp


def backup_answer(rows):
    budget = 20*1024*1024
    # Independent reference: enumerate combinations by cardinality. Model code
    # is never executed by the grader.
    best_total, best_paths = 0, []
    for count in range(1, len(rows)+1):
        for combo in itertools.combinations(rows, count):
            total = sum(r['size_bytes'] for r in combo)
            if total > budget or total < best_total:
                continue
            paths = sorted(r['path'] for r in combo)
            if total > best_total or (len(paths), paths) < (len(best_paths), best_paths):
                best_total, best_paths = total, paths
    return {'budget_bytes': budget, 'candidate_count': len(rows),
            'candidate_total_bytes': sum(r['size_bytes'] for r in rows),
            'chosen_paths': best_paths, 'chosen_bytes': best_total, 'unused_bytes': budget-best_total}


def walk(value):
    yield value
    if isinstance(value, dict):
        for child in value.values():
            yield from walk(child)
    elif isinstance(value, list):
        for child in value:
            yield from walk(child)


def camera_answer(automations, frigate):
    cameras = frigate.get('cameras', {})
    selected, referenced = [], set()
    for automation in automations:
        actions = automation.get('actions', automation.get('action', []))
        off = [v for v in walk(actions) if isinstance(v, dict)
               and v.get('action', v.get('service')) == 'light.turn_off']
        names = sorted(set(CAMERA_RX.findall(json.dumps(automation))))
        if not off or not names:
            continue
        targets = set()
        for action in off:
            for key in ['target', 'data']:
                mapping = action.get(key) or {}
                entities = mapping.get('entity_id', []) if isinstance(mapping, dict) else []
                targets.update([entities] if isinstance(entities, str) else entities)
        entries = []
        for name in names:
            camera = cameras.get(name)
            detect, record = (camera.get('detect', {}), camera.get('record', {})) if camera else ({}, {})
            entries.append({'name': name, 'exists_in_frigate': camera is not None,
                            'detect_enabled': detect.get('enabled', frigate.get('detect', {}).get('enabled')) if camera else None,
                            'record_enabled': record.get('enabled', frigate.get('record', {}).get('enabled')) if camera else None,
                            'fps': detect.get('fps', frigate.get('detect', {}).get('fps')) if camera else None,
                            'input_roles': sorted({role for i in camera.get('ffmpeg', {}).get('inputs', []) for role in i.get('roles', [])}) if camera else []})
        referenced.update(names)
        selected.append({'automation_id': automation['id'], 'light_targets': sorted(targets), 'cameras': entries})
    return {'automation_count': len(selected), 'automations': sorted(selected, key=lambda a: a['automation_id']),
            'referenced_camera_names': sorted(referenced), 'unknown_camera_names': sorted(referenced-set(cameras)),
            'unreferenced_frigate_cameras': sorted(set(cameras)-referenced)}


def log_answer(text):
    lines = text.splitlines()
    levels = dict.fromkeys(['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'], 0)
    errors, minutes, crashes = collections.Counter(), collections.Counter(), {}
    parsed, timestamps = 0, []
    for line in lines:
        m = LOG_RX.search(line)
        if not m:
            continue
        component, level, message = m.groups()
        parsed += 1
        levels[level] += 1
        if level != 'ERROR':
            continue
        stamp = original.instant(line.split()[0])
        timestamps.append(stamp)
        errors[component] += 1
        minutes[original.utc(stamp.replace(second=0, microsecond=0))] += 1
        crash = re.fullmatch(r'Ffmpeg process crashed unexpectedly for ([a-z0-9_]+)\.', message)
        if crash:
            crashes.setdefault(crash[1], []).append(stamp)
    busy = min(minutes, key=lambda m: (-minutes[m], m)) if minutes else None
    answer = {'total_lines': len(lines), 'parsed_lines': parsed, 'unparsed_lines': len(lines)-parsed,
              'level_counts': levels,
              'top_error_components': [{'component': c, 'error_count': n} for c, n in sorted(errors.items(), key=lambda x: (-x[1], x[0]))[:5]],
              'first_error_utc': original.utc(min(timestamps)) if timestamps else None,
              'last_error_utc': original.utc(max(timestamps)) if timestamps else None,
              'busiest_error_minute': {'minute_utc': busy, 'error_count': minutes[busy]} if busy else None,
              'crashes_by_camera': [{'camera': c, 'count': len(ts), 'first_utc': original.utc(min(ts)), 'last_utc': original.utc(max(ts))} for c, ts in sorted(crashes.items())]}
    return answer, [{'component': c, 'error_count': n} for c, n in sorted(errors.items())]


def availability_answer(data, window):
    zone = ZoneInfo(window['timezone'])
    events = {e['id']: e for e in data.get('items', []) if e.get('status') != 'cancelled'}
    days, proposals = [], []
    for day in window['work_dates']:
        start = datetime.combine(datetime.fromisoformat(day).date(), time.fromisoformat(window['work_start']), zone)
        end = datetime.combine(start.date(), time.fromisoformat(window['work_end']), zone)
        spans = []
        for event in events.values():
            if 'date' in event['start']:
                if event['start']['date'] <= day < event['end']['date']:
                    spans.append((start, end))
            else:
                lo, hi = original.instant(event['start']['dateTime']), original.instant(event['end']['dateTime'])
                lo, hi = max(start, lo), min(end, hi)
                if lo < hi:
                    spans.append((lo, hi))
        merged = []
        for lo, hi in sorted(spans):
            if merged and lo <= merged[-1][1]:
                merged[-1] = (merged[-1][0], max(merged[-1][1], hi))
            else:
                merged.append((lo, hi))
        free, cursor = [], start
        for lo, hi in merged + [(end, end)]:
            if cursor < lo:
                minutes = (lo-cursor).total_seconds()/60
                free.append({'start_utc': original.utc(cursor), 'end_utc': original.utc(lo), 'duration_minutes': minutes})
                if minutes >= window['meeting_minutes']:
                    proposals.append({'date': day, 'start_utc': original.utc(cursor),
                                      'end_utc': original.utc(cursor+timedelta(minutes=window['meeting_minutes']))})
            cursor = max(cursor, hi)
        free_minutes = sum(x['duration_minutes'] for x in free)
        days.append({'date': day, 'busy_minutes': (end-start).total_seconds()/60-free_minutes,
                     'free_minutes': free_minutes, 'free_intervals': free})
    return {'timezone': window['timezone'], 'meeting_minutes': window['meeting_minutes'], 'days': days,
            'total_free_minutes': sum(d['free_minutes'] for d in days), 'first_three_meetings': proposals[:3]}


def setup(task, work, root):
    if task in {t['id'] for t in original.TASKS}:
        return original.setup(task, work, root)
    work.mkdir()
    (work/'CLI_GUIDE.md').write_text(NEW_GUIDE)
    if task == 'frigate_log_triage':
        (work/'frigate-debug-redacted.log').write_bytes((root/'fixtures/frigate-debug-redacted.log').read_bytes())
    if task == 'gws_meeting_slots':
        (work/'scheduling-window.json').write_bytes((root/'scheduling-window.json').read_bytes())
    return {p.name: original.fingerprint(p) for p in work.iterdir() if p.is_file()}


def script_executed(script, events):
    successful = {e.get('toolCallId') for e in events if e.get('type') == 'tool_execution_end' and not e.get('isError', False)}
    for event in events:
        if event.get('type') != 'tool_execution_start' or event.get('toolName') != 'bash' or event.get('toolCallId') not in successful:
            continue
        command = (event.get('args') or {}).get('command', '')
        heredoc = None
        for line in command.splitlines():
            if heredoc is not None:
                if line.strip() == heredoc:
                    heredoc = None
                continue
            try:
                lexer = shlex.shlex(line, posix=True, punctuation_chars=';&|<>')
                lexer.whitespace_split = True
                tokens = list(lexer)
            except ValueError:
                continue
            if '<<' in tokens:
                index = tokens.index('<<')
                if index+1 < len(tokens):
                    heredoc = tokens[index+1].lstrip('-')
            groups, current = [], []
            for token in tokens:
                if token in [';', '&&', '||', '|', '&']:
                    groups.append(current)
                    current = []
                else:
                    current.append(token)
            groups.append(current)
            for group in groups:
                if group and Path(group[0]).name in ['env', 'command', 'time']:
                    group = group[1:]
                    while group and '=' in group[0]:
                        group = group[1:]
                if not group or Path(group[0]).name not in ['python', 'python3', 'python3.14']:
                    continue
                args = group[1:]
                while args and args[0] in ['-B', '-u', '-I', '-S', '-E', '-s', '-O', '-OO']:
                    args = args[1:]
                if args and Path(args[0]).name == script:
                    return True
    return False


def calendar_receipt(cli, window):
    valid = []
    for row in cli:
        if row.get('returncode') != 0 or not row.get('dispatched') or row.get('method') != 'calendar.events.list':
            continue
        p = row.get('params', {})
        try:
            match = all(original.instant(p[k]) == original.instant(window[k]) for k in ['timeMin', 'timeMax'])
        except (KeyError, ValueError, TypeError):
            match = False
        if match and p.get('calendarId') == 'primary' and p.get('singleEvents') in [True, 'true'] and p.get('orderBy') == 'startTime':
            valid.append(row)
    starts = [r for r in valid if not r.get('params', {}).get('pageToken')]
    if not starts:
        return None
    first = starts[-1]
    data = original.receipt_json(first)
    items, token, seen = list(data.get('items', [])), data.get('nextPageToken'), set()
    while token and token not in seen:
        seen.add(token)
        pages = [r for r in valid if r.get('params', {}).get('pageToken') == token]
        if not pages:
            return None
        page = original.receipt_json(pages[-1])
        items.extend(page.get('items', []))
        token = page.get('nextPageToken')
    fields = first.get('params', {}).get('fields', '')
    if token or (fields and fields != '*' and 'nextPageToken' not in fields):
        return None
    if fields and fields != '*' and not re.search(r'\bitems\b', fields):
        return None
    for event in items:
        if event.get('status') == 'cancelled':
            continue
        if not all(k in event for k in ['id', 'start', 'end']):
            return None
        if not all(isinstance(event[k], dict) and ('date' in event[k] or 'dateTime' in event[k]) for k in ['start', 'end']):
            return None
    return {**data, 'items': items}


def seal_artifacts(task, work, immutable):
    """Copy bounded ordinary files without following model-controlled links.

    The sealed directory is outside the model's writable/readable work folder.
    Holding a directory fd and O_NOFOLLOW file fds prevents a path-swap escape.
    No model program is executed by this reader or by the grader.
    """
    metadata = work.parent/'artifact-snapshot.json'
    if metadata.exists():
        return work.parent/json.loads(metadata.read_text())['directory']
    sealed = Path(tempfile.mkdtemp(prefix='graded-artifacts-', dir=work.parent))
    names = set(immutable) | {'answer.json', 'inventory.csv', 'checksums.csv',
                              'candidate_inventory.csv', 'errors_by_component.csv'}
    if task in SCRIPTS:
        names.add(SCRIPTS[task])
    captured, rejected = {}, {}
    try:
        directory_fd = os.open(work, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    except OSError as exc:
        directory_fd = None
        rejected['work'] = 'Cannot pin ordinary task directory: '+str(exc.errno)
    try:
        for name in sorted(names):
            if directory_fd is None:
                break
            fd = None
            try:
                fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=directory_fd)
                info = os.fstat(fd)
                if not stat.S_ISREG(info.st_mode) or info.st_size > 8*1024*1024:
                    rejected[name] = 'Not an ordinary file within the 8 MiB artifact limit.'
                    continue
                data = bytearray()
                while len(data) <= 8*1024*1024:
                    chunk = os.read(fd, min(65536, 8*1024*1024+1-len(data)))
                    if not chunk:
                        break
                    data.extend(chunk)
                if len(data) > 8*1024*1024:
                    rejected[name] = 'Artifact grew past 8 MiB while being read.'
                    continue
                (sealed/name).write_bytes(data)
                captured[name] = {'bytes': len(data), 'sha256': original.fingerprint(sealed/name)}
            except FileNotFoundError:
                pass
            except OSError as exc:
                rejected[name] = 'Artifact open rejected: errno '+str(exc.errno)
            finally:
                if fd is not None:
                    os.close(fd)
    finally:
        if directory_fd is not None:
            os.close(directory_fd)
    temporary = metadata.with_suffix('.json.tmp')
    temporary.write_text(json.dumps({'directory': sealed.name, 'files': captured, 'rejected': rejected,
                                    'reader': 'pinned directory fd; O_NOFOLLOW; regular files; 8 MiB cap'}, indent=2)+'\n')
    temporary.replace(metadata)
    return sealed


def verify(task, work, immutable, cli, events, root, local_rows=None):
    return verify_sealed(task, seal_artifacts(task, work, immutable), immutable, cli, events, root, local_rows)


def verify_sealed(task, work, immutable, cli, events, root, local_rows=None):
    if task in {t['id'] for t in original.TASKS}:
        return original.verify(task, work, immutable, cli, events, root, local_rows)
    checks = []
    def check(name, passed, detail=None):
        checks.append({'name': name, 'passed': bool(passed), 'detail': detail})
    for name, digest in immutable.items():
        check('fixture preserved: '+name, (work/name).is_file() and not (work/name).is_symlink() and original.fingerprint(work/name) == digest)
    try:
        answer = json.loads((work/'answer.json').read_text())
        valid = isinstance(answer, dict) and not (work/'answer.json').is_symlink()
    except (OSError, ValueError):
        answer, valid = {}, False
    check('answer.json is an object', valid)
    script = work/SCRIPTS[task]
    check('requested Python program saved', script.is_file() and not script.is_symlink())
    executed = script_executed(SCRIPTS[task], events)
    check('actual successful Python script invocation', executed)
    success = [r for r in cli if r.get('returncode') == 0 and r.get('dispatched')]
    reference = 'actual source receipts or frozen local fixture'
    workflow = executed
    if task == 'mac_backup_budget':
        expected = backup_answer(local_rows)
        try:
            rows = list(csv.DictReader((work/'candidate_inventory.csv').open()))
            for r in rows:
                r['size_bytes'] = int(r['size_bytes'])
            csv_ok = rows == sorted(local_rows, key=lambda r: r['path']) and not (work/'candidate_inventory.csv').is_symlink()
        except (OSError, ValueError, KeyError):
            csv_ok = False
        check('complete source-grounded candidate CSV', csv_ok)
    elif task == 'home_camera_crosscheck':
        ha = [r for r in success if r['service'] == 'home-read' and r['argv'] == ['ha', 'automations']]
        frigate = [r for r in success if r['service'] == 'home-read' and r['argv'] == ['frigate', 'config']]
        check('actual complete HA automation read', bool(ha))
        check('actual Frigate configuration read', bool(frigate))
        workflow = workflow and bool(ha and frigate)
        ha_data = original.receipt_json(ha[-1])['data'] if ha else json.loads((root/'preflight/ha-automations-redacted.json').read_text())
        f_data = original.receipt_json(frigate[-1])['data'] if frigate else json.loads((root/'preflight/frigate-config-redacted.json').read_text())
        expected = camera_answer(ha_data, f_data)
        if not ha or not frigate:
            reference = 'preflight fallback for missing required source retrieval'
    elif task == 'frigate_log_triage':
        expected, csv_expected = log_answer((root/'fixtures/frigate-debug-redacted.log').read_text())
        try:
            rows = list(csv.DictReader((work/'errors_by_component.csv').open()))
            for r in rows:
                r['error_count'] = int(r['error_count'])
            csv_ok = rows == csv_expected and not (work/'errors_by_component.csv').is_symlink()
        except (OSError, ValueError, KeyError):
            csv_ok = False
        check('complete error-component CSV', csv_ok)
    else:
        window = json.loads((root/'scheduling-window.json').read_text())
        source = calendar_receipt(success, window)
        check('actual complete requested Calendar read', source is not None)
        workflow = workflow and source is not None
        if source is None:
            source = json.loads((root/'preflight/gws-meeting-events.stdout').read_text())
            reference = 'preflight fallback; complete required Calendar retrieval missing'
        expected = availability_answer(source, window)
    for key, value in expected.items():
        check('correct '+key, isinstance(answer, dict) and answer.get(key) == value,
              {'expected': value, 'actual': answer.get(key) if isinstance(answer, dict) else None})
    return {'checks': checks, 'checks_passed': sum(c['passed'] for c in checks), 'checks_total': len(checks),
            'verified': all(c['passed'] for c in checks), 'answer': answer, 'expected': expected,
            'reference': reference, 'workflow_passed': workflow}
