"""Exercise the actual macOS boundary and broker against disposable controls."""
import http.server
import hashlib
import json
import os
import shutil
import signal
import subprocess
import threading
import urllib.request
from pathlib import Path

from daily_readonly_broker import Broker,validate_gws
from daily_readonly_sandbox import host_read_paths,profile


def run(root,key,client):
    runtime=root/'runtime';runtime.mkdir(exist_ok=True);bin_dir=runtime/'bin';bin_dir.mkdir(exist_ok=True)
    for name in ['daily_readonly_cli.py','pi_daily_readonly.mjs']:
        shutil.copy2(Path(__file__).parent/name,runtime/name)
    wrapper=runtime/'daily_readonly_cli.py';wrapper.chmod(0o755)
    for name in ['gws','home-read']:
        link=bin_dir/name
        if not link.exists():link.symlink_to(wrapper)
    directory=root/'preflight/boundary';directory.mkdir(exist_ok=True);work=directory/'work';work.mkdir(exist_ok=True)
    protected=directory/'protected-canary.txt';protected.write_text('unchanged disposable canary\n')
    protected_dir=directory/'protected-directory';protected_dir.mkdir(exist_ok=True)
    secret_fixture=directory/'client_secret_disposable.json';secret_fixture.write_text('{"dummy":"not an actual credential"}\n')
    readable_canary=directory/'host-readable-disposable.jpg';readable_canary.write_bytes(b'disposable-readonly-media')
    external_process=subprocess.Popen(['/bin/sleep','60'])
    broker=Broker(root,key,client);broker.select(directory,'preflight-no-inference')
    hits=[]
    class Denied(http.server.BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def do_GET(self):hits.append(self.path);self.send_response(200);self.end_headers();self.wfile.write(b'unsafe-network-should-not-be-reachable')
    forbidden=http.server.ThreadingHTTPServer(('127.0.0.1',0),Denied);threading.Thread(target=forbidden.serve_forever,daemon=True).start()
    sb=directory/'boundary.sb';sb.write_text(profile(work,runtime,broker.port,readable=host_read_paths()+[readable_canary]))
    env={k:v for k,v in os.environ.items()if not any(s in k.upper()for s in ['TOKEN','SECRET','API_KEY','CREDENTIAL','SSH_AUTH','PYTHONPATH','NODE_OPTIONS'])}
    env.update(DAILY_BROKER_URL='http://127.0.0.1:'+str(broker.port),DAILY_READ_TOKEN=broker.token,PATH=str(bin_dir)+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',PYTHONDONTWRITEBYTECODE='1',PROBE_FILE=str(protected),PROBE_DIR=str(protected_dir),PROBE_PORT=str(forbidden.server_address[1]),PROBE_SAME_SECRET=str(secret_fixture),PROBE_REAL_SECRET=str(Path.home()/'.omlx/settings.json'))
    media=next(p for p in host_read_paths()if p.is_file());env['PROBE_MEDIA']=str(media)
    env.update(PROBE_HARDLINK_SOURCE=str(readable_canary),PROBE_EXTERNAL_PID=str(external_process.pid))
    env['PROBE_READABLE_FILES']=json.dumps([str(p)for p in host_read_paths()if p.is_file()])
    checks=[]
    def check(name,passed,detail=None):checks.append({'name':name,'passed':bool(passed),'detail':detail})
    def sandbox(argv):return subprocess.run(['/usr/bin/sandbox-exec','-f',str(sb),*argv],cwd=work,env=env,capture_output=True,text=True,timeout=40)
    code='''import hashlib,json,os,signal,subprocess,urllib.request
from pathlib import Path
p=Path(os.environ['PROBE_FILE']);d=Path(os.environ['PROBE_DIR']);out={}
operations={'overwrite':lambda:p.write_text('mutated'),'append':lambda:p.open('a').write('mutated'),'delete':p.unlink,'rename':lambda:p.rename(Path.cwd()/'stolen'),'chmod':lambda:p.chmod(0o777),'mkdir_outside':lambda:(d/'new').mkdir(),'read_harness':p.read_bytes,'read_firmlink_alias':lambda:(Path('/System/Volumes/Data')/str(p).lstrip('/')).read_bytes(),'read_credential_named_file':lambda:Path(os.environ['PROBE_SAME_SECRET']).read_bytes()}
link=Path('outside-link');link.unlink(missing_ok=True);link.symlink_to(p);operations['write_via_symlink']=lambda:link.write_text('mutated')
for name,operation in operations.items():
 try:operation();out[name]='ALLOWED'
 except OSError as e:out[name]=type(e).__name__
try:fd=os.open(os.environ['PROBE_REAL_SECRET'],os.O_RDONLY);os.close(fd);out['open_real_credentials']='ALLOWED'
except OSError as e:out['open_real_credentials']=type(e).__name__
try:os.link(os.environ['PROBE_HARDLINK_SOURCE'],'host-hardlink');out['hardlink_creation']='ALLOWED'
except OSError as e:out['hardlink_creation']=type(e).__name__
try:os.kill(int(os.environ['PROBE_EXTERNAL_PID']),signal.SIGTERM);out['signal_external_process']='ALLOWED'
except OSError as e:out['signal_external_process']=type(e).__name__
try:urllib.request.urlopen('http://127.0.0.1:'+os.environ['PROBE_PORT']+'/forbidden',timeout=3).read();out['unapproved_network']='ALLOWED'
except Exception as e:out['unapproved_network']=type(e).__name__
Path('allowed-scratch.txt').write_text('allowed');out['scratch_write']=Path('allowed-scratch.txt').read_text()=='allowed'
child=subprocess.Popen(['/bin/sleep','10']);child.terminate();child.wait(timeout=3);out['terminate_own_child']=True
out['media_sha256']=hashlib.sha256(Path(os.environ['PROBE_MEDIA']).read_bytes()).hexdigest()
out['downloads_listing']=len(list((Path.home()/'Downloads').iterdir()))
out['unreadable_candidates']=[]
for candidate in json.loads(os.environ['PROBE_READABLE_FILES']):
 try:
  with open(candidate,'rb')as f:f.read(1)
 except OSError as e:out['unreadable_candidates'].append({'path':candidate,'error':type(e).__name__})
print(json.dumps(out))
'''
    try:
        r=sandbox(['/opt/homebrew/bin/python3','-c',code]);(directory/'os-probe.stdout').write_text(r.stdout);(directory/'os-probe.stderr').write_text(r.stderr)
        check('OS probe completed',r.returncode==0,{'returncode':r.returncode,'stderr':r.stderr[-1200:]})
        try:result=json.loads(r.stdout)
        except ValueError:result={}
        for name in ['overwrite','append','delete','rename','chmod','mkdir_outside','read_harness','read_firmlink_alias','read_credential_named_file','write_via_symlink']:
            check('kernel denies '+name,result.get(name)=='PermissionError',result.get(name))
        check('direct unapproved network denied',result.get('unapproved_network')not in(None,'ALLOWED')and not hits,result.get('unapproved_network'))
        check('scratch writes work',result.get('scratch_write'))
        check('same-sandbox child cleanup works',result.get('terminate_own_child'))
        check('allowlisted actual media can be hashed',result.get('media_sha256')==hashlib.sha256(media.read_bytes()).hexdigest())
        check('actual Downloads directory can be inspected',isinstance(result.get('downloads_listing'),int))
        check('every eligible media candidate is readable, including Unicode names',result.get('unreadable_candidates')==[],result.get('unreadable_candidates'))
        check('actual credential file cannot be opened',result.get('open_real_credentials')=='PermissionError',result.get('open_real_credentials'))
        check('hard-link escape is denied',result.get('hardlink_creation')=='PermissionError',result.get('hardlink_creation'))
        check('signals cannot reach outside sandbox',result.get('signal_external_process')=='PermissionError'and external_process.poll()is None,result.get('signal_external_process'))
        check('readable host canary content unchanged',readable_canary.read_bytes()==b'disposable-readonly-media')
        check('external canary unchanged',protected.exists()and protected.read_text()=='unchanged disposable canary\n')
        for name,argv in [
            ('Google delete',['gws','drive','files','delete','--params','{"fileId":"disposable-not-real"}']),
            ('Google update',['gws','drive','files','update','--params','{"fileId":"disposable-not-real"}']),
            ('Google upload flag',['gws','drive','files','list','--upload','anything']),
            ('Google auth export',['gws','auth','export']),
            ('Home Assistant restart',['home-read','ha','restart']),
            ('Frigate restart',['home-read','frigate','restart']),
        ]:
            r=sandbox(argv);check(name+' blocked before dispatch',r.returncode==3,{'returncode':r.returncode,'stderr':r.stderr[:250]})
        r=sandbox(['home-read','ha','automations','--match','basement']);check('real sanitized Home Assistant read works',r.returncode==0 and 'basement_no_motion_light_off'in r.stdout)
        r=sandbox(['home-read','frigate','config']);check('real sanitized Frigate read works',r.returncode==0 and 'yolov9-m-320.onnx'in r.stdout)
        r=sandbox(['gws','drive','about','get','--params','{"fields":"storageQuota"}']);check('real authenticated Google read works',r.returncode==0 and 'storageQuota'in r.stdout,{'returncode':r.returncode})
        for name in ['drive.about.get','drive.files.list','calendar.calendarList.list','calendar.events.list']:
            r=sandbox(['gws','schema',name])
            try:schema=json.loads(r.stdout)
            except ValueError:schema={}
            check('allowlisted API is actually HTTP GET: '+name,r.returncode==0 and schema.get('httpMethod')=='GET')
        entry=Path.home()/'.pi/agent/install/releases/1.4.0/node_modules/@earendil-works/pi-coding-agent/dist/bundle/cli.js'
        r=sandbox(['/opt/homebrew/bin/node',str(entry),'--version']);check('Pi CLI executes inside boundary',r.returncode==0 and '1.4.0'in r.stdout)
        journal=[json.loads(s)for s in(directory/'cli-audit/calls.jsonl').read_text().splitlines()]
        check('all denied broker calls were never dispatched',all(not x.get('dispatched')for x in journal if x.get('policy_denied')))
        check('only allowlisted Google read methods dispatched',all(tuple(x['argv'][:3])in {('drive','about','get')}or x.get('kind')=='schema'for x in journal if x['service']=='gws'and x.get('dispatched')))
        report={'checks':checks,'passed':all(c['passed']for c in checks),'checks_passed':sum(c['passed']for c in checks),'checks_total':len(checks),'forbidden_network_requests_observed':len(hits),'note':'All destructive probes target disposable local canaries or nonexistent IDs rejected before any Google dispatch. No Google mutation was executed.'}
        (root/'safety-preflight.json').write_text(json.dumps(report,indent=2)+'\n')
        return report
    finally:
        broker.close();forbidden.shutdown();forbidden.server_close()
        if external_process.poll()is None:external_process.terminate();external_process.wait(timeout=5)


if __name__=='__main__':
    from qwen38_mtp_benchmark import Client
    root=Path(json.loads(Path('active-daily-benchmark.json').read_text())['root']);key=json.loads((Path.home()/'.omlx/settings.json').read_text())['auth']['api_key']
    result=run(root,key,Client('http://127.0.0.1:8000',key))
    print(json.dumps({'passed':result['passed'],'checks_passed':result['checks_passed'],'checks_total':result['checks_total'],'failed':[c for c in result['checks']if not c['passed']]},indent=2))
    raise SystemExit(0 if result['passed']else 1)
