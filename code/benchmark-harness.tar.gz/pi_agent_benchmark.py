#!/usr/bin/env python3
"""Run real Pi CLI tasks sequentially, capture native tool events and oMLX speed."""
import argparse
import csv
import hashlib
import json
import os
import signal
import statistics
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

import reasoning_benchmark as reasoning
from pi_benchmark_tasks import TASKS, setup_task, verify_task
from qwen38_mtp_benchmark import Client, model_url
from word_count_benchmark import helper_reason

HERE = Path(__file__).resolve().parent
FIELDS = ['model','task','repetition','passed','functional_passed','workflow_passed','checks_passed','checks_total','e2e_s',
          'model_requests','tool_calls','tool_errors','input_tokens','cached_input_tokens',
          'computed_input_tokens','input_tps','output_tokens','reasoning_tokens','output_tps',
          'input_eval_s','output_eval_s','tool_seconds','timed_out','error','directory']

def read_jsonl(file):
    return [json.loads(line)for line in file.read_text().splitlines()]if file.exists()else[]

def classify_checks(row):
    workflow_names={'a real tool call executed successfully','requested native tool types used',
                    'agent executed requested program/tests','agent ran the checker'}
    functional=[c for c in row['checks']if c['name']not in workflow_names]
    workflow=[c for c in row['checks']if c['name']in workflow_names]
    row['functional_passed']=bool(functional)and all(c['passed']for c in functional)
    row['workflow_passed']=bool(workflow)and all(c['passed']for c in workflow)
    return row

def summarize(rows,manifest):
    result=[]
    for m in manifest['models']:
        rs=[r for r in rows if r['model']==m['id']]
        complete=[r for r in rs if r.get('usage_requests',0)>0 and r.get('input_eval_s') and r.get('output_eval_s')]
        denominator=sum(r['input_eval_s']for r in complete)
        output_s=sum(r['output_eval_s']for r in complete)
        times=[r['e2e_s']for r in rs]
        result.append({'model':m['id'],'passed':sum(r['passed']for r in rs),
                       'functional_passed':sum(classify_checks(r)['functional_passed']for r in rs),
                       'workflow_passed':sum(r['workflow_passed']for r in rs),'attempted':len(rs),
                       'checks_passed':sum(r['checks_passed']for r in rs),'checks_total':sum(r['checks_total']for r in rs),
                       'input_tps':sum(r['computed_input_tokens']for r in complete)/denominator if denominator else None,
                       'output_tps':sum(r['output_tokens']for r in complete)/output_s if output_s else None,
                       'median_task_e2e_s':statistics.median(times)if times else None,
                       'total_task_e2e_s':sum(times),'mean_task_e2e_s':statistics.mean(times)if times else None,
                       'model_requests':sum(r['model_requests']for r in rs),'tool_calls':sum(r['tool_calls']for r in rs),
                       'tool_errors':sum(r['tool_errors']for r in rs),'timeouts':sum(r['timed_out']for r in rs)})
    return result

def outputs(directory,rows,manifest):
    summary=summarize(rows,manifest)
    (directory/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    for filename,data in [('summary.json',summary)]:
        (directory/filename).write_text(json.dumps(data,indent=2)+'\n')
    for filename,data,fields in [('raw-results.csv',rows,FIELDS),('summary.csv',summary,list(summary[0]))]:
        with(directory/filename).open('w',newline='')as f:
            w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(data)
    def fmt(n):return f'{n:.2f}'if n is not None else 'pending'
    lines=['# Pi CLI tool and programming benchmark','',
           f"Pi {manifest['pi_version']}, six tasks × {manifest['repeats']} repetitions per full model. Fresh disposable task directories and sessions; sequential inference with explicit unloads between models. MCP, discovered extensions, skills and user context files are disabled for a common native-tool baseline. An explicit audit extension records provider usage and timings; it does not rewrite the prompt, tool schemas, or tool arguments.",'',
           'Medium thinking, 1,024 thinking tokens and 3,072 total output tokens per model turn; at most 12 model requests and 420 seconds per task. Temperature 0.6, top_p 0.95, top_k 20; matched best-effort seeds. The Pi default coding system prompt is used. Node executes TypeScript directly; these are runtime tests, not static TypeScript type checks.','',
           'A full task pass requires all output, edge-case, preserved-fixture, requested-tool, and actual execution checks. Check counts are diagnostic and differ by task. CLI and code execution time are included in task E2E, as are Pi startup, subsequent model turns, and tool repair attempts; initial model loading and verifier execution are excluded. Input rate counts uncached tokens, and output rate includes reasoning and function-call tokens. Rates are token-weighted using oMLX provider timing, not E2E token averages. oMLX prefix caching remains enabled, and its hits are reported.','',
           '| Model | Full task pass | Working result | Tool workflow | Input tok/s | Output tok/s | Mean task E2E s | Tool calls | Tool errors |',
           '|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    for r in summary:
        lines.append(f"| {r['model']} | {r['passed']}/{r['attempted']} | {r['functional_passed']}/{r['attempted']} | {r['workflow_passed']}/{r['attempted']} | {fmt(r['input_tps'])} | {fmt(r['output_tps'])} | {fmt(r['mean_task_e2e_s'])} | {r['tool_calls']} | {r['tool_errors']} |")
    lines+=['','Task wall time is observed by a one-second process monitor, so allow approximately one second of measurement granularity. Native provider token rates use the server-reported evaluation durations.','','## Task results','','| Model | Task | Run | Pass | Checks | E2E s | Requests | Tool calls | Errors |','|---|---|---:|---|---:|---:|---:|---:|---|']
    for r in rows:
        lines.append(f"| {r['model']} | {r['task']} | {r['repetition']} | {r['passed']} | {r['checks_passed']}/{r['checks_total']} | {fmt(r['e2e_s'])} | {r['model_requests']} | {r['tool_calls']} | {r.get('error','')} |")
    lines+=['','## Prompts','']
    for t in TASKS:lines += [f"### {t['id']}",'',t['prompt'],'']
    lines+=['## Raw artifacts','', 'Each task directory contains prompt.txt, the actual `pi` argv in command.json, all Pi JSON events, stderr, provider request/timing audit, test checks, final text, and the complete work directory. raw-results.jsonl contains aggregate metrics and all verifier checks. Extra attempts interrupted by external model loading are retained in isolation-events.jsonl and their original directories, but excluded from scored results.','']
    (directory/'report.md').write_text('\n'.join(lines))
    raw=['# Raw Pi tool transcripts','']
    for r in rows:
        base=Path(r['directory']);events=read_jsonl(base/'pi-events.jsonl')
        raw += [f"## {r['model']} / {r['task']} / run {r['repetition']}",'',
                f"Passed: {r['passed']}; E2E {r['e2e_s']:.2f}s; tools {r['tool_calls']}; errors {r.get('error','') or 'none'}.",'']
        for e in events:
            if e.get('type')=='message_end'and e.get('message',{}).get('role')=='assistant':
                for c in e['message'].get('content',[]):
                    if c.get('type')=='text':raw += ['Assistant:','',c.get('text',''),'']
            elif e.get('type') in ('tool_execution_start','tool_execution_end'):
                raw+=['```json',json.dumps(e,ensure_ascii=False,indent=2),'```','']
        raw+=['Checks:','', '```json',json.dumps(r['checks'],ensure_ascii=False,indent=2),'```','']
    (directory/'raw-transcripts.md').write_text('\n'.join(raw))

def stop_own_process(process):
    if process.poll()is None:
        os.killpg(process.pid,signal.SIGTERM)
        try:process.wait(timeout=12)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=5)

def isolation_activity(state,activity,model,owned):
    """Aggregate admin counts may include completed streams being cleaned up."""
    foreign_models=[m.get('id')for m in activity.get('models',[])if m.get('id')!=model]
    ids=set()
    for m in activity.get('models',[]):
        for kind in ('generating','prefilling','waiting','activities'):
            ids.update(r['request_id']for r in m.get(kind,[])if r.get('request_id'))
    return {'foreign_models':foreign_models,'active_request_ids':sorted(ids),'unknown_request_ids':sorted(ids-owned),
            'loaded_count':state.get('loaded_count',0),'admin_active':activity.get('total_active_requests',0),
            'admin_waiting':activity.get('total_waiting_requests',0)}

def metrics_from_audit(audit,events):
    # Usage can appear repeatedly on a streamed finish; use the last per request.
    usages={}
    for event in audit:
        if event.get('event')=='provider_metrics'and event.get('data',{}).get('usage'):
            usages[event['request']]=event['data']['usage']
    values=list(usages.values())
    input_tokens=sum(v.get('prompt_tokens',0)for v in values)
    cached=sum((v.get('prompt_tokens_details')or{}).get('cached_tokens',0)for v in values)
    input_s=sum(v.get('prompt_eval_duration',0)for v in values)
    output_s=sum(v.get('generation_duration',0)for v in values)
    output_tokens=sum(v.get('completion_tokens',0)for v in values)
    return {'model_requests':sum(e.get('event')=='request'for e in audit),'usage_requests':len(values),
            'input_tokens':input_tokens,'cached_input_tokens':cached,'computed_input_tokens':max(0,input_tokens-cached),
            'input_eval_s':input_s,'output_eval_s':output_s,
            'input_tps':max(0,input_tokens-cached)/input_s if input_s else None,
            'output_tokens':output_tokens,'output_tps':output_tokens/output_s if output_s else None,
            'reasoning_tokens':sum((v.get('completion_tokens_details')or{}).get('reasoning_tokens',0)for v in values),
            'tool_calls':sum(e.get('type')=='tool_execution_start'for e in events),
            'tool_errors':sum(e.get('type')=='tool_execution_end'and e.get('isError',False)for e in events),
            'tool_seconds':sum(e.get('durationMs',0)for e in events if e.get('type')=='tool_execution_end')/1000}

def run_task(client,model,task,repetition,base,config,key):
    directory=base/(task['id']+f'-run{repetition}-'+datetime.now().strftime('%H%M%S-%f'))
    directory.mkdir();work=directory/'work';setup=setup_task(task['id'],work)
    (directory/'setup.json').write_text(json.dumps(setup,indent=2)+'\n')
    prompt=task['prompt']+'\n\nWork only in the current task directory. Complete the task with real tools, keep the final reply brief, and do not install dependencies or access the network.'
    (directory/'prompt.txt').write_text(prompt+'\n')
    cmd=['pi','--offline','--no-extensions','--no-mcp','--no-skills','--no-prompt-templates','--no-themes',
         '--no-context-files','--no-session','--mode','json','--print','--provider','omlx-benchmark',
         '--model',model,'--thinking','medium','--tools','read,write,edit,bash',
         '--extension',str(HERE/'pi_benchmark_audit.mjs'),'--',prompt]
    (directory/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
    env=os.environ.copy();env.update(PI_CODING_AGENT_DIR=str(config),PI_BENCHMARK_API_KEY=key,
                                   PI_BENCHMARK_AUDIT=str(directory/'provider-audit.jsonl'),
                                   PI_OFFLINE='1',PI_TELEMETRY='0')
    error='';conflict=False;timed_out=False;overlap_samples=0;last_activity={};max_admin_requests=0
    started=time.perf_counter()
    with(directory/'pi-events.jsonl').open('w')as out,(directory/'pi-stderr.txt').open('w')as err:
        process=subprocess.Popen(cmd,cwd=work,env=env,stdout=out,stderr=err,start_new_session=True)
        try:
            while process.poll()is None:
                if time.perf_counter()-started>420:
                    timed_out=True;error='Task exceeded 420-second wall limit';stop_own_process(process);break
                state=client.json('/health',timeout=5).get('engine_pool',{})
                activity=client.json('/admin/api/activity',timeout=5).get('active_models',{})
                ids_file=directory/'provider-audit.jsonl.request-ids'
                owned=set(ids_file.read_text().splitlines())if ids_file.exists()else set()
                last_activity=isolation_activity(state,activity,model,owned)
                max_admin_requests=max(max_admin_requests,last_activity['admin_active']+last_activity['admin_waiting'])
                suspicious=bool(last_activity['unknown_request_ids'])and time.perf_counter()-started>5
                overlap_samples=overlap_samples+1 if suspicious else 0
                if state.get('loaded_count',1)>1 or last_activity['foreign_models']or overlap_samples>=2:
                    conflict=True;error='Another model or unowned inference request detected';stop_own_process(process);break
                time.sleep(1)
        finally:
            stop_own_process(process)
    elapsed=time.perf_counter()-started
    events=read_jsonl(directory/'pi-events.jsonl');audit=read_jsonl(directory/'provider-audit.jsonl')
    if not conflict:
        conflict=any((m.get('loaded')or m.get('is_loading'))and m['id']!=model and not helper_reason(m)for m in client.models())
    if conflict:
        return {'conflict':True,'model':model,'task':task['id'],'repetition':repetition,'directory':str(directory),'error':error,'e2e_s':elapsed,'activity':last_activity}
    if process.returncode and not error:error=f'Pi exit code {process.returncode}'
    messages=[e['message']for e in events if e.get('type')=='message_end'and e.get('message',{}).get('role')=='assistant']
    model_errors=[m.get('errorMessage',m.get('stopReason'))for m in messages if m.get('stopReason')in('error','aborted','length')]
    if model_errors and not error:error='; '.join(str(x)for x in model_errors)
    if not any(e.get('type')=='agent_settled'for e in events)and not error:error='Pi did not settle normally'
    verification=verify_task(task['id'],work,setup,events)
    final='\n'.join(c.get('text','')for m in messages for c in m.get('content',[])if c.get('type')=='text')
    (directory/'final.txt').write_text(final+'\n')
    (directory/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
    row={'model':model,'task':task['id'],'category':task['category'],'repetition':repetition,
         'e2e_s':elapsed,'directory':str(directory),'error':error,'timed_out':timed_out,
         'exit_code':process.returncode,'max_admin_request_count':max_admin_requests,'last_activity':last_activity,**metrics_from_audit(audit,events),**verification}
    row['passed']=row['passed']and not error
    return classify_checks(row)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--resume',type=Path);parser.add_argument('--only',nargs='+')
    parser.add_argument('--output-dir',type=Path)
    parser.add_argument('--repeats',type=int,default=1)
    parser.add_argument('--reasoning-resume',type=Path,help='Finish the earlier reasoning suite one selected model at a time before its Pi tasks')
    args=parser.parse_args()
    local=json.loads((Path.home()/'.omlx/settings.json').read_text());key=local.get('auth',{}).get('api_key','')
    client=Client('http://127.0.0.1:8000',key)
    if args.resume and args.output_dir:parser.error('Choose --resume or --output-dir')
    directory=args.resume or args.output_dir or HERE/('pi-agent-'+datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
    if args.resume:
        manifest=json.loads((directory/'manifest.json').read_text());rows=read_jsonl(directory/'raw-results.jsonl')
    else:
        directory.mkdir();models=[m for m in client.models()if not helper_reason(m)and(not args.only or m['id']in args.only)]
        manifest={'created_at':datetime.now().isoformat(),'models':models,'repeats':args.repeats,
                  'pi_version':subprocess.check_output(['pi','--version'],text=True).strip(),
                  'load_seconds':{},'suite_seconds':{},'model_errors':{},'tasks':TASKS}
        rows=[]
    config=directory/'agent-config';config.mkdir(exist_ok=True)
    model_defs=[{'id':m['id'],'reasoning':True,'input':['text'],'contextWindow':65536,'maxTokens':3072,
                 'compat':{'supportsStore':False,'supportsDeveloperRole':False,'supportsReasoningEffort':True,
                           'maxTokensField':'max_tokens','thinkingFormat':'qwen-chat-template',
                           'thinkingTokenBudgetField':'thinking_budget'},
                 'samplingParams':{'temperature':0.6,'top_p':0.95,'top_k':20,'max_tokens':3072,
                                   'thinking_budget':1024,'reasoning_effort':'medium',
                                   'seed':27000,'chat_template_kwargs':reasoning.native_template_kwargs(m,'on')}}for m in manifest['models']]
    for definition in model_defs:
        if 'reasoning_strength'in definition['samplingParams']['chat_template_kwargs'] or 'gemma'in definition['id'].lower():
            definition['compat']['thinkingFormat']='chat-template'
            definition['compat']['chatTemplateKwargs']=definition['samplingParams']['chat_template_kwargs']
    (config/'models.json').write_text(json.dumps({'providers':{'omlx-benchmark':{'api':'openai-completions',
         'baseUrl':'http://127.0.0.1:8000/v1','apiKey':'$PI_BENCHMARK_API_KEY','authHeader':True,'models':model_defs}}},indent=2)+'\n')
    (config/'settings.json').write_text(json.dumps({'thinkingBudgets':{'medium':1024},'compaction':{'enabled':False},
          'retry':{'enabled':False,'provider':{'maxRetries':0,'timeoutMs':420000}},'cacheWarming':'off',
          'packages':[],'extensions':[],'quietStartup':True},indent=2)+'\n')
    done={(r['model'],r['task'],r['repetition'])for r in rows}
    outputs(directory,rows,manifest)
    print('PI RESULTS '+str(directory),flush=True)
    for original in manifest['models']:
        model=original['id']
        if args.only and model not in args.only:continue
        if all((model,t['id'],r)in done for t in TASKS for r in range(1,args.repeats+1)):continue
        if args.reasoning_resume:
            cmd=[sys.executable,'-u',str(HERE/'reasoning_benchmark.py'),'--resume',str(args.reasoning_resume),
                 '--repeats','3','--thinking','on','--thinking-budget','1024','--max-tokens','1536','--only',model]
            subprocess.run(cmd,check=True)
        reasoning.wait_idle(client);reasoning.unload_all_chat_models(client)
        info=next(m for m in client.models()if m['id']==model)
        force=bool(info.get('settings',{}).get('force_sampling',False));started=time.perf_counter()
        print('PI MODEL START '+model,flush=True)
        try:
            if force:client.json(model_url(model,'settings'),{'force_sampling':False},method='PUT')
            tick=time.perf_counter();client.json(model_url(model,'load'),{},timeout=600)
            manifest['load_seconds'][model]=time.perf_counter()-tick
            # Shared per-model warmup, outside task E2E. Also warms tool-free kernels.
            reasoning.complete(client,model,'What is 1+1? Finish with FINAL: and the number.','on',123,max_tokens=128,thinking_budget=64)
            base=directory/('model-'+str(manifest['models'].index(original)+1));base.mkdir(exist_ok=True)
            for repeat in range(1,args.repeats+1):
                for task in TASKS:
                    if(model,task['id'],repeat)in done:continue
                    for attempt in range(3):
                        reasoning.wait_idle(client)
                        for other in client.models():
                            if other.get('loaded')and other['id']!=model and not helper_reason(other):reasoning.unload_one_model(client,other['id'])
                        if not next(m for m in client.models()if m['id']==model).get('loaded'):
                            client.json(model_url(model,'load'),{},timeout=600)
                        # Different task seeds, matched between models; same task repeats get distinct seeds.
                        settings=json.loads((config/'models.json').read_text())
                        for md in settings['providers']['omlx-benchmark']['models']:
                            md['samplingParams']['seed']=27000+TASKS.index(task)*100+repeat
                        (config/'models.json').write_text(json.dumps(settings,indent=2)+'\n')
                        row=run_task(client,model,task,repeat,base,config,key)
                        if not row.get('conflict'):break
                        with(directory/'isolation-events.jsonl').open('a')as f:f.write(json.dumps(row)+'\n')
                        print('PI ISOLATION WAIT '+model+' / '+task['id'],flush=True)
                        reasoning.unload_one_model(client,model)
                    else:raise reasoning.BenchmarkPaused('Repeated external activity interrupted Pi task; resume after other inference is idle')
                    rows.append(row);done.add((model,task['id'],repeat))
                    with(directory/'raw-results.jsonl').open('a')as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
                    outputs(directory,rows,manifest)
                    print(f"PI {model} | {task['id']} | run {repeat} | passed={row['passed']} | checks={row['checks_passed']}/{row['checks_total']} | E2E={row['e2e_s']:.2f}s | input={row['input_tps']} output={row['output_tps']} | tools={row['tool_calls']} errors={row['tool_errors']} | {row['error']}",flush=True)
        except Exception as exc:
            manifest['model_errors'][model]=str(exc);print('PI MODEL ERROR '+model+': '+str(exc),flush=True)
        finally:
            if force:client.json(model_url(model,'settings'),{'force_sampling':True},method='PUT')
            reasoning.unload_one_model(client,model)
            manifest['suite_seconds'][model]=time.perf_counter()-started
            outputs(directory,rows,manifest)
        print('PI MODEL DONE '+model,flush=True)
        if all((model,t['id'],r)in done for t in TASKS for r in range(1,args.repeats+1)):
            manifest['model_errors'].pop(model,None)
    manifest['last_run_finished_at']=datetime.now().isoformat()
    if len(rows)==len(manifest['models'])*len(TASKS)*args.repeats:
        manifest['finished_at']=datetime.now().isoformat()
    outputs(directory,rows,manifest)
    print('PI COMPLETE '+str(directory/'report.md'),flush=True)

if __name__=='__main__':main()
