#!/usr/bin/env python3
"""Saved-evidence-only audit; never run model code or query cloud services."""
import argparse
import hashlib
import json
import math
import stat
from datetime import datetime
from pathlib import Path

import daily_ten_tasks as tasks
import pi_agent_benchmark as pi
from daily_readonly_broker import METHODS, SCHEMA_METHODS


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def audit(master):
    manifest = json.loads((master/'manifest.json').read_text())
    checks = []
    def check(name, passed, detail=None):
        checks.append({'name': name, 'passed': bool(passed), 'detail': detail})
    check('baseline artifacts unchanged', all(sha(x['path']) == x['sha256'] for x in json.loads((master/'baseline-integrity.json').read_text())))
    check('grader controls passed', json.loads((master/'grader-controls.json').read_text())['passed'])
    check('sandboxed Pi integration passed', json.loads((master/'integration-probe.json').read_text())['passed'])
    check('private master directory', stat.S_IMODE(master.stat().st_mode) == 0o700)
    all_rows, cli_calls, intervals = [], [], []
    old_pairs = {(r['model'], r['task']): r for r in pi.read_jsonl(Path(manifest['baseline_root'])/'raw-results.jsonl')}
    for stage in ['added', 'repeat']:
        root = master/stage
        check(stage+': OS/broker preflight passed', json.loads((root/'safety-preflight.json').read_text())['passed'])
        data = pi.read_jsonl(root/'raw-results.jsonl')
        scheduled = tasks.NEW_TASKS if stage == 'added' else tasks.TASKS
        expected = {(m['id'], t['id']) for m in manifest['models'] for t in scheduled}
        got = [(r['model'], r['task']) for r in data]
        check(stage+': unique pairs', len(got) == len(set(got)))
        check(stage+': all required pairs collected', set(got) == expected, {'collected': len(got), 'planned': len(expected)})
        all_rows.extend(data)
        for r in data:
            prefix = stage+'/'+r['model']+'/'+r['task']
            directory, work = Path(r['directory']), Path(r['directory'])/'work'
            provider = pi.read_jsonl(directory/'provider-audit.jsonl')
            cli, events = pi.read_jsonl(directory/'cli-audit/calls.jsonl'), pi.read_jsonl(directory/'pi-events.jsonl')
            cli_calls.extend(cli)
            names = ['CLI_GUIDE.md', 'answer.json']
            if r['task'] in tasks.SCRIPTS:
                names.append(tasks.SCRIPTS[r['task']])
            if r['task'] == 'mac_large_files':
                names.append('inventory.csv')
            if r['task'] == 'mac_duplicates':
                names.append('checksums.csv')
            if r['task'] == 'mac_backup_budget':
                names.append('candidate_inventory.csv')
            if r['task'] == 'frigate_log_triage':
                names += ['errors_by_component.csv', 'frigate-debug-redacted.log']
            immutable = json.loads((directory/'setup.json').read_text())
            sealed = tasks.seal_artifacts(r['task'], work, immutable)
            snapshot = json.loads((directory/'artifact-snapshot.json').read_text())
            safe = not sealed.is_symlink() and all(not (sealed/name).is_symlink() and stat.S_ISREG((sealed/name).lstat().st_mode) and sha(sealed/name) == info['sha256'] for name, info in snapshot['files'].items())
            check(prefix+': sealed ordinary artifacts and hashes', safe)
            check(prefix+': rejected artifacts cannot pass', not snapshot['rejected'] or not r['verified'])
            if safe:
                local = json.loads((directory/'local-reference-before.json').read_text()) if r['task'].startswith('mac_') else None
                replay = tasks.verify(r['task'], work, immutable, cli, events, root, local)
                check(prefix+': grading replay matches', all(replay[k] == r[k] for k in ['verified', 'answer', 'expected', 'checks_passed', 'checks_total', 'workflow_passed']) and [(c['name'], c['passed']) for c in replay['checks']] == [(c['name'], c['passed']) for c in r['checks']])
            check(prefix+': full pass definition', r['passed'] == (r['verified'] and not r['error']))
            check(prefix+': reference fingerprint', hashlib.sha256(json.dumps(r['expected'], sort_keys=True, ensure_ascii=False).encode()).hexdigest() == r['reference_hash'])
            check(prefix+': native metrics replay', all(math.isclose(r[k], value, rel_tol=1e-12) if isinstance(value, (int, float)) else r[k] == value for k, value in pi.metrics_from_audit(provider, events).items()))
            requests = [p['payload'] for p in provider if p.get('event') == 'request']
            seed = 41001+100*next(i for i, t in enumerate(tasks.TASKS) if t['id'] == r['task'])
            settings = {'model': r['model'], 'temperature': .6, 'top_p': .95, 'top_k': 20, 'seed': seed, 'max_tokens': 4096, 'thinking_budget': 1024}
            check(prefix+': matched sampling and request cap', 0 < len(requests) <= 12 and all(all(p.get(k) == v for k, v in settings.items()) for p in requests))
            command = json.loads((directory/'command.json').read_text())
            policy = (directory/'policy.sb').read_text()
            check(prefix+': actual sandbox-exec launch', command[:2] == ['/usr/bin/sandbox-exec', '-f'] and command[2] == str(directory/'policy.sb'))
            writes = [x for x in policy.splitlines() if x.startswith('(allow file-write')]
            check(prefix+': default-deny scratch-only writes', '(deny default)' in policy and writes == ['(allow file-write* (subpath '+json.dumps(str(work), ensure_ascii=False)+') (literal "/dev/null"))'])
            network = [x for x in policy.splitlines() if x.startswith('(allow network')]
            check(prefix+': only one loopback capability', len(network) == 1 and '(remote ip "localhost:' in network[0])
            check(prefix+': source journal hashes', all(sha(c[k+'_file']) == c[k+'_sha256'] for c in cli for k in ['stdout', 'stderr']))
            check(prefix+': source counters', r['source_calls'] == len(cli) and r['policy_denials'] == sum(c.get('policy_denied', False) for c in cli))
            task = next(t for t in tasks.TASKS if t['id'] == r['task'])
            from pi_daily_readonly_benchmark import SUFFIX
            check(prefix+': exact task prompt', (directory/'prompt.txt').read_text() == task['prompt']+SUFFIX+'\n')
            if r['task'] in {t['id'] for t in tasks.original.TASKS}:
                old = Path(old_pairs[(r['model'], r['task'])]['directory'])
                old_immutable = json.loads((old/'setup.json').read_text())
                check(prefix+': original-six prompt and initial guide identical', sha(directory/'prompt.txt') == sha(old/'prompt.txt') and immutable['CLI_GUIDE.md'] == old_immutable['CLI_GUIDE.md'])
            else:
                check(prefix+': additional initial guide identical', immutable['CLI_GUIDE.md'] == hashlib.sha256(tasks.NEW_GUIDE.encode()).hexdigest())
            intervals.append((directory.stat().st_birthtime, (directory/'verification.json').stat().st_birthtime, prefix))
    ordered = sorted(intervals)
    overlaps = [(a[2], b[2]) for a, b in zip(ordered, ordered[1:]) if a[1] > b[0]]
    check('scored trial lifetimes do not overlap', not overlaps, overlaps)
    dispatched = [c for c in cli_calls if c.get('dispatched') and c['service'] == 'gws']
    mutations = [c for c in dispatched if c.get('kind') not in ['help', 'schema'] and tuple(c['argv'][:3]) not in METHODS]
    check('zero Google mutation dispatches', not mutations)
    check('public schemas only', all(c['argv'][1] in SCHEMA_METHODS for c in dispatched if c.get('kind') == 'schema'))
    check('denied calls never dispatched', all(not c.get('dispatched') for c in cli_calls if c.get('policy_denied')))
    pairs = json.loads((master/'paired-comparison.json').read_text())
    added = pi.read_jsonl(master/'added/raw-results.jsonl')
    repeat = pi.read_jsonl(master/'repeat/raw-results.jsonl')
    first = {**old_pairs, **{(r['model'], r['task']): r for r in added}}
    second = {(r['model'], r['task']): r for r in repeat}
    check('paired comparison covers every collected repeat', len(pairs) == len(second))
    check('paired references and outcomes correct', all(p['same_expected_reference'] == (first[(p['model'], p['task'])]['expected'] == second[(p['model'], p['task'])]['expected']) and p['full_agrees'] == (first[(p['model'], p['task'])]['passed'] == second[(p['model'], p['task'])]['passed']) for p in pairs))
    result = {'audited_at': datetime.now().astimezone().isoformat(), 'mode': 'saved evidence only; no model code or cloud calls',
              'new_trials': len(all_rows), 'planned_new_trials': 140, 'verified': sum(r['verified'] for r in all_rows), 'full': sum(r['passed'] for r in all_rows),
              'google_mutation_dispatches': len(mutations), 'checks_passed': sum(c['passed'] for c in checks), 'checks_total': len(checks),
              'failed_checks': [c for c in checks if not c['passed']], 'checks': checks}
    (master/'audit-latest.json').write_text(json.dumps(result, indent=2)+'\n')
    if len(all_rows) == 140 and not result['failed_checks']:
        (master/'final-audit.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'checks'}, indent=2))
    return not result['failed_checks']


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    raise SystemExit(0 if audit(parser.parse_args().root.resolve()) else 1)
