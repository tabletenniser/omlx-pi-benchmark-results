"""macOS read-only host access for daily-task Pi benchmark processes."""
import json
from pathlib import Path

MEDIA_EXTENSIONS={'.jpg','.jpeg','.png','.mp4','.mov','.pdf','.csv'}
MEDIA_MAX_BYTES=10*1024*1024


def host_read_paths():
    paths=[Path.home()/'Downloads',Path.home()/'Movies']
    downloads=paths[0]
    if downloads.exists():
        for p in downloads.iterdir():
            if not p.is_symlink()and p.is_file()and p.suffix.lower()in MEDIA_EXTENSIONS and p.stat().st_size<=MEDIA_MAX_BYTES:paths.append(p)
    return paths


def profile(work, runtime, port, *, readable=()):
    work=Path(work).resolve();runtime=Path(runtime).resolve()
    roots=['/System','/usr','/bin','/sbin','/opt/homebrew','/private/etc','/private/var/db','/dev',str(Path.home()/'.pi/agent/install'),str(work),str(runtime)]
    q=lambda value:json.dumps(str(value),ensure_ascii=False)
    return '\n'.join([
        '(version 1)', '(deny default)',
        '(allow process-exec)', '(allow process-fork)',
        '(allow process-info* (target same-sandbox))',
        '(allow signal (target same-sandbox))', '(allow sysctl-read)',
        '(allow file-read-metadata)',
        '(allow file-read* (literal "/"))',
        '(allow file-read* '+ ' '.join('(subpath '+q(p)+')'for p in roots)+')',
        '(allow file-read* '+ ' '.join('(literal '+q(p)+')'for p in readable)+')'if readable else'',
        '(allow file-map-executable '+ ' '.join('(subpath '+q(p)+')'for p in roots)+')',
        '(allow file-write* (subpath '+q(work)+') (literal "/dev/null"))',
        '(allow network-outbound (remote ip "localhost:'+str(port)+'"))',
        '(allow mach-lookup (global-name "com.apple.system.logger") (global-name "com.apple.system.opendirectoryd.libinfo"))',
        '',
    ])
