#!/usr/bin/env python3
"""Explain saved outcomes and paired changes without inference or model execution."""
import argparse
import csv
import json
from datetime import datetime
from pathlib import Path

import pi_agent_benchmark as pi
import daily_ten_tasks as tasks


def status(row):
    return 'PASS' if row['passed'] else 'VERIFIED' if row['verified'] else 'FAIL'


def explain(row, note=None):
    if note:
        return note
    failed = [c['name'] for c in row['checks'] if not c['passed']]
    if row['verified']:
        return 'All required values, artifacts and source/program checks passed; normal completion failed: '+row['error']
    if 'answer.json is an object' in failed:
        return 'No valid required answer.json was delivered. Missing value checks are undelivered output, not independently demonstrated factual errors. '+(row['error'] or '')
    fragments = []
    execution = [x for x in failed if 'Python' in x or 'actual ' in x]
    if execution:
        fragments.append('Required execution/source checks failed: '+', '.join(execution)+'.')
    for name in failed:
        if name.startswith('complete ') and name.endswith('CSV'):
            fragments.append('The required complete CSV did not match its source-grounded contract.')
        elif name.startswith('correct '):
            key = name.removeprefix('correct ')
            expected, actual = row['expected'][key], row['answer'].get(key)
            if type(expected) != type(actual) and not (isinstance(expected, (int, float)) and isinstance(actual, (int, float))):
                fragments.append(key+': expected '+type(expected).__name__+', received '+type(actual).__name__+'.')
            elif not isinstance(expected, (dict, list)):
                # Scalar field names identify the issue without exposing account contents.
                fragments.append(key+': incorrect value.')
            else:
                fragments.append(key+': one or more nested values/order differ; see exact expected/actual evidence.')
    if row['error']:
        fragments.append('Completion error: '+row['error'])
    return ' '.join(fragments) or 'Failed checks: '+', '.join(failed)


def main(master):
    manifest = json.loads((master/'manifest.json').read_text())
    baseline = pi.read_jsonl(Path(manifest['baseline_root'])/'raw-results.jsonl')
    added = pi.read_jsonl(master/'added/raw-results.jsonl')
    repeated = pi.read_jsonl(master/'repeat/raw-results.jsonl')
    stamp = 'Snapshot: '+datetime.now().astimezone().isoformat()+f'; {len(added)}/40 added, {len(repeated)}/100 repeated trials.'
    notes = json.loads((master/'case-notes.json').read_text()) if (master/'case-notes.json').exists() else {}
    old_notes = json.loads((Path(manifest['baseline_root'])/'failure-notes.json').read_text())
    explanations = []
    text = ['# Explanations of new and repeated failures', '', stamp, '',
            'A strict question pass requires every requested artifact, value and execution check. These explanations retain the recorded scores. Full expected/actual JSON and tool logs remain in failures.md and the case directories.', '',
            '| Stage | Model | Question | Checks | Explanation |', '|---|---|---|---:|---|']
    for stage, rows in [('added', added), ('repeat', repeated)]:
        for row in rows:
            if row['passed']:
                continue
            reason = explain(row, notes.get(stage+'/'+row['model']+'/'+row['task']))
            explanations.append({'stage': stage, 'model': row['model'], 'task': row['task'], 'checks_passed': row['checks_passed'],
                                 'checks_total': row['checks_total'], 'explanation': reason, 'directory': row['directory']})
            text.append('| '+stage+' | '+row['model']+' | '+row['task']+' | '+str(row['checks_passed'])+'/'+str(row['checks_total'])+' | '+reason.replace('|', '\\|').replace('\n', ' ')+' |')
    text += ['', '[Full expected/actual values and replies](failures.md) · [Every tool transcript](raw-transcripts.md) · [Raw outcomes](task-outcomes.csv)', '']
    (master/'case-explanations.md').write_text('\n'.join(text))
    (master/'case-explanations.json').write_text(json.dumps(explanations, indent=2, ensure_ascii=False)+'\n')
    diagnostic = ['# Task diagnostics', '', stamp, '',
                  'These subtask checks explain the strict whole-question scores; they do not replace or alter them. A correct backup subset can coexist with incorrect candidate-population metadata. Correct free-minute totals can coexist with incorrect UTC meeting times.', '',
                  '| Stage | Model | Question | Value checks | Reporting/time checks | Whole status |',
                  '|---|---|---|---|---|---|']
    for stage, data in [('added', added), ('repeat', repeated)]:
        for row in data:
            a = row['answer'] if isinstance(row['answer'], dict) else {}
            e = row['expected']
            if row['task'] == 'mac_backup_budget':
                core = ['budget_bytes', 'chosen_paths', 'chosen_bytes', 'unused_bytes']
                count = sum(a.get(k) == e[k] for k in core)
                metadata = sum(a.get(k) == e[k] for k in ['candidate_count', 'candidate_total_bytes'])
                csv_pass = next(c['passed'] for c in row['checks'] if c['name'] == 'complete source-grounded candidate CSV')
                diagnostic.append(f"| {stage} | {row['model']} | Backup | {count}/4 optimal-subset values | {metadata}/2 candidate metadata; CSV={csv_pass} | {status(row)} |")
            elif row['task'] == 'gws_meeting_slots':
                actual_days = a.get('days', []) if isinstance(a.get('days'), list) else []
                daymap = {d.get('date'): d for d in actual_days if isinstance(d, dict)}
                totals = a.get('total_free_minutes') == e['total_free_minutes'] and len(actual_days) == len(e['days']) and all(daymap.get(d['date'], {}).get('busy_minutes') == d['busy_minutes'] and daymap.get(d['date'], {}).get('free_minutes') == d['free_minutes'] for d in e['days'])
                dates = a.get('days') == e['days']
                proposals = a.get('first_three_meetings') == e['first_three_meetings']
                diagnostic.append(f"| {stage} | {row['model']} | Meetings | Daily/total minutes correct={totals} | All interval fields={dates}; UTC proposals={proposals} | {status(row)} |")
    diagnostic += ['', '[Strict scores and complete matrix](report.md) · [Exact field differences](failures.md)', '']
    (master/'task-diagnostics.md').write_text('\n'.join(diagnostic))
    first = {(r['model'], r['task']): r for r in baseline+added}
    second = {(r['model'], r['task']): r for r in repeated}
    matrix = ['# Question matrix: expanded baseline → fresh repeat', '', stamp, '',
              'P = full pass; V = all task checks verified but completion limit/error; F = failed task checks; — = not collected. Bold pairs changed status. The first six baseline observations are the original recorded trials; questions7–10 are the additions.', '',
              '| Model | '+' | '.join('Q'+str(i) for i in range(1, 11))+' |',
              '|---|'+'---:|'*10]
    short = lambda row: 'P' if row['passed'] else 'V' if row['verified'] else 'F'
    for model in manifest['models']:
        cells = []
        for task in tasks.TASKS:
            a, b = first.get((model['id'], task['id'])), second.get((model['id'], task['id']))
            cell = (short(a) if a else '—')+'→'+(short(b) if b else '—')
            if a and b and short(a) != short(b):
                cell = '**'+cell+'**'
            cells.append(cell)
        matrix.append('| '+model['id']+' | '+' | '.join(cells)+' |')
    matrix += ['', 'Question key:', '']+[str(i)+'. '+t['id']+' — '+t['category'] for i, t in enumerate(tasks.TASKS, 1)]
    matrix += ['', '[Exact prompts](questions.md) · [Paired change explanations](replication-findings.md) · [Raw results](task-outcomes.csv)', '']
    (master/'question-matrix.md').write_text('\n'.join(matrix))
    original_ids = {t['id'] for t in tasks.original.TASKS}
    comparisons = []
    flips = ['# Paired reproducibility findings', '', stamp, '',
             'Comparison uses the same ten questions. Expected-value changes are reported separately from outcome changes. Required answer values exclude unrequested extra keys. Different failed checks can be hidden by an unchanged total score.', '']
    for row in repeated:
        old = first[(row['model'], row['task'])]
        old_failed = sorted(c['name'] for c in old['checks'] if not c['passed'])
        new_failed = sorted(c['name'] for c in row['checks'] if not c['passed'])
        changed_reference = sorted(k for k in set(old['expected']) | set(row['expected']) if old['expected'].get(k) != row['expected'].get(k))
        old_answer = old['answer'] if isinstance(old['answer'], dict) else {}
        new_answer = row['answer'] if isinstance(row['answer'], dict) else {}
        keys = set(old['expected']) | set(row['expected'])
        values_equal = all(old_answer.get(k) == new_answer.get(k) for k in keys)
        record = {'model': row['model'], 'task': row['task'], 'subset': 'original6' if row['task'] in original_ids else 'added4',
                  'first_status': status(old), 'repeat_status': status(row), 'same_expected_reference': not changed_reference,
                  'changed_reference_fields_json': json.dumps(changed_reference), 'required_answer_values_equal': values_equal,
                  'first_failed_checks_json': json.dumps(old_failed), 'repeat_failed_checks_json': json.dumps(new_failed),
                  'fixed_checks_json': json.dumps(sorted(set(old_failed)-set(new_failed))),
                  'regressed_checks_json': json.dumps(sorted(set(new_failed)-set(old_failed))),
                  'first_error': old['error'], 'repeat_error': row['error'],
                  'first_e2e_s': old['e2e_s'], 'repeat_e2e_s': row['e2e_s'],
                  'first_directory': old['directory'], 'repeat_directory': row['directory']}
        comparisons.append(record)
        if status(old) != status(row) or old_failed != new_failed:
            baseline_note = old_notes.get(old['model']+'/'+old['task']) if row['task'] in original_ids else notes.get('added/'+old['model']+'/'+old['task'])
            repeat_note = notes.get('repeat/'+row['model']+'/'+row['task'])
            flips += ['## '+row['model']+' / '+row['task'], '',
                      'First: '+status(old)+'; repeat: '+status(row)+'. Expected reference changed: '+(', '.join(changed_reference) or 'no')+'.', '',
                      'First outcome: '+('All task checks and normal completion passed.' if old['passed'] else explain(old, baseline_note)), '',
                      'Repeat outcome: '+('All task checks and normal completion passed.' if row['passed'] else explain(row, repeat_note)), '',
                      'Fixed checks: '+(', '.join(sorted(set(old_failed)-set(new_failed))) or 'none')+'.', '',
                      'Regressed checks: '+(', '.join(sorted(set(new_failed)-set(old_failed))) or 'none')+'.', '']
    (master/'replication-findings.md').write_text('\n'.join(flips))
    if comparisons:
        with (master/'comparison-details.csv').open('w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=list(comparisons[0]))
            writer.writeheader()
            writer.writerows(comparisons)
    print(json.dumps({'failure_explanations': len(explanations), 'paired_cases': len(comparisons),
                      'status_flips': sum(x['first_status'] != x['repeat_status'] for x in comparisons),
                      'changed_references': sum(not x['same_expected_reference'] for x in comparisons)}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    main(parser.parse_args().root.resolve())
