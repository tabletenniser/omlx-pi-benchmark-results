"""Trusted loopback proxy: model inference and allowlisted read-only CLI calls."""
import hashlib
import http.server
import json
import os
import secrets
import signal
import socket
import subprocess
import threading
import time
import urllib.error
import urllib.request
import uuid
from datetime import datetime, timezone
from pathlib import Path

from daily_readonly_sources import read_home

METHODS={
    ('drive','about','get'):{'fields'},
    ('drive','files','list'):{'q','pageSize','pageToken','orderBy','fields','spaces'},
    ('calendar','calendarList','list'):{'maxResults','pageToken','fields','showHidden','showDeleted'},
    ('calendar','events','list'):{'calendarId','timeMin','timeMax','singleEvents','orderBy','maxResults','pageToken','fields','showDeleted'},
}
SCHEMA_METHODS={'.'.join(k)for k in METHODS}


def validate_gws(argv):
    if not isinstance(argv,list)or not all(isinstance(x,str)and len(x)<20000 for x in argv):raise ValueError('Invalid CLI argument array.')
    if argv in [['--help'],['--version']]:return {'kind':'help'}
    if len(argv)==2 and argv[0]=='schema'and argv[1]in SCHEMA_METHODS:return {'kind':'schema','schema':argv[1]}
    method=tuple(argv[:3])
    if method not in METHODS:raise ValueError('Read-only broker: only Drive about.get/files.list and Calendar calendarList.list/events.list are allowed. Mutations, auth, shell, upload and other services are blocked.')
    rest=argv[3:];params={}
    while rest:
        if len(rest)<2:raise ValueError('Flags require values.')
        flag,value,*rest=rest
        if flag=='--params':
            if params:raise ValueError('Only one params object is allowed.')
            params=json.loads(value)
            if not isinstance(params,dict):raise ValueError('params must be an object.')
        elif flag=='--format'and value=='json':pass
        else:raise ValueError('Only --params and --format json are allowed. No output/upload/body/auth/config flags.')
    if set(params)-METHODS[method]:raise ValueError('Unsupported parameters: '+','.join(sorted(set(params)-METHODS[method])))
    if len(json.dumps(params))>24000:raise ValueError('Parameters exceed limit.')
    for k,v in params.items():
        if isinstance(v,(dict,list))or v is None:raise ValueError('Parameters must be scalar.')
        if k in('pageSize','maxResults')and(not isinstance(v,int)or not 1<=v<=100):raise ValueError('Page sizes must be between 1 and 100.')
    return {'kind':'data','method':'.'.join(method),'params':params}


class Broker:
    def __init__(self,root,key,client):
        self.root=Path(root);self.key=key;self.client=client;self.token=secrets.token_urlsafe(32)
        self.directory=None;self.model=None;self.count=0;self.cli_count=0
        self.lock=threading.RLock();self.inference_lock=threading.Lock();self.cli_lock=threading.Lock()
        self.closing=threading.Event();self.current_cli=None;self.responses=set()
        self.expected_sampling={}
        owner=self
        class Handler(http.server.BaseHTTPRequestHandler):
            def log_message(self,*args):pass
            def do_POST(self):owner.handle(self)
            def do_GET(self):self.send_error(405,'Use the documented CLI wrapper.')
            def do_DELETE(self):self.send_error(405,'Read-only proxy.')
            def do_PUT(self):self.send_error(405,'Read-only proxy.')
            def do_PATCH(self):self.send_error(405,'Read-only proxy.')
            def do_CONNECT(self):self.send_error(405,'Tunneling is forbidden.')
        self.server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);self.server.daemon_threads=True
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.port=self.server.server_address[1]

    def close(self):
        self.closing.set();self.server.shutdown()
        process=self.current_cli
        if process is not None and process.poll()is None:
            try:os.killpg(process.pid,signal.SIGTERM)
            except ProcessLookupError:pass
        with self.lock:responses=list(self.responses)
        for response in responses:
            try:response.fp.raw._sock.shutdown(socket.SHUT_RDWR)
            except (AttributeError,OSError):pass
        for lock in [self.cli_lock,self.inference_lock]:
            if not lock.acquire(timeout=15):raise RuntimeError('Read-only broker did not drain its owned operation; refusing to switch tasks.')
            lock.release()
        self.server.server_close();self.thread.join(timeout=3)

    def select(self,directory,model):
        with self.lock:
            self.directory=Path(directory);self.model=model;self.count=0;self.cli_count=0
            (self.directory/'cli-audit').mkdir(exist_ok=True)

    def append(self,name,row):
        with self.lock:
            with(self.directory/name).open('a')as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')

    def reply(self,h,status,data):
        raw=json.dumps(data,ensure_ascii=False).encode();h.send_response(status);h.send_header('Content-Type','application/json');h.send_header('Content-Length',str(len(raw)));h.end_headers();h.wfile.write(raw)

    def handle(self,h):
        if h.headers.get('Authorization')!='Bearer '+self.token:
            self.reply(h,403,{'error':'Invalid local benchmark capability.'});return
        try:
            size=int(h.headers.get('Content-Length','0'))
            if not 0<size<=4*1024*1024:raise ValueError('Invalid request size.')
            body=json.loads(h.rfile.read(size))
            if self.directory is None:raise ValueError('No active task.')
            if h.path=='/v1/chat/completions':self.inference(h,body)
            elif h.path=='/cli':self.cli(h,body)
            else:self.reply(h,403,{'error':'This endpoint is not exposed.'})
        except (BrokenPipeError,ConnectionResetError):pass
        except Exception as e:
            try:self.reply(h,400,{'error':str(e)})
            except (BrokenPipeError,ConnectionResetError):pass

    def inference(self,h,body):
        if body.get('model')!=self.model:self.reply(h,403,{'error':{'message':'Only the selected benchmark model is available.'}});return
        if any(body.get(k)!=v for k,v in self.expected_sampling.items()):
            self.reply(h,403,{'error':{'message':'Matched benchmark sampling parameters cannot be changed.'}});return
        for message in body.get('messages',[]):
            content=message.get('content')
            if content is None or isinstance(content,str):continue
            if not isinstance(content,list)or any(not isinstance(part,dict)or part.get('type')!='text'for part in content):
                self.reply(h,403,{'error':{'message':'Text-only benchmark: remote images, files, audio and other URL-fetching inputs are blocked.'}});return
        if int(body.get('max_tokens',4096))>4096 or int(body.get('thinking_budget',1024))>1024:
            self.reply(h,403,{'error':{'message':'Configured model output/thinking budgets cannot be exceeded.'}});return
        with self.inference_lock:
            with self.lock:self.count+=1;number=self.count
            stamp=lambda:datetime.now(timezone.utc).isoformat()
            if number>12:
                self.append('provider-audit.jsonl',{'event':'turn_limit','request':number,'time':stamp()})
                self.reply(h,429,{'error':{'message':'Benchmark limit: twelve model requests per task.'}});return
            started=time.perf_counter()
            self.append('provider-audit.jsonl',{'event':'request','request':number,'time':stamp(),'payload':body})
            request=urllib.request.Request('http://127.0.0.1:8000/v1/chat/completions',data=json.dumps(body).encode(),headers={'Content-Type':'application/json','Authorization':'Bearer '+self.key})
            try:
                with urllib.request.urlopen(request,timeout=610)as response:
                    with self.lock:self.responses.add(response)
                    rid=response.headers.get('x-omlx-request-id')
                    self.append('provider-audit.jsonl',{'event':'http_response','request':number,'time':stamp(),'status':response.status,'request_id':rid})
                    if rid:
                        with(self.directory/'provider-audit.jsonl.request-ids').open('a')as f:f.write(rid+'\n')
                    h.send_response(response.status);h.send_header('Content-Type',response.headers.get('Content-Type','text/event-stream'))
                    if rid:h.send_header('x-omlx-request-id',rid)
                    h.send_header('Connection','close');h.end_headers();h.close_connection=True
                    for line in response:
                        h.wfile.write(line);h.wfile.flush()
                        if line.startswith(b'data: '):
                            try:data=json.loads(line[6:])
                            except ValueError:continue
                            if data.get('usage')or data.get('error')or any(c.get('finish_reason')for c in data.get('choices',[])):
                                self.append('provider-audit.jsonl',{'event':'provider_metrics','request':number,'time':stamp(),'elapsed_ms':(time.perf_counter()-started)*1000,'data':data})
            except urllib.error.HTTPError as e:
                data=e.read();self.append('provider-audit.jsonl',{'event':'http_error','request':number,'status':e.code,'time':stamp()})
                h.send_response(e.code);h.send_header('Content-Type','application/json');h.end_headers();h.wfile.write(data)
            finally:
                with self.lock:self.responses={r for r in self.responses if not r.closed}

    def cli(self,h,body):
        service=body.get('service');argv=body.get('argv',[]);identifier=str(uuid.uuid4());started=time.perf_counter()
        row={'id':identifier,'service':service,'argv':argv,'started_at':time.time(),'cwd':str(self.directory/'work')}
        code=0;out='';err='';denied=False
        with self.cli_lock:
            try:
                if not isinstance(argv,list)or not all(isinstance(x,str)for x in argv):raise ValueError('Invalid arguments.')
                if service=='gws':
                    info=validate_gws(argv);row.update(info)
                    if self.cli_count>=12:raise ValueError('Twelve read-only source calls per task maximum.')
                    self.cli_count+=1
                    # This is the only Google dispatch. Validation happens first;
                    # no model-supplied program, URL, or shell runs in this process.
                    row['dispatched']=True
                    process=subprocess.Popen(['/opt/homebrew/bin/gws',*argv],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True);self.current_cli=process
                    try:out,err=process.communicate(timeout=120);code=process.returncode
                    except subprocess.TimeoutExpired:
                        os.killpg(process.pid,signal.SIGKILL);out,err=process.communicate();code=124;err+='\nRead-only source exceeded 120 seconds.\n'
                    finally:self.current_cli=None
                elif service=='home-read':
                    if argv==['--help']:out='home-read ha config | ha automations [--match TEXT] | frigate config\n'
                    else:
                        if self.cli_count>=12:raise ValueError('Twelve read-only source calls per task maximum.')
                        self.cli_count+=1;data=read_home(argv);row['source_path']=data['source_path'];out=json.dumps(data,indent=2)+'\n'
                    row['dispatched']=True
                else:raise ValueError('Only gws and home-read services exist.')
            except (ValueError,KeyError)as e:code=3;err=str(e)+'\n';denied=True;row['dispatched']=False
            except subprocess.TimeoutExpired:code=124;err='Read-only CLI exceeded 120 seconds.\n'
            except Exception as e:code=125;err=str(e)+'\n'
            base=self.directory/'cli-audit'/identifier
            for name,value in [('stdout',out),('stderr',err)]:
                file=base.with_suffix('.'+name);file.write_text(value);row[name+'_file']=str(file);row[name+'_sha256']=hashlib.sha256(file.read_bytes()).hexdigest()
            row.update(returncode=code,wall_s=time.perf_counter()-started,policy_denied=denied)
            self.append('cli-audit/calls.jsonl',row)
        self.reply(h,200,{'returncode':code,'stdout':out,'stderr':err})
