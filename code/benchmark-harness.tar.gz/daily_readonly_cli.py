#!/opt/homebrew/opt/python@3.14/bin/python3.14
"""Agent-side CLI client; execution of arbitrary code stays in the OS sandbox."""
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path


def main():
    name=Path(sys.argv[0]).name
    if name not in('gws','home-read'):raise SystemExit('Only gws and home-read wrappers are available.')
    request=urllib.request.Request(os.environ['DAILY_BROKER_URL']+'/cli',data=json.dumps({'service':name,'argv':sys.argv[1:]}).encode(),headers={'Content-Type':'application/json','Authorization':'Bearer '+os.environ['DAILY_READ_TOKEN']})
    try:
        with urllib.request.urlopen(request,timeout=125)as response:result=json.load(response)
        sys.stdout.write(result['stdout']);sys.stderr.write(result['stderr']);raise SystemExit(result['returncode'])
    except urllib.error.HTTPError as e:sys.stderr.write('Read-only broker rejected the request: '+str(e.code)+'\n');raise SystemExit(3)


if __name__=='__main__':main()
