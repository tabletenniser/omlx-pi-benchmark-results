#!/usr/bin/env python3
"""Audit saved daily-task evidence without running model code or cloud actions."""
import argparse
import hashlib
import json
import math
import stat
from datetime import datetime
from pathlib import Path

import daily_readonly_tasks as tasks
import pi_agent_benchmark as pi
from daily_readonly_broker import METHODS,SCHEMA_METHODS


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def audit(root):
    manifest=json.loads((root/'manifest.json').read_text());data=pi.read_jsonl(root/'raw-results.jsonl');checks=[]
    def check(name,passed,detail=None):checks.append({'name':name,'passed':bool(passed),'detail':detail})
    pairs=[(r['model'],r['task'])for r in data];expected={(m['id'],t['id'])for m in manifest['models']for t in tasks.TASKS}
    check('unique scored pairs',len(pairs)==len(set(pairs)))
    check('all60 required scored pairs collected',set(pairs)==expected,{'collected':len(pairs),'pending':len(expected-set(pairs))})
    check('OS/broker safety preflight passed',json.loads((root/'safety-preflight.json').read_text())['passed'])
    check('actual sandboxed Pi integration passed',json.loads((root/'integration-probe.json').read_text())['passed'])
    source_calls=[];prompts={}
    for r in data:
        d=Path(r['directory']);w=d/'work';prefix=r['model']+'/'+r['task'];cli=pi.read_jsonl(d/'cli-audit/calls.jsonl');events=pi.read_jsonl(d/'pi-events.jsonl');provider=pi.read_jsonl(d/'provider-audit.jsonl');source_calls.extend(cli)
        check(prefix+': work directory is not a symlink',not w.is_symlink()and w.is_dir())
        names=['CLI_GUIDE.md','answer.json']+(['calendar-window.json']if r['task']=='gws_calendar_conflicts'else[])+(['inventory.csv']if r['task']=='mac_large_files'else['checksums.csv']if r['task']=='mac_duplicates'else[])
        safe=not w.is_symlink()and all(not(w/name).is_symlink()and stat.S_ISREG((w/name).lstat().st_mode)for name in names if(w/name).exists()or(w/name).is_symlink())
        check(prefix+': model artifacts are ordinary scratch files',safe)
        if safe:
            immutable=json.loads((d/'setup.json').read_text());local=json.loads((d/'local-reference-before.json').read_text())if r['task'].startswith('mac_')else None
            replay=tasks.verify(r['task'],w,immutable,cli,events,root,local)
            check(prefix+': saved-evidence grading reproduces original verdict',replay['verified']==r['verified']and replay['expected']==r['expected']and replay['answer']==r['answer']and[(c['name'],c['passed'])for c in replay['checks']]==[(c['name'],c['passed'])for c in r['checks']])
        check(prefix+': full pass definition',r['passed']==(r['verified']and not r['error']))
        check(prefix+': verifier counts',r['checks_passed']==sum(c['passed']for c in r['checks'])and r['checks_total']==len(r['checks']))
        check(prefix+': native metrics reproduce',all(math.isclose(r[k],v,rel_tol=1e-12)if isinstance(v,(int,float))else r[k]==v for k,v in pi.metrics_from_audit(provider,events).items()))
        task=next(t for t in tasks.TASKS if t['id']==r['task']);seed=41001+100*tasks.TASKS.index(task)
        requests=[p['payload']for p in provider if p.get('event')=='request']
        matched={'model':r['model'],'temperature':.6,'top_p':.95,'top_k':20,'seed':seed,'max_tokens':4096,'thinking_budget':1024}
        check(prefix+': matched provider settings',bool(requests)and all(all(p.get(k)==v for k,v in matched.items())for p in requests))
        check(prefix+': model request cap',len(requests)<=12)
        check(prefix+': CLI journal hashes intact',all(sha(c[k+'_file'])==c[k+'_sha256']for c in cli for k in ['stdout','stderr']))
        check(prefix+': source and denial counts',r['source_calls']==len(cli)and r['policy_denials']==sum(c.get('policy_denied',False)for c in cli))
        command=json.loads((d/'command.json').read_text());policy=(d/'policy.sb').read_text()
        check(prefix+': Pi actually launched through sandbox-exec',command[:2]==['/usr/bin/sandbox-exec','-f']and command[2]==str(d/'policy.sb'))
        expected_write='(allow file-write* (subpath '+json.dumps(str(w),ensure_ascii=False)+') (literal "/dev/null"))'
        write_rules=[line for line in policy.splitlines()if line.startswith('(allow file-write')]
        network_rules=[line for line in policy.splitlines()if line.startswith('(allow network')]
        check(prefix+': default-deny scratch-only write policy', '(deny default)'in policy and write_rules==[expected_write])
        check(prefix+': only one loopback outbound capability',len(network_rules)==1 and'(remote ip "localhost:'in network_rules[0])
        prompts.setdefault(r['task'],set()).add(sha(d/'prompt.txt'))
    check('identical prompt per task across models',all(len(v)==1 for v in prompts.values()),{k:len(v)for k,v in prompts.items()})
    dispatched=[c for c in source_calls if c.get('dispatched')]
    check('only read-only Google methods dispatched',all(c.get('kind')in('help','schema')or tuple(c['argv'][:3])in METHODS for c in dispatched if c['service']=='gws'))
    check('only allowed public schemas exposed',all(c['argv'][1]in SCHEMA_METHODS for c in dispatched if c['service']=='gws'and c.get('kind')=='schema'))
    check('denied source requests never dispatched',all(not c.get('dispatched')for c in source_calls if c.get('policy_denied')))
    baseline=json.loads((root/'previous-suite-integrity.json').read_text());check('previous benchmark suite remains unchanged',all(sha(p['path'])==p['sha256']for p in baseline))
    result={'audited_at':datetime.now().astimezone().isoformat(),'mode':'saved evidence only; no model code, cloud mutation, or new model inference','status':manifest['status'],'scored_trials':len(data),'planned_trials':60,'models_with_results':len({r['model']for r in data}),'verified':sum(r['verified']for r in data),'full':sum(r['passed']for r in data),'source_calls':len(source_calls),'policy_denials':sum(c.get('policy_denied',False)for c in source_calls),'google_mutation_dispatches':0 if all(c.get('kind')in('help','schema')or tuple(c['argv'][:3])in METHODS for c in dispatched if c['service']=='gws')else None,'checks_passed':sum(c['passed']for c in checks),'checks_total':len(checks),'failed_checks':[c for c in checks if not c['passed']],'checks':checks}
    (root/'audit-latest.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    if len(data)==60:(root/'final-audit.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({k:v for k,v in result.items()if k!='checks'},indent=2))
    return not result['failed_checks']


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);raise SystemExit(0 if audit(p.parse_args().root.resolve())else 1)
