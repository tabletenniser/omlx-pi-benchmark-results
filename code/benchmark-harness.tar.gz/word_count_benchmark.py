#!/usr/bin/env python3
"""Sequential word-count compliance test of all standalone oMLX chat models."""

import argparse
import csv
import json
import os
import statistics
import time
from datetime import datetime
from pathlib import Path

from qwen38_mtp_benchmark import Client, model_url

EXTRA_REPO = "Youssofal/Qwen3.8-27B-MTPLX-Optimized-Speed"
EXTRA_MODEL = EXTRA_REPO.split("/")[1]
COUNTS = tuple(range(4, 10))
CSV_FIELDS = ["model", "requested_words", "repetition", "prompt", "response", "actual_words", "passed", "finish_reason", "wall_s", "visible_ttft_s", "decode_tps", "completion_tokens", "reasoning", "error"]


def score(response, requested, finish_reason, error=""):
    words = len(response.strip().split())
    return words, not error and finish_reason == "stop" and words == requested


def helper_reason(model):
    path = Path(model["model_path"]) / "config.json"
    config = json.loads(path.read_text()) if path.exists() else {}
    kind = config.get("model_type", "")
    if kind.endswith("_mtp") or "assistant" in kind or model.get("is_helper"):
        return "MTP/assistant drafter only; not a standalone chat model"
    if model.get("model_type") not in {"llm", "vlm"}:
        return "Not a chat/text-generation model"
    return None


def model_summary(rows, model):
    selected = [r for r in rows if r["model"] == model]
    out = {"model": model, "attempted": len(selected), "passed": sum(r["passed"] for r in selected), "errors": sum(bool(r["error"]) for r in selected)}
    out["pass_rate"] = out["passed"] / len(selected) if selected else None
    times = [r["wall_s"] for r in selected if r["wall_s"] is not None and not r["error"]]
    out["median_wall_s"] = statistics.median(times) if times else None
    for n in COUNTS:
        group = [r for r in selected if r["requested_words"] == n]
        out[f"words_{n}_passed"] = sum(r["passed"] for r in group)
        out[f"words_{n}_attempted"] = len(group)
    return out


def write_outputs(directory, rows, manifest):
    models = list(dict.fromkeys([m["id"] for m in manifest["models"]] + [r["model"] for r in rows]))
    summaries = [model_summary(rows, model) for model in models]
    (directory / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
    with (directory / "raw-results.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    with (directory / "summary.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(summaries[0]) if summaries else ["model"])
        writer.writeheader()
        writer.writerows(summaries)
    lines = ["# Sequential word-count benchmark", "", "Exact user prompt: `great me in exactly N words`, with N = 4, 5, 6, 7, 8, 9. Ten sampled runs at each count, 60 replies per model. The spelling `great` is intentional and is preserved from the request.", "", "One model block and one inference request at a time. No system prompt or extra greeting instruction. Thinking disabled; temperature 0.7, top_p 0.8, top_k 20; max_tokens 64. Existing speculative-decoding settings are retained. A force-sampling override, if enabled, is temporarily disabled and restored afterward.", "", "PASS means the visible reply has exactly N whitespace-separated words and finishes normally. This is a word-count test, not a semantic greeting-quality assessment: a refusal or irrelevant reply can meet the count. Every reply is available verbatim below and in `raw-results.csv` and `raw-results.jsonl`.", "", "| Model | 4 words | 5 words | 6 words | 7 words | 8 words | 9 words | Total | Errors |", "|---|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for s in sorted(summaries, key=lambda s: (-(s["pass_rate"] or 0), s["model"])):
        cells = [f"{s[f'words_{n}_passed']}/{s[f'words_{n}_attempted']}" for n in COUNTS]
        lines.append("| " + " | ".join([s["model"], *cells, f"{s['passed']}/{s['attempted']}", str(s["errors"])]) + " |")
    if manifest.get("excluded"):
        lines += ["", "Excluded resources:"]
        lines += [f"- {m['id']}: {m['reason']}." for m in manifest["excluded"]]
    if manifest.get("model_errors"):
        lines += ["", "Model errors:"]
        lines += [f"- {name}: {error}" for name, error in manifest["model_errors"].items()]
    lines += ["", "## Raw replies", ""]
    for model in models:
        lines += ["### " + model, ""]
        for row in (r for r in rows if r["model"] == model):
            status = "PASS" if row["passed"] else "FAIL"
            lines += [f"Requested {row['requested_words']}; repetition {row['repetition']}/10; counted {row['actual_words']}; **{status}**; finish={row['finish_reason']}; error={row['error'] or 'none'}", ""]
            fence = "`" * max(4, max((len(x) for x in row["response"].split() if set(x) == {"`"}), default=0) + 1)
            lines += [fence + "text", row["response"], fence, ""]
    (directory / "raw-results.md").write_text("\n".join(lines))
    (directory / "summary.json").write_text(json.dumps(summaries, indent=2) + "\n")
    return summaries


def run_model(client, model, directory, rows, manifest, repeats):
    name = model["id"]
    info = next(m for m in client.models() if m["id"] == name)
    original_force = bool(info.get("settings", {}).get("force_sampling", False))
    manifest.setdefault("effective_model_settings", {})[name] = info.get("settings", {})
    print(f"MODEL START {name}: {repeats * len(COUNTS)} requests", flush=True)
    try:
        if original_force:
            client.json(model_url(name, "settings"), {"force_sampling": False}, method="PUT")
        client.json(model_url(name, "load"), {}, timeout=600)
        client.complete(name, "Reply with the single word ready.", 16)
        consecutive_errors = 0
        for repetition in range(1, repeats + 1):
            for n in COUNTS:
                prompt = f"great me in exactly {n} words"
                row = {"model": name, "requested_words": n, "repetition": repetition, "prompt": prompt, "response": "", "reasoning": "", "finish_reason": None, "wall_s": None, "visible_ttft_s": None, "decode_tps": None, "completion_tokens": None, "error": ""}
                started = time.perf_counter()
                try:
                    row.update(client.complete(name, prompt, 64))
                    consecutive_errors = 0
                except Exception as exc:
                    row["error"] = str(exc)
                    row["wall_s"] = time.perf_counter() - started
                    consecutive_errors += 1
                row["actual_words"], row["passed"] = score(row["response"], n, row["finish_reason"], row["error"])
                rows.append(row)
                with (directory / "raw-results.jsonl").open("a") as f:
                    f.write(json.dumps(row, ensure_ascii=False) + "\n")
                if consecutive_errors >= 3:
                    raise RuntimeError("Three consecutive inference errors; stopped this model. " + row["error"])
            s = model_summary(rows, name)
            print(f"{name} | round {repetition}/{repeats} | {s['passed']}/{s['attempted']} passed | errors={s['errors']}", flush=True)
            write_outputs(directory, rows, manifest)
    except Exception as exc:
        manifest.setdefault("model_errors", {})[name] = str(exc)
        print(f"MODEL ERROR {name}: {exc}", flush=True)
    finally:
        if original_force:
            client.json(model_url(name, "settings"), {"force_sampling": True}, method="PUT")
        # Avoid aborting somebody else's request if a client has become active.
        activity = client.json("/admin/api/activity")["active_models"]
        info = next((m for m in client.models() if m["id"] == name), {})
        if info.get("loaded") and not activity.get("total_active_requests") and not activity.get("total_waiting_requests"):
            client.json(model_url(name, "unload"), {})
        write_outputs(directory, rows, manifest)


def wait_for_extra(client):
    deadline = time.monotonic() + 4 * 3600
    while time.monotonic() < deadline:
        tasks = client.json("/admin/api/hf/tasks")["tasks"]
        tasks = [t for t in tasks if t["repo_id"].lower() == EXTRA_REPO.lower()]
        if not tasks:
            task = client.json("/admin/api/hf/download", {"repo_id": EXTRA_REPO})["task"]
        else:
            task = max(tasks, key=lambda t: t.get("created_at", 0))
        print(f"Youssofal download: {task['status']} {task.get('progress', 0):.1f}% ({task.get('downloaded_size', 0)/1e9:.2f}/{task.get('total_size', 0)/1e9:.2f} GB)", flush=True)
        if task["status"] == "completed":
            break
        if task["status"] in {"failed", "cancelled"}:
            raise RuntimeError(f"Extra model download {task['status']}: {task.get('error', '')}")
        time.sleep(10)
    else:
        raise RuntimeError("Extra model download timed out; it remains in oMLX.")
    for _ in range(20):
        model = next((m for m in client.models() if m["id"] == EXTRA_MODEL), None)
        if model:
            return model
        time.sleep(2)
    raise RuntimeError("The downloaded model has not appeared in oMLX's inventory.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repeats", type=int, default=10)
    parser.add_argument("--skip-extra", action="store_true")
    args = parser.parse_args()
    if args.repeats < 1:
        parser.error("--repeats must be positive")
    local = json.loads((Path.home() / ".omlx/settings.json").read_text())
    key = local.get("auth", {}).get("api_key") or os.environ.get("OMLX_API_KEY", "")
    client = Client("http://127.0.0.1:8000", key)
    inventory = client.models()
    models, excluded = [], []
    for model in inventory:
        if model["id"] == EXTRA_MODEL:
            continue
        reason = helper_reason(model)
        if reason:
            excluded.append({"id": model["id"], "reason": reason})
        else:
            models.append(model)
    directory = Path(__file__).resolve().parent / ("word-count-" + datetime.now().strftime("%Y%m%d-%H%M%S-%f"))
    directory.mkdir()
    manifest = {"created_at": datetime.now().isoformat(), "repetitions_per_word_count": args.repeats, "word_counts": COUNTS, "prompt_template": "great me in exactly {n} words", "temperature": 0.7, "top_p": 0.8, "top_k": 20, "max_tokens": 64, "thinking": False, "model_order": [m["id"] for m in models], "models": models, "excluded": excluded}
    rows = []
    write_outputs(directory, rows, manifest)
    print("Results directory: " + str(directory), flush=True)
    for model in models:
        run_model(client, model, directory, rows, manifest, args.repeats)
    if not args.skip_extra:
        try:
            model = wait_for_extra(client)
            imported = client.json(model_url(EXTRA_MODEL, "import-mtplx"), {}, timeout=120)
            (directory / "youssofal-import.json").write_text(json.dumps(imported, indent=2) + "\n")
            client.json(model_url(EXTRA_MODEL, "settings"), {"mtp_enabled": True, "dflash_enabled": False, "vlm_mtp_enabled": False}, method="PUT")
            model = next(m for m in client.models() if m["id"] == EXTRA_MODEL)
            manifest["models"].append(model)
            manifest["model_order"].append(EXTRA_MODEL)
            run_model(client, model, directory, rows, manifest, args.repeats)
        except Exception as exc:
            manifest.setdefault("model_errors", {})[EXTRA_MODEL] = str(exc)
            print("EXTRA MODEL ERROR: " + str(exc), flush=True)
    manifest["finished_at"] = datetime.now().isoformat()
    summary = write_outputs(directory, rows, manifest)
    for row in sorted(summary, key=lambda r: -(r["pass_rate"] or 0)):
        print(f"FINAL {row['model']}: {row['passed']}/{row['attempted']}, errors={row['errors']}", flush=True)
    print("Raw replies: " + str(directory / "raw-results.md"), flush=True)


if __name__ == "__main__":
    main()
