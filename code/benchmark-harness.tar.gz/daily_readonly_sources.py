"""Trusted read-only access to locally configured Home Assistant and Frigate."""
import json
import re
import subprocess
from pathlib import Path

HOME=Path.home()
PATHS={'ha-config':HOME/'homeassistant/config/configuration.yaml','ha-automations':HOME/'homeassistant/config/automations.yaml','frigate-config':HOME/'frigate/config/config.yml'}
YAML_PYTHON=str(HOME/'.venv/bin/python')


def redact(value,key=''):
    if re.search(r'password|passwd|secret|token|api.?key|private.?key|credential|authorization',key,re.I):return '[REDACTED]'
    if isinstance(value,dict):return {str(k):redact(v,str(k))for k,v in value.items()}
    if isinstance(value,list):return [redact(v)for v in value]
    if isinstance(value,str):
        value=re.sub(r'([a-zA-Z][a-zA-Z0-9+.-]*://)[^/\s@]+@',r'\1[REDACTED]@',value)
        value=re.sub(r'(?i)((?:access_token|auth_token|token|password|api_key|key|session)=)[^&#\s]+',r'\1[REDACTED]',value)
        value=re.sub(r'(?i)Bearer\s+[A-Za-z0-9._~+/-]+','Bearer [REDACTED]',value)
        value=re.sub(r'(?i)Basic\s+[A-Za-z0-9+/=]+','Basic [REDACTED]',value)
        value=re.sub(r'\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b','[REDACTED]',value)
        return value
    return value


def load_source(name):
    path=PATHS[name]
    code='''import json,sys,yaml
class Loader(yaml.SafeLoader):pass
def unknown(loader,tag,node):
    if isinstance(node,yaml.ScalarNode):return '!'+tag+' '+loader.construct_scalar(node)
    if isinstance(node,yaml.SequenceNode):return loader.construct_sequence(node)
    return loader.construct_mapping(node)
Loader.add_multi_constructor('!',unknown)
with open(sys.argv[1])as f:data=yaml.load(f,Loader=Loader)
print(json.dumps(data,default=str))
'''
    r=subprocess.run([YAML_PYTHON,'-B','-c',code,str(path)],capture_output=True,text=True,timeout=20,check=True)
    return redact(json.loads(r.stdout))


def read_home(argv):
    if argv==['ha','config']:name='ha-config';data=load_source(name)
    elif argv[:2]==['ha','automations']:
        name='ha-automations';data=load_source(name)
        if len(argv)==4 and argv[2]=='--match'and len(argv[3])<=100:
            data=[a for a in data if argv[3].casefold()in str(a.get('alias','')).casefold()]
        elif len(argv)!=2:raise ValueError('Use home-read ha automations [--match TEXT].')
    elif argv==['frigate','config']:name='frigate-config';data=load_source(name)
    else:raise ValueError('Only ha config, ha automations [--match TEXT], and frigate config are available. No service controls exist.')
    return {'source_path':str(PATHS[name]),'data':data}
