#!/usr/bin/env python3
"""Sequential reasoning, prefill, decode and end-to-end benchmark for oMLX."""

import argparse
import ast
import csv
import json
import math
import os
import re
import statistics
import threading
import time
import uuid
from collections import Counter
from datetime import datetime
from fractions import Fraction
from pathlib import Path

from qwen38_mtp_benchmark import Client, model_url, read_stream
from word_count_benchmark import helper_reason

HERE = Path(__file__).resolve().parent
ISOLATION_JOURNAL = None


class BenchmarkPaused(BaseException):
    """Stop without treating external traffic as a model-answer failure."""


class IsolationConflict(Exception):
    pass


def record_isolation_event(event):
    if ISOLATION_JOURNAL is not None:
        with ISOLATION_JOURNAL.open("a") as f:
            f.write(json.dumps({"time": datetime.now().isoformat(), **event}, ensure_ascii=False) + "\n")
SYSTEM = "Solve the problem carefully. Give at most two sentences of visible justification, then finish with a line beginning FINAL: and the requested answer."
FIELDS = ["model", "kind", "case_id", "mode", "repetition", "correct", "grading_note", "final_answer", "question", "response", "reasoning", "input_tokens", "cached_input_tokens", "computed_input_tokens", "input_tps", "output_tokens", "reasoning_tokens", "output_tps", "input_eval_s", "output_eval_s", "e2e_s", "first_visible_s", "server_ttft_s", "finish_reason", "truncated", "error", "seed"]


def final_text(response):
    matches = list(re.finditer(r"(?i)(?:\*\*)?\bFINAL(?:\s+ANSWER)?(?:\*\*)?\s*:\s*(?:\*\*)?", response))
    text = response[matches[-1].end():].strip() if matches else response.strip()
    text = re.sub(r"^```(?:json|python|text)?\s*", "", text)
    return re.sub(r"\s*```\s*$", "", text).strip().strip("`*$ ")


def evaluate_expression(text):
    text = text.strip().strip("`$").replace("×", "*").replace("÷", "/").replace("−", "-")
    if len(text) > 512:
        raise ValueError("Expression too long")
    tree = ast.parse(text, mode="eval")
    if sum(1 for _ in ast.walk(tree)) > 64:
        raise ValueError("Expression too large")
    leaves = []
    def visit(node):
        if isinstance(node, ast.Expression):
            return visit(node.body)
        if isinstance(node, ast.Constant) and type(node.value) in (int, float) and node.value in (3, 8):
            leaves.append(int(node.value))
            return Fraction(node.value)
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
            value = visit(node.operand)
            return -value if isinstance(node.op, ast.USub) else value
        if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Sub, ast.Mult, ast.Div)):
            left, right = visit(node.left), visit(node.right)
            if isinstance(node.op, ast.Add): return left + right
            if isinstance(node.op, ast.Sub): return left - right
            if isinstance(node.op, ast.Mult): return left * right
            return left / right
        raise ValueError("Only the supplied numbers and + - * / are allowed")
    value = visit(tree)
    return value, Counter(leaves)


def grade(case, response, error="", truncated=False):
    final = final_text(response)
    if error:
        return False, "Request error", final
    if not final:
        return False, "No visible final answer" + ("; token limit reached" if truncated else ""), final
    if case["kind"] == "expression24":
        candidates = [part.strip().rstrip(".") for part in final.splitlines()[0].split("=")]
        parsed = False
        for candidate in candidates:
            try:
                value, leaves = evaluate_expression(candidate)
                parsed = True
                if value == 24 and leaves == Counter([3, 3, 8, 8]):
                    return True, "Exact rational evaluation and number usage verified", final
            except (ValueError, SyntaxError, ZeroDivisionError):
                pass
        return (False if parsed else None), ("Expression does not make 24 with the required numbers" if parsed else "Manual review: expression could not be parsed"), final
    if case["kind"] == "fraction":
        cleaned = final.strip('`"$ *()').rstrip(".")
        cleaned = re.sub(r"\\(?:dfrac|tfrac|frac)\s*\{([+-]?\d+)\}\s*\{([+-]?\d+)\}", r"\1/\2", cleaned)
        cleaned = re.sub(r"\\boxed\s*\{([^{}]+)\}", r"\1", cleaned)
        cleaned = cleaned.replace(r"\(", "").replace(r"\)", "").strip("$ ()")
        match = re.match(r"^([+-]?\d+)\s*/\s*(\d+)(?:\b|$)", cleaned)
        try:
            if match:
                value = Fraction(int(match[1]), int(match[2]))
                correct = value == Fraction(case["answer"])
            else:
                value, _ = json.JSONDecoder().raw_decode(cleaned)
                correct = math.isclose(float(Fraction(str(value))), float(Fraction(case["answer"])), rel_tol=0, abs_tol=1e-9)
            return correct, "Compared numerical probability to exact reference", final
        except (ValueError, TypeError, ZeroDivisionError):
            return None, "Manual review: probability could not be parsed", final
    try:
        value, _ = json.JSONDecoder().raw_decode(final)
    except ValueError:
        if case["kind"] == "integer":
            match = re.match(r"^(?:x\s*=\s*)?([+-]?\d+)(?:\b|$)", final)
            if match:
                value = int(match[1])
            else:
                return None, "Manual review: integer could not be parsed", final
        elif case["kind"] == "names" and re.fullmatch(r"[ABC](?:\s*,\s*[ABC])*", final):
            value = re.findall(r"[ABC]", final)
        else:
            return None, "Manual review: final answer could not be parsed", final
    if case["kind"] == "integer":
        return type(value) in (int, float) and value == case["answer"], "Compared to exact integer reference", final
    if case["kind"] == "names":
        if isinstance(value, str): value = [value]
        return isinstance(value, list) and sorted(value) == sorted(case["answer"]), "Compared truth-teller set", final
    if case["kind"] == "json_subset":
        correct = isinstance(value, dict) and all(value.get(k) == v for k, v in case["answer"].items())
        return correct, "Compared algorithm result, shortest distance and path", final
    return value == case["answer"], "Compared reference program output", final


def normalize_metrics(result):
    usage = result.get("usage", {})
    total_input = usage.get("prompt_tokens")
    cached = (usage.get("prompt_tokens_details") or {}).get("cached_tokens", 0)
    computed = max(0, total_input - cached) if total_input is not None else None
    return {
        "input_tokens": total_input,
        "cached_input_tokens": cached,
        "computed_input_tokens": computed,
        "input_tps": usage.get("prompt_tokens_per_second"),
        "output_tokens": usage.get("completion_tokens"),
        "reasoning_tokens": (usage.get("completion_tokens_details") or {}).get("reasoning_tokens", 0),
        "output_tps": result.get("decode_tps"),
        "input_eval_s": usage.get("prompt_eval_duration"),
        "output_eval_s": usage.get("generation_duration"),
        "e2e_s": result.get("wall_s"),
        "first_visible_s": result.get("visible_ttft_s"),
        "server_ttft_s": usage.get("time_to_first_token"),
        "truncated": result.get("finish_reason") == "length",
    }


def resource_collision(error, model, inventory):
    return ("HTTP 507 /v1/chat/completions:" in str(error)
            and any((m.get("loaded") or m.get("is_loading")) and m["id"] != model for m in inventory))


def native_template_kwargs(model_info, mode):
    """Map common thinking settings to the installed checkpoint's template."""
    options = {"enable_thinking": mode == "on"}
    model_path = model_info.get("model_path")
    config_path = Path(model_path) / "config.json" if model_path else None
    config = json.loads(config_path.read_text()) if config_path and config_path.exists() else {}
    if config.get("model_type") == "muse_glimmer":
        options["reasoning_strength"] = "medium" if mode == "on" else "low"
    return options


def complete(client, model, question, mode, seed, max_tokens=1536, thinking_budget=1024, system=SYSTEM, payload_overrides=None):
    for attempt in range(3):
        try:
            foreign_present = any((m.get("loaded") or m.get("is_loading")) and m["id"] != model for m in client.models())
            wait_idle(client, stable_seconds=30 if attempt or foreign_present else 0)
            for other in client.models():
                if other.get("loaded") and other.get("model_type") in {"llm", "vlm"} and other["id"] != model:
                    unload_one_model(client, other["id"])
            own = next(m for m in client.models() if m["id"] == model)
            if not own.get("loaded"):
                tick = time.perf_counter(); client.json(model_url(model, "load"), {}, timeout=600)
                record_isolation_event({"event": "reload_after_external_traffic", "model": model, "load_seconds": time.perf_counter() - tick})
        except RuntimeError as exc:
            raise BenchmarkPaused(str(exc)) from exc
        trial_system = system
        if attempt and system.startswith("Request identifier "):
            trial_system = "Request identifier " + uuid.uuid4().hex + ". Follow the output instruction."
        template_options = native_template_kwargs(own, mode)
        payload = {"model": model, "messages": [{"role": "system", "content": trial_system}, {"role": "user", "content": question}], "temperature": 0.6, "top_p": 0.95, "top_k": 20, "max_tokens": max_tokens, "chat_template_kwargs": template_options, "stream": True, "stream_options": {"include_usage": True}}
        if seed is not None: payload["seed"] = seed
        if mode == "on": payload.update(reasoning_effort="medium", thinking_budget=thinking_budget)
        elif "reasoning_strength" in template_options:
            # Muse exposes low/medium/high/xhigh, without an off level. The
            # native parser supports a zero budget and a forced user channel.
            payload["thinking_budget"] = 0
        if payload_overrides: payload.update(payload_overrides)
        stop, conflict = threading.Event(), threading.Event()
        conflict_details = {}
        def watch_memory_isolation():
            overlap_samples = 0
            while not stop.wait(1.0):
                try:
                    count = client.json("/health", timeout=5).get("engine_pool", {}).get("loaded_count", 1)
                    activity = client.json("/admin/api/activity", timeout=5).get("active_models", {})
                    requests = activity.get("total_active_requests", 0) + activity.get("total_waiting_requests", 0)
                    overlap_samples = overlap_samples + 1 if requests > 1 else 0
                    foreign = [m for m in activity.get("models", []) if m.get("id") != model]
                    if count > 1 or foreign or overlap_samples >= 2:
                        conflict_details.update(loaded_count=count, active_requests=activity.get("total_active_requests", 0), waiting_requests=activity.get("total_waiting_requests", 0), models=[{"id": m.get("id"), "active_requests": m.get("active_requests"), "waiting_requests": m.get("waiting_requests")} for m in activity.get("models", [])])
                        conflict.set(); return
                except Exception:
                    pass
        watcher = threading.Thread(target=watch_memory_isolation, daemon=True)
        watcher.start()
        result = None
        try:
            start = time.perf_counter()
            with client.request("/v1/chat/completions", payload, timeout=600) as response:
                def lines():
                    for line in response:
                        if conflict.is_set(): raise IsolationConflict("Possible concurrent model or request activity during inference")
                        yield line
                result = read_stream(lines(), start)
            others = [m["id"] for m in client.models() if m.get("loaded") and m.get("model_type") in {"llm", "vlm"} and m["id"] != model]
            if conflict.is_set() or others: raise IsolationConflict("Another model overlapped this inference: " + str(others))
            return result
        except (IsolationConflict, RuntimeError) as exc:
            if not isinstance(exc, IsolationConflict):
                inventory = client.models()
                if not resource_collision(exc, model, inventory): raise
                conflict_details.update(resource_collision=True, foreign_models=[m["id"] for m in inventory if (m.get("loaded") or m.get("is_loading")) and m["id"] != model])
            record_isolation_event({"event": "discarded_overlapping_request", "model": model, "question": question, "mode": mode, "seed": seed, "reason": str(exc), "completed_result": result, "activity": conflict_details})
            print("ISOLATION WAIT: " + str(exc) + "; preserving the attempt separately and waiting for other traffic.", flush=True)
        finally:
            stop.set(); watcher.join(timeout=6)
        unload_one_model(client, model)
    raise BenchmarkPaused("Repeated external inference is preventing an isolated benchmark. Pause other clients and resume.")


def speed_document():
    words = "amber copper river meadow cedar silver harbor valley lantern orchard quiet north".split()
    lines = [f"Record {n:03d}: " + " ".join(words[n % len(words):] + words[:n % len(words)]) + "." for n in range(1, 121)]
    return "Read the following reference document.\n\n" + "\n".join(lines) + "\n\nNow output the integers from 1 through 200 in order, separated by commas. Output only the numbers."


def weighted_tps(rows, tokens, seconds):
    good = [r for r in rows if not r.get("error") and r.get(tokens) is not None and r.get(seconds) and r[seconds] > 0]
    return sum(r[tokens] for r in good) / sum(r[seconds] for r in good) if good else None


def summary_rows(rows, manifest):
    output = []
    for model in manifest["models"]:
        probes = [r for r in rows if r["model"] == model["id"] and r["kind"] == "speed_probe"]
        for mode in manifest["modes"]:
            selected = [r for r in rows if r["model"] == model["id"] and r["kind"] == "question" and r["mode"] == mode]
            times = [r["e2e_s"] for r in selected if r.get("e2e_s") is not None]
            output.append({"model": model["id"], "thinking": mode, "correct": sum(r.get("correct") is True for r in selected), "questions_attempted": len(selected), "manual_review": sum(r.get("correct") is None for r in selected), "request_errors": sum(bool(r.get("error")) for r in selected), "truncated_answers": sum(bool(r.get("truncated")) for r in selected), "input_probe_tps": weighted_tps(probes, "computed_input_tokens", "input_eval_s"), "output_probe_tps": weighted_tps(probes, "output_tokens", "output_eval_s"), "question_input_tps": weighted_tps(selected, "computed_input_tokens", "input_eval_s"), "question_output_tps": weighted_tps(selected, "output_tokens", "output_eval_s"), "median_question_e2e_s": statistics.median(times) if times else None, "total_question_e2e_s": sum(times), "model_load_s": manifest.get("load_seconds", {}).get(model["id"]), "model_suite_wall_s": manifest.get("suite_seconds", {}).get(model["id"])})
    for row in output:
        row["mean_question_e2e_s"] = row["total_question_e2e_s"] / row["questions_attempted"] if row["questions_attempted"] else None
    return output


def write_outputs(directory, rows, manifest, cases):
    summaries = summary_rows(rows, manifest)
    (directory / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
    (directory / "summary.json").write_text(json.dumps(summaries, indent=2) + "\n")
    with (directory / "raw-results.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS, extrasaction="ignore"); writer.writeheader(); writer.writerows(rows)
    with (directory / "summary.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(summaries[0]) if summaries else ["model"]); writer.writeheader(); writer.writerows(summaries)
    def fmt(n): return f"{n:.2f}" if n is not None else "pending"
    lines = ["# Reasoning and speed benchmark", "", f"{len(cases)} verified-answer questions, {manifest['repeats']} repetitions per question, thinking mode(s): {', '.join(manifest['modes'])}. One model is loaded at a time and requests run sequentially. Temperature 0.6, top_p 0.95, top_k 20, best-effort matched seeds. Thinking-on requests use medium effort, a {manifest['thinking_budget']}-token thinking budget and a {manifest['max_tokens']}-token total output limit. Limit failures are recorded; this is a budgeted custom suite, not a standard leaderboard.", "", "Input-probe tok/s counts newly computed tokens in three fresh-prefix reference-document requests per model. Output-probe tok/s measures 256-token, non-thinking generations. Question output tok/s includes hidden reasoning and visible answer tokens. Rates are token-weighted. E2E is client-measured full request time with the model already loaded. Cold API load time and complete per-model suite wall time are separate columns in summary.csv. Background applications remain running.", "", "| Model | Thinking | Correct | Review | Input probe tok/s | Question output tok/s | Median question E2E s | Load s |", "|---|---|---:|---:|---:|---:|---:|---:|"]
    for s in summaries:
        lines.append(f"| {s['model']} | {s['thinking']} | {s['correct']}/{s['questions_attempted']} | {s['manual_review']} | {fmt(s['input_probe_tps'])} | {fmt(s['question_output_tps'])} | {fmt(s['median_question_e2e_s'])} | {fmt(s['model_load_s'])} |")
    for mode in manifest["modes"]:
        names = [m["id"] for m in manifest["models"]]
        lines += ["", f"## Per-question correctness, thinking {mode}", "", "| Question | " + " | ".join(names) + " |", "|---|" + "---:|" * len(names)]
        for case in cases:
            cells = []
            for model in names:
                group = [r for r in rows if r["kind"] == "question" and r["model"] == model and r["mode"] == mode and r["case_id"] == case["id"]]
                cells.append(f"{sum(r.get('correct') is True for r in group)}/{len(group)}")
            lines.append("| " + case["id"] + " | " + " | ".join(cells) + " |")
    lines += ["", "## Questions and answer keys", ""]
    for case in cases:
        lines += [f"### {case['id']} ({case['category']})", "", case["prompt"], "", "Reference answer: `" + json.dumps(case["answer"], ensure_ascii=False) + "`", "", case["verification"], ""]
    if manifest.get("model_errors"):
        lines += ["## Model errors", "", json.dumps(manifest["model_errors"], indent=2), ""]
    if manifest.get("suite_wall_notes"):
        lines += ["## Runtime notes", "", json.dumps(manifest["suite_wall_notes"], indent=2), ""]
    lines += ["## Raw results", "", "Full prompts, visible replies, reasoning, correctness and per-request timing/usage are in raw-results.csv and raw-results.jsonl. Human-readable replies are in raw-answers.md. Speed probes intentionally run to their 256-token cap and are not correctness-scored.", ""]
    (directory / "report.md").write_text("\n".join(lines))
    raw = ["# Raw question answers", ""]
    for row in rows:
        if row["kind"] != "question": continue
        raw += [f"## {row['model']} / {row['case_id']} / thinking {row['mode']} / run {row['repetition']}", "", f"Correct: {row.get('correct')}; {row.get('grading_note')}; E2E {fmt(row.get('e2e_s'))} s; input {fmt(row.get('input_tps'))} tok/s; output {fmt(row.get('output_tps'))} tok/s; finish={row.get('finish_reason')}; error={row.get('error') or 'none'}.", "", "Prompt:", "", row["question"], "", "Visible answer:", "", "````text", row.get("response", ""), "````", "", "Reasoning:", "", "````text", row.get("reasoning", ""), "````", ""]
    (directory / "raw-answers.md").write_text("\n".join(raw))


def wait_idle(client, timeout=300, stable_seconds=0):
    deadline = time.monotonic() + timeout
    last_notice = 0
    idle_since = None
    while time.monotonic() < deadline:
        state = client.json("/admin/api/activity")["active_models"]
        loading = any(m.get("is_loading") for m in state.get("models", []))
        if not state.get("total_active_requests") and not state.get("total_waiting_requests") and not loading:
            if idle_since is None: idle_since = time.monotonic()
            if time.monotonic() - idle_since >= stable_seconds: return
        else:
            idle_since = None
        if time.monotonic() - last_notice >= 5:
            print("Waiting for other inference requests to finish...", flush=True); last_notice = time.monotonic()
        time.sleep(0.25)
    raise BenchmarkPaused("Other inference requests have not become idle; no models were forcibly unloaded. Resume after other clients finish.")


def unload_one_model(client, name, timeout=300):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        own = next((m for m in client.models() if m["id"] == name), {})
        if own.get("is_loading"):
            time.sleep(0.25)
            continue
        if not own.get("loaded"): return
        activity = client.json("/admin/api/activity")["active_models"]
        own_activity = next((m for m in activity.get("models", []) if m.get("id") == name), {})
        if not own_activity.get("active_requests", 0) and not own_activity.get("waiting_requests", 0):
            client.json(model_url(name, "unload"), {})
            break
        time.sleep(0.25)
    else:
        raise BenchmarkPaused("The benchmark model is still in use by another client: " + name)
    deadline = time.monotonic() + 120
    while time.monotonic() < deadline:
        if not next((m for m in client.models() if m["id"] == name), {}).get("loaded"): return
        time.sleep(0.25)
    raise BenchmarkPaused("Model unload did not finish: " + name)


def unload_all_chat_models(client):
    present = any(m.get("loaded") or m.get("is_loading") for m in client.models())
    wait_idle(client, stable_seconds=30 if present else 0)
    for model in client.models():
        if model.get("loaded") and model.get("model_type") in {"llm", "vlm"}:
            client.json(model_url(model["id"], "unload"), {})
    deadline = time.monotonic() + 120
    while True:
        loaded = [m["id"] for m in client.models() if m.get("loaded") and m.get("model_type") in {"llm", "vlm"}]
        if not loaded: return
        if time.monotonic() >= deadline:
            raise RuntimeError("Model unload did not finish within 120 seconds: " + str(loaded))
        time.sleep(0.25)


def main():
    global ISOLATION_JOURNAL
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--thinking", choices=["on", "off", "both"], default="on")
    parser.add_argument("--thinking-budget", type=int, default=1024)
    parser.add_argument("--max-tokens", type=int, default=1536)
    parser.add_argument("--resume", type=Path)
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--only", nargs="+")
    args = parser.parse_args()
    if args.repeats < 1 or args.thinking_budget < 1 or args.max_tokens <= args.thinking_budget:
        parser.error("Use positive repeats/budget and a total token limit larger than the thinking budget")
    cases = json.loads((HERE / "reasoning_questions.json").read_text())
    local = json.loads((Path.home() / ".omlx/settings.json").read_text())
    key = local.get("auth", {}).get("api_key") or os.environ.get("OMLX_API_KEY", "")
    client = Client("http://127.0.0.1:8000", key)
    modes = ["off", "on"] if args.thinking == "both" else [args.thinking]
    if args.resume and args.output_dir: parser.error("Choose --resume or --output-dir")
    directory = args.resume or args.output_dir or HERE / ("reasoning-" + datetime.now().strftime("%Y%m%d-%H%M%S-%f"))
    ISOLATION_JOURNAL = directory / "isolation-events.jsonl"
    if args.resume:
        manifest = json.loads((directory / "manifest.json").read_text())
        assert manifest["modes"] == modes and manifest["thinking_budget"] == args.thinking_budget and manifest["max_tokens"] == args.max_tokens
        manifest["repeats"] = args.repeats
        rows = [json.loads(line) for line in (directory / "raw-results.jsonl").read_text().splitlines()]
    else:
        directory.mkdir()
        models = [m for m in client.models() if not helper_reason(m) and (not args.only or m["id"] in args.only)]
        manifest = {"created_at": datetime.now().isoformat(), "repeats": args.repeats, "modes": modes, "thinking_budget": args.thinking_budget, "max_tokens": args.max_tokens, "models": models, "load_seconds": {}, "suite_seconds": {}, "model_errors": {}}
        rows = []
        (directory / "questions.json").write_text(json.dumps(cases, indent=2) + "\n")
    done = {(r["model"], r["kind"], r["case_id"], r["mode"], r["repetition"]) for r in rows}
    def save(row):
        rows.append(row)
        with (directory / "raw-results.jsonl").open("a") as f: f.write(json.dumps(row, ensure_ascii=False) + "\n")
        write_outputs(directory, rows, manifest, cases)
    write_outputs(directory, rows, manifest, cases)
    print("RESULTS " + str(directory), flush=True)
    for original in manifest["models"]:
        name = original["id"]
        if args.only and name not in args.only:
            continue
        expected = [(name, "question", case["id"], mode, repeat) for mode in modes for repeat in range(1, args.repeats + 1) for case in cases]
        if all(key in done for key in expected): continue
        started = time.perf_counter()
        info = next(m for m in client.models() if m["id"] == name)
        original_force = bool(info.get("settings", {}).get("force_sampling", False))
        print("MODEL START " + name, flush=True)
        try:
            unload_all_chat_models(client)
            if original_force: client.json(model_url(name, "settings"), {"force_sampling": False}, method="PUT")
            tick = time.perf_counter(); client.json(model_url(name, "load"), {}, timeout=600)
            manifest["load_seconds"][name] = time.perf_counter() - tick
            tick = time.perf_counter()
            warm = complete(client, name, speed_document(), "off", 8999, max_tokens=16, system="Warmup identifier " + uuid.uuid4().hex + ". Follow the output instruction.")
            manifest.setdefault("prefill_warmup_seconds", {})[name] = time.perf_counter() - tick
            with (directory / "warmups.jsonl").open("a") as f:
                f.write(json.dumps({"model": name, "kind": "unmeasured_prefill_warmup", **warm}, ensure_ascii=False) + "\n")
            for repetition in range(1, 4):
                trial = (name, "speed_probe", "fixed_document", "off", repetition)
                if trial in done: continue
                question = speed_document(); system = "Request identifier " + uuid.uuid4().hex + ". Follow the output instruction."
                result = complete(client, name, question, "off", 9000 + repetition, max_tokens=256, system=system)
                row = {"model": name, "kind": "speed_probe", "case_id": "fixed_document", "mode": "off", "repetition": repetition, "question": question, "system_prompt": system, "seed": 9000 + repetition, "error": "", "correct": None, "grading_note": "Unscored speed probe", **result, **normalize_metrics(result)}
                save(row)
                print(f"{name} | speed probe {repetition}/3 | input={row['input_tps']} output={row['output_tps']} tok/s | E2E={row['e2e_s']:.2f}s", flush=True)
            for mode in modes:
                complete(client, name, "What is 1+1? Finish with FINAL: and the number.", mode, 123, max_tokens=128, thinking_budget=64)
                consecutive_errors = 0
                for repetition in range(1, args.repeats + 1):
                    for index, case in enumerate(cases):
                        trial = (name, "question", case["id"], mode, repetition)
                        if trial in done: continue
                        seed = 17000 + index * 100 + repetition
                        row = {"model": name, "kind": "question", "case_id": case["id"], "mode": mode, "repetition": repetition, "question": case["prompt"], "seed": seed, "error": "", "response": "", "reasoning": "", "finish_reason": None}
                        tick = time.perf_counter()
                        try:
                            result = complete(client, name, case["prompt"], mode, seed, args.max_tokens, args.thinking_budget)
                            row.update(result); row.update(normalize_metrics(result)); consecutive_errors = 0
                        except BenchmarkPaused:
                            raise
                        except Exception as exc:
                            row["error"] = str(exc); row["e2e_s"] = time.perf_counter() - tick; consecutive_errors += 1
                        row["correct"], row["grading_note"], row["final_answer"] = grade(case, row["response"], row["error"], row.get("truncated", False))
                        save(row)
                        print(f"{name} | thinking={mode} | {case['id']} | run {repetition}/{args.repeats} | correct={row['correct']} | E2E={row['e2e_s']:.2f}s | out={row.get('output_tps')} tok/s | finish={row['finish_reason']}", flush=True)
                        if consecutive_errors >= 3: raise RuntimeError("Three consecutive inference errors")
        except Exception as exc:
            manifest["model_errors"][name] = str(exc); print("MODEL ERROR " + name + ": " + str(exc), flush=True)
        finally:
            if original_force: client.json(model_url(name, "settings"), {"force_sampling": True}, method="PUT")
            unload_one_model(client, name)
            manifest["suite_seconds"][name] = time.perf_counter() - started
            write_outputs(directory, rows, manifest, cases)
        print("MODEL DONE " + name, flush=True)
    manifest["last_run_finished_at"] = datetime.now().isoformat()
    if sum(r["kind"] == "question" for r in rows) == len(manifest["models"]) * len(cases) * len(modes) * args.repeats:
        manifest["finished_at"] = datetime.now().isoformat()
    write_outputs(directory, rows, manifest, cases)
    print("COMPLETE " + str(directory / "report.md"), flush=True)


if __name__ == "__main__":
    main()
