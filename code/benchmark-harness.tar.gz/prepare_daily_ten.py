#!/usr/bin/env python3
"""Prepare frozen inputs and exercise real read-only controls before inference."""
import argparse
import csv
import hashlib
import json
import os
import re
import shutil
import subprocess
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

import daily_ten_tasks as tasks
from daily_readonly_broker import Broker
from daily_readonly_preflight import run as boundary_preflight
from daily_readonly_sandbox import host_read_paths, profile
from daily_readonly_sources import load_source, redact
from qwen38_mtp_benchmark import Client

HERE = Path(__file__).resolve().parent
BASELINE = HERE/'daily-readonly-20261026-123002'


def save(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False)+'\n')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def controls(root, key, client):
    checks = []
    def check(name, passed, detail=None):
        checks.append({'name': name, 'passed': bool(passed), 'detail': detail})
    local, _ = tasks.local_inventory('mac_backup_budget')
    expected = tasks.backup_answer(local)
    # Independent bit-mask optimizer checks the combinations-based oracle.
    best = None
    for mask in range(1 << len(local)):
        selected = [r for i, r in enumerate(local) if mask & (1 << i)]
        size = sum(r['size_bytes'] for r in selected)
        if size <= expected['budget_bytes']:
            score = (-size, len(selected), sorted(r['path'] for r in selected))
            if best is None or score < best:
                best = score
    check('independent exact backup optimizer agrees', expected['chosen_bytes'] == -best[0] and expected['chosen_paths'] == best[2])
    tie = tasks.backup_answer([{'path': '/a', 'size_bytes': 10*1024*1024}, {'path': '/b', 'size_bytes': 10*1024*1024}, {'path': '/z', 'size_bytes': 20*1024*1024}])
    check('backup ties prefer fewer files', tie['chosen_paths'] == ['/z'])
    lex = tasks.backup_answer([{'path': '/a', 'size_bytes': 10*1024*1024}, {'path': '/b', 'size_bytes': 10*1024*1024}, {'path': '/c', 'size_bytes': 10*1024*1024}])
    check('backup cardinality ties prefer lexicographic paths', lex['chosen_paths'] == ['/a', '/b'])
    log_expected, log_csv = tasks.log_answer((root/'fixtures/frigate-debug-redacted.log').read_text())
    rg = subprocess.run(['/opt/homebrew/bin/rg', '-c', r'\] +\S+ +ERROR +:', str(root/'fixtures/frigate-debug-redacted.log')], capture_output=True, text=True, check=True)
    check('independent CLI ERROR count agrees', int(rg.stdout.strip()) == log_expected['level_counts']['ERROR'], {'rg_count': int(rg.stdout), 'parsed_lines': log_expected['parsed_lines']})
    window = json.loads((root/'scheduling-window.json').read_text())
    empty = tasks.availability_answer({'items': []}, window)
    check('empty Calendar gives five complete workdays', empty['total_free_minutes'] == 2400 and len(empty['days']) == 5)
    check('DST offsets differ across supplied dates', empty['days'][0]['free_intervals'][0]['start_utc'].endswith('16:00:00Z') and empty['days'][-1]['free_intervals'][0]['start_utc'].endswith('17:00:00Z'))
    fake = {'items': [
        {'id': 'all-day', 'start': {'date': window['work_dates'][0]}, 'end': {'date': window['work_dates'][1]}},
        {'id': 'cancelled', 'status': 'cancelled', 'start': {'date': window['work_dates'][1]}, 'end': {'date': window['work_dates'][2]}},
        {'id': 'touch-a', 'start': {'dateTime': window['work_dates'][1]+'T09:00:00-07:00'}, 'end': {'dateTime': window['work_dates'][1]+'T10:00:00-07:00'}},
        {'id': 'touch-b', 'start': {'dateTime': window['work_dates'][1]+'T10:00:00-07:00'}, 'end': {'dateTime': window['work_dates'][1]+'T11:00:00-07:00'}},
    ]}
    oracle = tasks.availability_answer(fake, window)
    check('all-day event blocks only its exclusive date range', oracle['days'][0]['free_minutes'] == 0 and oracle['days'][1]['free_minutes'] == 360)
    check('touching busy spans merge and cancelled event ignored', len(oracle['days'][1]['free_intervals']) == 1 and oracle['days'][1]['free_intervals'][0]['duration_minutes'] == 360)
    ha = json.loads((root/'preflight/ha-automations-redacted.json').read_text())
    frigate = json.loads((root/'preflight/frigate-config-redacted.json').read_text())
    cross = tasks.camera_answer(ha, frigate)
    synthetic = tasks.camera_answer([{'id': 'x', 'conditions': [{'entity_id': 'sensor.missing_person_count'}], 'actions': [{'action': 'light.turn_off', 'target': {'entity_id': 'light.x'}}]}], {'cameras': {}})
    check('unknown cross-source camera handled without defaults', synthetic['unknown_camera_names'] == ['missing'] and synthetic['automations'][0]['cameras'][0]['detect_enabled'] is None)
    values = {'mac_backup_budget': expected, 'home_camera_crosscheck': cross,
              'frigate_log_triage': log_expected,
              'gws_meeting_slots': tasks.availability_answer(json.loads((root/'preflight/gws-meeting-events.stdout').read_text()), window)}
    for task in tasks.NEW_TASKS:
        identifier = task['id']
        directory = root/'preflight/grader-controls'/identifier
        directory.mkdir(parents=True)
        work = directory/'work'
        immutable = tasks.setup(identifier, work, root)
        csv_data = (local if identifier == 'mac_backup_budget' else log_csv if identifier == 'frigate_log_triage' else None)
        csv_name = 'candidate_inventory.csv' if identifier == 'mac_backup_budget' else 'errors_by_component.csv'
        broker = Broker(root, key, client)
        broker.select(directory, 'control-no-inference')
        cli_commands = []
        if identifier == 'home_camera_crosscheck':
            cli_commands = [['home-read', 'ha', 'automations'], ['home-read', 'frigate', 'config']]
        elif identifier == 'gws_meeting_slots':
            params = {'calendarId': 'primary', 'timeMin': window['timeMin'], 'timeMax': window['timeMax'], 'singleEvents': True, 'orderBy': 'startTime', 'maxResults': 100, 'fields': 'items(id,start,end,status),nextPageToken,timeZone'}
            cli_commands = [['gws', 'calendar', 'events', 'list', '--params', json.dumps(params)]]
        code = 'import json,csv,subprocess\nfrom zoneinfo import ZoneInfo\nassert ZoneInfo("America/Los_Angeles")\n'
        for i, command in enumerate(cli_commands):
            code += f'r=subprocess.run({command!r},capture_output=True,text=True,check=True)\nopen("source-{i}.json","w").write(r.stdout)\n'
        code += f'answer=json.loads({json.dumps(values[identifier])!r})\nopen("answer.json","w").write(json.dumps(answer))\n'
        if csv_data is not None:
            code += f'rows=json.loads({json.dumps(csv_data)!r})\nf=open({csv_name!r},"w",newline="")\nw=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else ["path","size_bytes"])\nw.writeheader();w.writerows(rows);f.close()\n'
        script = tasks.SCRIPTS[identifier]
        (work/script).write_text(code)
        policy = directory/'policy.sb'
        policy.write_text(profile(work, root/'runtime', broker.port, readable=host_read_paths()))
        env = {**os.environ, 'PATH': str(root/'runtime/bin')+':/opt/homebrew/bin:/usr/bin:/bin',
               'DAILY_READ_TOKEN': broker.token, 'DAILY_BROKER_URL': 'http://127.0.0.1:'+str(broker.port), 'PYTHONDONTWRITEBYTECODE': '1'}
        try:
            proc = subprocess.run(['/usr/bin/sandbox-exec', '-f', str(policy), '/opt/homebrew/bin/python3', script], cwd=work, env=env, capture_output=True, text=True, timeout=180)
        finally:
            broker.close()
        (directory/'stdout.txt').write_text(proc.stdout)
        (directory/'stderr.txt').write_text(proc.stderr)
        check(identifier+': reference program and actual read commands run inside OS profile', proc.returncode == 0, proc.stderr[-500:])
        cli = [json.loads(x) for x in (directory/'cli-audit/calls.jsonl').read_text().splitlines()] if (directory/'cli-audit/calls.jsonl').exists() else []
        events = [{'type': 'tool_execution_start', 'toolName': 'bash', 'toolCallId': 'control', 'args': {'command': 'python3 '+script}},
                  {'type': 'tool_execution_end', 'toolName': 'bash', 'toolCallId': 'control', 'isError': proc.returncode != 0}]
        result = tasks.verify(identifier, work, immutable, cli, events, root, local)
        save(directory/'verification.json', result)
        check(identifier+': correct actual-source artifact passes', result['verified'], [c for c in result['checks'] if not c['passed']])
        no_exec = tasks.verify(identifier, work, immutable, cli, [], root, local)
        check(identifier+': answer without Python execution fails', not no_exec['verified'])
        answer_path = work/'answer.json'
        good = answer_path.read_bytes()
        answer_path.write_text('{}')
        bad = tasks.verify(identifier, work, immutable, cli, events, root, local)
        check(identifier+': empty/wrong result fails', not bad['verified'])
        answer_path.write_bytes(good)
    return {'checks': checks, 'passed': all(c['passed'] for c in checks), 'checks_passed': sum(c['passed'] for c in checks), 'checks_total': len(checks)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path)
    args = parser.parse_args()
    master = (args.root or HERE/('daily-ten-'+datetime.now().strftime('%Y%m%d-%H%M%S'))).resolve()
    master.mkdir(mode=0o700)
    key = json.loads((Path.home()/'.omlx/settings.json').read_text())['auth']['api_key']
    client = Client('http://127.0.0.1:8000', key)
    inventory = {m['id']: m for m in client.models()}
    baseline_manifest = json.loads((BASELINE/'manifest.json').read_text())
    manifest = {'created_at': datetime.now().astimezone().isoformat(), 'status': 'preparing', 'baseline_root': str(BASELINE),
                'models': [inventory[m['id']] for m in baseline_manifest['models']], 'tasks': tasks.TASKS,
                'collection': 'retain original60; add40; fresh repeat100; no valid outcome retries'}
    save(master/'manifest.json', manifest)
    save(HERE/'active-daily-ten-benchmark.json', {'root': str(master), 'status': 'preparing'})
    save(master/'baseline-integrity.json', [{'path': str(p), 'sha256': sha(p)} for p in [BASELINE/name for name in ['manifest.json', 'report.md', 'raw-results.jsonl', 'summary.json', 'all-models-summary.csv', 'final-audit.json', 'completion-audit.json', 'artifact-sha256.json']]])
    raw_log = (Path.home()/'Downloads/frigate-debug.log').read_text(errors='replace')
    safe_log = redact(raw_log)
    safe_log = re.sub(r'''(?i)(["']?(?:password|api[_-]?key|access[_-]?token|secret)["']?\s*[:=]\s*["']?)[^\s,"']+''', r'\1[REDACTED]', safe_log)
    zone = ZoneInfo('America/Los_Angeles')
    old_window = json.loads((BASELINE/'calendar-window.json').read_text())
    day = tasks.original.instant(old_window['timeMin']).astimezone(zone).date()+timedelta(days=1)
    dates = []
    while len(dates) < 5:
        if day.weekday() < 5:
            dates.append(day.isoformat())
        day += timedelta(days=1)
    start = datetime.fromisoformat(dates[0]+'T09:00:00').replace(tzinfo=zone)
    end = datetime.fromisoformat(dates[-1]+'T17:00:00').replace(tzinfo=zone)
    scheduling = {'timezone': 'America/Los_Angeles', 'work_dates': dates, 'work_start': '09:00', 'work_end': '17:00', 'meeting_minutes': 90,
                  'timeMin': tasks.original.utc(start), 'timeMax': tasks.original.utc(end)}
    for stage in ['added', 'repeat']:
        root = master/stage
        root.mkdir(mode=0o700)
        (root/'preflight').mkdir()
        (root/'runs').mkdir()
        (root/'fixtures').mkdir()
        (root/'fixtures/frigate-debug-redacted.log').write_text(safe_log)
        (root/'calendar-window.json').write_bytes((BASELINE/'calendar-window.json').read_bytes())
        save(root/'scheduling-window.json', scheduling)
        for name in ['gws-drive-about.stdout', 'gws-drive-largest-fixed.stdout', 'gws-upcoming-events.stdout']:
            shutil.copy2(BASELINE/'preflight'/name, root/'preflight'/name)
        for name in ['ha-automations', 'frigate-config']:
            save(root/'preflight'/(name+'-redacted.json'), load_source(name))
        params = {'calendarId': 'primary', 'timeMin': scheduling['timeMin'], 'timeMax': scheduling['timeMax'],
                  'singleEvents': True, 'orderBy': 'startTime', 'maxResults': 100,
                  'fields': 'items(id,start,end,status),nextPageToken,timeZone'}
        response = subprocess.run(['/opt/homebrew/bin/gws', 'calendar', 'events', 'list', '--params', json.dumps(params)], capture_output=True, text=True, timeout=120)
        (root/'preflight/gws-meeting-events.stdout').write_text(response.stdout)
        (root/'preflight/gws-meeting-events.stderr').write_text(response.stderr)
        if response.returncode:
            raise RuntimeError('Read-only Calendar preflight failed; inspect protected stderr artifact.')
        if json.loads(response.stdout).get('nextPageToken'):
            raise RuntimeError('Preflight reference needs pagination before collection.')
        result = boundary_preflight(root, key, client)
        if not result['passed']:
            raise RuntimeError('OS/broker preflight failed: '+json.dumps([c for c in result['checks'] if not c['passed']]))
        print('BOUNDARY '+stage+' '+str(result['checks_passed'])+'/'+str(result['checks_total']), flush=True)
    result = controls(master/'added', key, client)
    save(master/'grader-controls.json', result)
    save(master/'preparation.json', {'passed': result['passed'], 'checks_passed': result['checks_passed'], 'checks_total': result['checks_total'],
                                    'raw_log_source': str(Path.home()/'Downloads/frigate-debug.log'), 'raw_log_sha256': hashlib.sha256(raw_log.encode()).hexdigest(),
                                    'redacted_log_sha256': hashlib.sha256(safe_log.encode()).hexdigest(), 'log_lines': len(safe_log.splitlines()),
                                    'new_prompt_control_characters': {t['id']: sum(ord(c) < 32 and c not in '\n\t' for c in t['prompt']) for t in tasks.NEW_TASKS}})
    if not result['passed']:
        raise RuntimeError('Grader controls failed: '+json.dumps([c for c in result['checks'] if not c['passed']]))
    print('ROOT '+str(master), flush=True)
    print('CONTROLS '+str(result['checks_passed'])+'/'+str(result['checks_total']), flush=True)


if __name__ == '__main__':
    main()
