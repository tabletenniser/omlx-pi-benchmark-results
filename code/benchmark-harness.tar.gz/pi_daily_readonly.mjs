import fs from 'node:fs';
import path from 'node:path';

export default function(pi) {
  pi.on('tool_call', event => {
    if (!['write','edit'].includes(event.toolName) || !event.input.path) return;
    let target = path.resolve(event.input.path);
    let existing = target;
    while (!fs.existsSync(existing) && existing !== path.dirname(existing)) existing=path.dirname(existing);
    const resolved = path.join(fs.realpathSync(existing),path.relative(existing,target));
    const work=fs.realpathSync(process.cwd());
    if (resolved !== work && !resolved.startsWith(work+path.sep)) {
      return {block:true, reason:'Read-only daily benchmark: writes and edits are limited to this disposable task folder. User files and services must remain unchanged.'};
    }
  });
}
