"""Deterministic fixtures and execution-based checks for Pi's real tool loop."""
import ast
import csv
import hashlib
import io
import json
import random
import re
import subprocess
import sys
from collections import Counter
from fractions import Fraction
from pathlib import Path

TASKS = [
    {"id": "config_tools", "category": "read/edit/bash tool chain", "prompt": "Use the read tool to inspect config.json, then the edit tool to change retry.enabled to false and timeout_ms to 9100. Preserve every other value. Run `node check.cjs` with the bash tool and report its actual receipt. Do not edit check.cjs."},
    {"id": "shell_csv", "category": "CLI and structured data", "prompt": "Use the bash tool to inspect the CSV files under sales/. Aggregate only rows with status=paid and currency=USD. Sum amount_cents minus refund_cents by customer, keeping only customers with a positive total. Write result.json as an array of objects {customer, net_cents}, sorted descending by net_cents then ascending by customer. Use a real CSV parser: quoted commas and newlines are valid. Execute the calculation and report how many customers are in the result. You may use standard-library Python through bash. No dependencies or network."},
    {"id": "python_24", "category": "write and execute Python", "prompt": "Use the write tool to create solve24.py. It reads a JSON array of exactly four integers from stdin, and prints a JSON string containing an expression that equals 24 using each input number exactly once, or JSON null if impossible. Only binary + - * / and parentheses are allowed (no unary minus, concatenation, powers, factorials, or extra constants). Intermediate fractions and negative values are allowed; use exact rational arithmetic. Support repeated numbers and zeros. Use the bash tool to execute your script for [3,8,8,3], [1,1,1,1], and [1,3,4,6]. Explain the observed outputs briefly. Python standard library only."},
    {"id": "python_lru", "category": "read/edit/test Python", "prompt": "Read cache.py and test_cache.py with the read tool. Fix cache.py using the edit tool so LRUCache works: get returns -1 for missing keys and makes hits most recently used; put updates existing values and promotes them, evicts the least recently used item at capacity, and stores nothing at capacity zero. Run `python3 -m unittest -v test_cache.py` using bash and fix failures. Preserve the public API and test file. Standard library only."},
    {"id": "typescript_plan", "category": "write and execute TypeScript", "prompt": "Use the write tool to create plan.ts with genuine TypeScript type annotations. It reads one JSON object from stdin mapping task names to arrays of prerequisites. Include tasks mentioned only as prerequisites, and ignore duplicate prerequisite entries. Print a JSON array containing the lexicographically smallest valid topological ordering, choosing the alphabetically smallest currently available task at every step. For any cycle, print exactly {\"error\":\"cycle\"}. Support empty input. Use only Node built-ins, no dependencies. Node 26 can run TypeScript directly with `node plan.ts`. Use bash to execute at least one acyclic and one cyclic example and report the observed outputs."},
    {"id": "typescript_merge", "category": "read/edit/test TypeScript", "prompt": "Read intervals.ts and check.ts using the read tool. Fix mergeIntervals using the edit tool. It must numerically sort intervals, merge overlapping or touching intervals, preserve the greatest end when intervals are nested, and leave the input array and its inner arrays unchanged. Return independent arrays that do not share inner arrays with the input. Keep the exported TypeScript function signature. Run `node check.ts` with bash and fix failures. Preserve check.ts. Use Node built-ins only."},
]

CONFIG = {"retry": {"enabled": True, "attempts": 4}, "timeout_ms": 3500,
          "metadata": {"owner": "benchmark", "enabled": True}, "paths": ["one", "two"]}

CHECK_CJS = '''const fs = require('node:fs');
const assert = require('node:assert/strict');
const c=JSON.parse(fs.readFileSync('config.json','utf8'));
assert.equal(c.retry.enabled,false);assert.equal(c.timeout_ms,9100);
assert.equal(c.retry.attempts,4);assert.deepEqual(c.paths,['one','two']);
assert.deepEqual(c.metadata,{owner:'benchmark',enabled:true});
const receipt={ok:true,receipt:'@@NONCE@@'};
fs.writeFileSync('receipt.json',JSON.stringify(receipt));console.log(JSON.stringify(receipt));
'''

CACHE = '''from collections import OrderedDict

class LRUCache:
    def __init__(self, capacity):
        self.capacity = capacity
        self.data = OrderedDict()

    def get(self, key):
        return self.data.get(key, -1)

    def put(self, key, value):
        if len(self.data) >= self.capacity:
            self.data.popitem(last=False)
        self.data[key] = value
'''

CACHE_TEST = '''import unittest
from cache import LRUCache

class CacheTests(unittest.TestCase):
    def test_hit_promotes(self):
        c=LRUCache(2);c.put(1,1);c.put(2,2);self.assertEqual(c.get(1),1)
        c.put(3,3);self.assertEqual(c.get(2),-1);self.assertEqual(c.get(1),1)
    def test_update(self):
        c=LRUCache(2);c.put(1,1);c.put(2,2);c.put(2,9)
        self.assertEqual(c.get(1),1);self.assertEqual(c.get(2),9)
    def test_zero_capacity(self):
        c=LRUCache(0);c.put(1,1);self.assertEqual(c.get(1),-1)

if __name__ == '__main__': unittest.main()
'''

INTERVALS = '''export function mergeIntervals(intervals: number[][]): number[][] {
  if (intervals.length === 0) return [];
  intervals.sort();
  const merged: number[][] = [intervals[0]];
  for (const current of intervals.slice(1)) {
    const last = merged[merged.length - 1];
    if (current[0] < last[1]) last[1] = current[1];
    else merged.push(current);
  }
  return merged;
}
'''

TS_CHECK = '''import assert from 'node:assert/strict';
import {mergeIntervals} from './intervals.ts';
assert.deepEqual(mergeIntervals([[10,12],[2,3],[3,9]]),[[2,9],[10,12]]);
assert.deepEqual(mergeIntervals([[1,10],[2,3],[4,5]]),[[1,10]]);
const original = [[5,7],[1,6]];
const before = JSON.stringify(original);
assert.deepEqual(mergeIntervals(original),[[1,7]]);
assert.equal(JSON.stringify(original),before);
assert.deepEqual(mergeIntervals([]),[]);
console.log('all public interval tests passed');
'''

def setup_task(task_id, directory):
    directory.mkdir(parents=True)
    expected = {}
    immutable = []
    if task_id == 'config_tools':
        nonce=hashlib.sha256(str(directory).encode()).hexdigest()[:16]
        (directory/'config.json').write_text(json.dumps(CONFIG,indent=2)+'\n')
        (directory/'check.cjs').write_text(CHECK_CJS.replace('@@NONCE@@',nonce))
        immutable=['check.cjs']; expected={'ok':True,'receipt':nonce}
    elif task_id == 'shell_csv':
        (directory/'sales').mkdir()
        rows=[['Alice',1250,0,'paid','USD'],['Bob, Jr',700,50,'paid','USD'],
              ['Alice',500,200,'paid','USD'],['pending',9000,0,'pending','USD'],
              ['Bob, Jr',100,0,'paid','USD'],['Euro',9000,0,'paid','EUR'],
              ['Carol',800,50,'paid','USD'],['refund',200,300,'paid','USD'],
              ['Line\nBreak',99,0,'paid','USD'],['Zero',600,600,'paid','USD'],
              ['Alice',1000,0,'cancelled','USD'],['Carol',10,10,'paid','USD']]
        random.Random(18031).shuffle(rows)
        for part,items in enumerate([rows[:6],rows[6:]],1):
            f=directory/'sales'/f'part {part}.csv'
            with f.open('w',newline='') as stream:
                w=csv.writer(stream);w.writerow(['customer','amount_cents','refund_cents','status','currency']);w.writerows(items)
            immutable.append(str(f.relative_to(directory)))
        totals=Counter()
        for customer,amount,refund,status,currency in rows:
            if status=='paid' and currency=='USD':totals[customer]+=amount-refund
        expected=[{'customer':c,'net_cents':n}for c,n in sorted(totals.items(),key=lambda v:(-v[1],v[0]))if n>0]
    elif task_id == 'python_lru':
        (directory/'cache.py').write_text(CACHE);(directory/'test_cache.py').write_text(CACHE_TEST)
        immutable=['test_cache.py']
    elif task_id == 'typescript_merge':
        (directory/'intervals.ts').write_text(INTERVALS);(directory/'check.ts').write_text(TS_CHECK)
        immutable=['check.ts']
    return {'expected':expected,'immutable':{n:hashlib.sha256((directory/n).read_bytes()).hexdigest()for n in immutable}}

def run_program(args, directory, input_value=None, timeout=10):
    try:
        r=subprocess.run(args,cwd=directory,input=json.dumps(input_value) if input_value is not None else None,
                         text=True,capture_output=True,timeout=timeout)
        return {'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
    except subprocess.TimeoutExpired:
        return {'exit_code':None,'stdout':'','stderr':'Verification timed out'}

def expression_value(expression, numbers):
    if not isinstance(expression,str) or len(expression)>1000:raise ValueError('Not a bounded expression string')
    root=ast.parse(expression,mode='eval');leaves=[]
    if sum(1 for _ in ast.walk(root))>64:raise ValueError('Expression too large')
    def visit(n):
        if isinstance(n,ast.Expression):return visit(n.body)
        if isinstance(n,ast.Constant) and type(n.value)is int:
            leaves.append(n.value);return Fraction(n.value)
        if isinstance(n,ast.BinOp) and isinstance(n.op,(ast.Add,ast.Sub,ast.Mult,ast.Div)):
            a,b=visit(n.left),visit(n.right)
            if isinstance(n.op,ast.Add):return a+b
            if isinstance(n.op,ast.Sub):return a-b
            if isinstance(n.op,ast.Mult):return a*b
            return a/b
        raise ValueError('Forbidden expression syntax')
    result=visit(root)
    return result==24 and Counter(leaves)==Counter(numbers)

def possible24(numbers):
    values=tuple(Fraction(n)for n in numbers)
    def search(v):
        if len(v)==1:return v[0]==24
        for i in range(len(v)):
            for j in range(i+1,len(v)):
                a,b=v[i],v[j];rest=tuple(x for k,x in enumerate(v)if k not in (i,j))
                choices={a+b,a-b,b-a,a*b}
                if b:choices.add(a/b)
                if a:choices.add(b/a)
                if any(search(rest+(x,))for x in choices):return True
        return False
    return search(values)

def reference_order(graph):
    pending={name:set(deps)for name,deps in graph.items()}
    for name in set().union(set(graph),*(set(v)for v in graph.values())):pending.setdefault(name,set())
    output=[]
    while pending:
        available=sorted(name for name,deps in pending.items()if not deps)
        if not available:return {'error':'cycle'}
        item=available[0];output.append(item);del pending[item]
        for deps in pending.values():deps.discard(item)
    return output

def verify_task(task_id, directory, setup, events):
    checks=[];runs=[]
    def check(name, passed, detail=''):
        checks.append({'name':name,'passed':bool(passed),'detail':str(detail)})
    calls=[e for e in events if e.get('type')=='tool_execution_start']
    names=[e.get('toolName')for e in calls]
    successful={e.get('toolCallId')for e in events if e.get('type')=='tool_execution_end'and not e.get('isError')}
    check('a real tool call executed successfully',any(e.get('toolCallId')in successful for e in calls))
    needed={'config_tools':['read','edit','bash'],'shell_csv':['bash'],'python_24':['write','bash'],
            'python_lru':['read','edit','bash'],'typescript_plan':['write','bash'],'typescript_merge':['read','edit','bash']}[task_id]
    check('requested native tool types used',all(n in names for n in needed),names)
    for filename,sha in setup['immutable'].items():
        f=directory/filename
        check('fixture preserved: '+filename,f.exists()and hashlib.sha256(f.read_bytes()).hexdigest()==sha)
    commands=[str(e.get('args',{}).get('command',''))for e in calls if e.get('toolName')=='bash'and e.get('toolCallId')in successful]
    if task_id in ('python_24','python_lru','typescript_plan','typescript_merge'):
        required={'python_24':r'python(?:3(?:\.\d+)?)?\b[^\n]*solve24\.py',
                  'python_lru':r'python(?:3(?:\.\d+)?)?\b[^\n]*(?:unittest|test_cache\.py)',
                  'typescript_plan':r'node\b[^\n]*plan\.ts',
                  'typescript_merge':r'node\b[^\n]*check\.ts'}[task_id]
        check('agent executed requested program/tests',any(re.search(required,c)for c in commands))
    if task_id in ('config_tools','shell_csv'):
        filename='receipt.json'if task_id=='config_tools'else'result.json'
        try:value=json.loads((directory/filename).read_text())
        except (OSError,ValueError):value=None
        check('correct output file',value==setup['expected'],value)
        if task_id=='config_tools':
            expected=json.loads(json.dumps(CONFIG));expected['retry']['enabled']=False;expected['timeout_ms']=9100
            try:actual=json.loads((directory/'config.json').read_text())
            except (OSError,ValueError):actual=None
            check('only requested config values changed',actual==expected,actual)
            check('agent ran the checker',any(re.search(r'node\b[^\n]*check\.cjs',c)for c in commands))
    elif task_id=='python_24':
        cases=[[3,8,8,3],[1,1,1,1],[1,3,4,6],[0,0,4,6],[1,5,5,5],[2,2,6,6],[4,4,4,4],[2,3,4,5],[1,1,1,2],[0,1,6,4]]
        for numbers in cases:
            r=run_program([sys.executable,'solve24.py'],directory,numbers);runs.append({'input':numbers,**r})
            try:
                answer=json.loads(r['stdout'])
                passed=(not possible24(numbers))if answer is None else expression_value(answer,numbers)
                passed=passed and r['exit_code']==0
            except (ValueError,TypeError,SyntaxError,ZeroDivisionError):passed=False
            check('24-game '+str(numbers),passed,r['stdout'][:300])
    elif task_id=='python_lru':
        r=run_program([sys.executable,'-m','unittest','-v','test_cache.py'],directory);runs.append(r)
        check('public Python tests pass',r['exit_code']==0,r['stderr'])
        code='''from cache import LRUCache
import json
cases=[]
for cap in [0,1,2,4]:
 c=LRUCache(cap);ref={};order=[];ok=True
 for i in range(120):
  key=(i*7)%9
  if i%3:
   c.put(key,i)
   if cap:
    if key in order:order.remove(key)
    ref[key]=i;order.append(key)
    if len(order)>cap:del ref[order.pop(0)]
  else:
   got=c.get(key);ok=ok and got==ref.get(key,-1)
   if key in ref:order.remove(key);order.append(key)
 cases.append(ok)
print(json.dumps(cases))
'''
        r=run_program([sys.executable,'-c',code],directory);runs.append(r)
        try:value=json.loads(r['stdout'])
        except ValueError:value=None
        check('hidden LRU sequence/zero/update/promotion tests',r['exit_code']==0 and value==[True]*4,r['stdout']+r['stderr'])
    elif task_id=='typescript_plan':
        f=directory/'plan.ts';source=f.read_text()if f.exists()else''
        check('TypeScript annotations present',bool(re.search(r'\b(?:type|interface)\s+\w+|:\s*(?:string|number|Record|Map|Set|Array)\b',source)))
        graphs=[{}, {'build':['lint','test'],'test':['compile'],'lint':[],'compile':[]},
                {'a':['b'],'b':['a']},{'z':['b','b'],'a':[]},{'x':['x']},
                {'e':['b'],'c':['a'],'d':[],'b':['a'],'a':[]},
                {'__proto__':[],'x':['__proto__']},{'a':['z'],'b':[]}]
        for graph in graphs:
            r=run_program(['node','plan.ts'],directory,graph);runs.append({'input':graph,**r})
            try:value=json.loads(r['stdout'])
            except ValueError:value=None
            check('dependency graph '+json.dumps(graph),r['exit_code']==0 and value==reference_order(graph),r['stdout']+r['stderr'])
    elif task_id=='typescript_merge':
        r=run_program(['node','check.ts'],directory);runs.append(r)
        check('public TypeScript tests pass',r['exit_code']==0,r['stdout']+r['stderr'])
        # Outside the agent's directory, and only supplied after it has finished.
        code='''import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const {mergeIntervals}=await import(pathToFileURL(process.argv[1]).href);
const cases=[[],[[1,2]],[[1,5],[2,3]],[[2,4],[4,6]],[[10,20],[1,2]],[[1,3],[1,2]],[[1,4],[2,3],[5,6]],[[4,4],[2,4],[4,8]],[[0,10],[1,2],[3,4],[8,12]]];
for(const xs of cases){
 const snap=JSON.stringify(xs);const sorted=xs.map(a=>[...a]).sort((a,b)=>a[0]-b[0]);const ref=[];
 for(const [a,b] of sorted){if(ref.length&&a<=ref.at(-1)[1])ref.at(-1)[1]=Math.max(ref.at(-1)[1],b);else ref.push([a,b]);}
 const got=mergeIntervals(xs);assert.deepEqual(got,ref);assert.equal(JSON.stringify(xs),snap);
 if(got.length){got[0][0]=999;assert.equal(JSON.stringify(xs),snap);}
}
console.log('hidden interval tests passed');
'''
        r=run_program(['node','--input-type=module','-e',code,str(directory/'intervals.ts')],directory);runs.append(r)
        check('hidden interval edge cases and output aliasing',r['exit_code']==0,r['stdout']+r['stderr'])
    return {'passed':all(c['passed']for c in checks),'checks_passed':sum(c['passed']for c in checks),
            'checks_total':len(checks),'checks':checks,'verification_runs':runs}
