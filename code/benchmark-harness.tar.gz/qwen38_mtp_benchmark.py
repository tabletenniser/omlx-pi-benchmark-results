#!/usr/bin/env python3
"""Download Jundot's model through oMLX and benchmark it against the existing 4-bit model.

Uses Python's standard library and the running oMLX server. Run from a normal
Terminal while Pi and other inference clients are idle. Credentials stay local.
"""

import argparse
import json
import os
import statistics
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime
from pathlib import Path

REPO = "Jundot/Qwen3.8-27B-oQ4e-mtp"
BASELINE = "Qwen3.8-27B-4bit"
CANDIDATE = "Qwen3.8-27B-oQ4e-mtp"
CASES = [
    ("greeting_original", "great me in exactly 9 words", 64, "nine_words"),
    ("greeting_corrected", "Greet me in exactly 9 words. Return only the greeting.", 64, "nine_words"),
    ("json", 'Return only a JSON object with exactly these values: {"ready": true, "count": 9}', 64, "json"),
    ("long_decode", "Write a complete Python implementation of a least recently used cache with get and put methods, followed by three example calls. Output only Python code.", 384, None),
]


def validate_response(text, check, finish_reason):
    if finish_reason == "length" and check:
        return False
    if check == "nine_words":
        return len(text.strip().split()) == 9
    if check == "json":
        try:
            value = json.loads(text)
            return isinstance(value, dict) and set(value) == {"ready", "count"} and value["ready"] is True and type(value["count"]) is int and value["count"] == 9
        except (ValueError, TypeError):
            return False
    return None


def read_stream(response, start, clock=time.perf_counter):
    content, reasoning, usage = [], [], {}
    first_visible, finish_reason, done = None, None, False
    for raw in response:
        line = raw.decode("utf-8").strip()
        if not line.startswith("data:"):
            continue
        data = line[5:].strip()
        if data == "[DONE]":
            done = True
            break
        event = json.loads(data)
        if event.get("error"):
            raise RuntimeError(str(event["error"]))
        if event.get("usage"):
            usage = event["usage"]
        for choice in event.get("choices", []):
            delta = choice.get("delta", {})
            if delta.get("content"):
                if first_visible is None:
                    first_visible = clock() - start
                content.append(delta["content"])
            if delta.get("reasoning_content"):
                reasoning.append(delta["reasoning_content"])
            finish_reason = choice.get("finish_reason") or finish_reason
    if not done or finish_reason is None:
        raise RuntimeError("Incomplete inference stream; refusing to report a partial benchmark.")
    seconds = clock() - start
    tokens = usage.get("completion_tokens")
    tps = usage.get("generation_tokens_per_second")
    duration = usage.get("generation_duration")
    if not tps and tokens and duration and duration > 0:
        tps = tokens / duration
    return {
        "response": "".join(content),
        "reasoning": "".join(reasoning),
        "visible_ttft_s": first_visible,
        "wall_s": seconds,
        "completion_tokens": tokens,
        "decode_tps": tps,
        "finish_reason": finish_reason,
        "usage": usage,
    }


class Client:
    def __init__(self, url, key):
        self.url = url.rstrip("/")
        self.key = key

    def request(self, path, data=None, method=None, timeout=120):
        headers = {"Accept": "application/json"}
        if self.key:
            headers["Authorization"] = "Bearer " + self.key
        body = None
        if data is not None:
            body = json.dumps(data).encode()
            headers["Content-Type"] = "application/json"
        req = urllib.request.Request(self.url + path, data=body, headers=headers, method=method)
        try:
            return urllib.request.urlopen(req, timeout=timeout)
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")[:1200]
            if self.key:
                detail = detail.replace(self.key, "[redacted]")
            raise RuntimeError(f"HTTP {exc.code} {path}: {detail}") from exc

    def json(self, path, data=None, method=None, timeout=120):
        with self.request(path, data, method, timeout) as response:
            return json.load(response)

    def models(self):
        return self.json("/admin/api/models")["models"]

    def complete(self, model, prompt, max_tokens):
        payload = {
            "model": model,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.7,
            "top_p": 0.8,
            "top_k": 20,
            "max_tokens": max_tokens,
            "chat_template_kwargs": {"enable_thinking": False},
            "stream": True,
            "stream_options": {"include_usage": True},
        }
        start = time.perf_counter()
        with self.request("/v1/chat/completions", payload, timeout=600) as response:
            return read_stream(response, start)


def model_url(model, suffix):
    return "/admin/api/models/" + urllib.parse.quote(model, safe="") + "/" + suffix


def install(client):
    # Use the server's downloader so Hugging Face cache settings and resumable
    # local-dir metadata work exactly as they do in the oMLX application.
    tasks = client.json("/admin/api/hf/tasks")["tasks"]
    task = next((t for t in tasks if t["repo_id"].lower() == REPO.lower() and t["status"] in {"pending", "downloading"}), None)
    if task is None:
        task = client.json("/admin/api/hf/download", {"repo_id": REPO})["task"]
    task_id = task["task_id"]
    print(f"Installing {REPO} (about 17 GB; existing files are reused).", flush=True)
    deadline = time.monotonic() + 4 * 3600
    while time.monotonic() < deadline:
        tasks = client.json("/admin/api/hf/tasks")["tasks"]
        task = next((t for t in tasks if t["task_id"] == task_id), None)
        if task is None:
            raise RuntimeError("The oMLX download task disappeared. Inspect Downloads in oMLX.")
        print(f"Download: {task['status']} {task.get('progress', 0):.1f}%  {task.get('downloaded_size', 0) / 1e9:.2f}/{task.get('total_size', 0) / 1e9:.2f} GB", flush=True)
        if task["status"] == "completed":
            break
        if task["status"] in {"failed", "cancelled"}:
            raise RuntimeError(f"Download {task['status']}: {task.get('error', '')}")
        time.sleep(10)
    else:
        raise RuntimeError("Timed out waiting for the download; it remains in oMLX's queue.")
    for _ in range(12):
        if any(m["id"] == CANDIDATE for m in client.models()):
            return
        time.sleep(2)
    # Inventory reload also unloads engines. Never request it automatically.
    raise RuntimeError("Download finished. Refresh the model inventory in oMLX while other clients are idle, then rerun this script with --skip-download.")


def summaries(rows):
    output = []
    for model in (BASELINE, CANDIDATE):
        for case, _, _, _ in CASES:
            group = [r for r in rows if r["model"] == model and r["case"] == case]
            if not group:
                continue
            def median(key):
                values = [r[key] for r in group if r[key] is not None]
                return statistics.median(values) if values else None
            checks = [r["passed"] for r in group if r["passed"] is not None]
            output.append({"model": model, "case": case, "runs": len(group), "median_wall_s": median("wall_s"), "median_visible_ttft_s": median("visible_ttft_s"), "median_decode_tps": median("decode_tps"), "passes": sum(checks), "checked_runs": len(checks)})
    return output


def write_report(directory, rows, metadata):
    summary = summaries(rows)
    (directory / "summary.json").write_text(json.dumps({"metadata": metadata, "summary": summary}, indent=2) + "\n")
    lines = ["# Qwen3.8-27B comparison", "", "Warm inference; thinking disabled; temperature 0.7, top_p 0.8, top_k 20. Model loading and warmup are excluded. Short prompts measure responsiveness and instruction following; the longer code prompt is the more useful decode-throughput comparison. Prefix caches are retained. Results do not measure image accuracy.", "", "| Model | Prompt | Median total seconds | Median first-visible-token seconds | Median decode tok/s | Passed |", "|---|---|---:|---:|---:|---:|"]
    def fmt(value):
        return f"{value:.2f}" if value is not None else "unavailable"
    for row in summary:
        passed = f"{row['passes']}/{row['checked_runs']}" if row["checked_runs"] else "n/a"
        lines.append(f"| {row['model']} | {row['case']} | {fmt(row['median_wall_s'])} | {fmt(row['median_visible_ttft_s'])} | {fmt(row['median_decode_tps'])} | {passed} |")
    lines += ["", "All responses and timing/usage fields are recorded in `runs.jsonl`. Nine-word checks count whitespace-separated words. Each round reverses model order; every model switch has an unmeasured warmup. These are sampled runs, not seeded deterministic comparisons.", ""]
    (directory / "report.md").write_text("\n".join(lines))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--url", default="http://127.0.0.1:8000")
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--skip-download", action="store_true")
    args = parser.parse_args()
    if args.repeats < 1:
        parser.error("--repeats must be positive")
    settings_file = Path.home() / ".omlx/settings.json"
    local = json.loads(settings_file.read_text()) if settings_file.exists() else {}
    key = local.get("auth", {}).get("api_key") or os.environ.get("OMLX_API_KEY", "")
    client = Client(args.url, key)
    models = client.models()  # Check connectivity and authentication before doing anything.
    if not any(m["id"] == BASELINE for m in models):
        raise RuntimeError(f"Baseline {BASELINE!r} was not found. Available models: {[m['id'] for m in models]}")
    print("Keep Pi and other inference clients idle during this benchmark.", flush=True)
    if not args.skip_download:
        install(client)
    models = client.models()
    by_id = {m["id"]: m for m in models}
    if CANDIDATE not in by_id:
        raise RuntimeError("Jundot's model is not in oMLX's model inventory.")
    candidate_path = Path(by_id[CANDIDATE]["model_path"])
    index = json.loads((candidate_path / "model.safetensors.index.json").read_text())
    weights = index["weight_map"]
    missing = [name for name in set(weights.values()) if not (candidate_path / name).is_file()]
    vision_count = sum("vision_tower" in name or "visual" in name for name in weights)
    mtp_count = sum("mtp" in name for name in weights)
    if missing or not vision_count or not mtp_count:
        raise RuntimeError(f"Incomplete vision/MTP checkpoint: missing={missing}, vision_tensors={vision_count}, mtp_tensors={mtp_count}")
    directory = Path(__file__).resolve().parent / ("results-" + datetime.now().strftime("%Y%m%d-%H%M%S-%f"))
    directory.mkdir()
    metadata = {"repo": REPO, "vision_tensors": vision_count, "mtp_tensors": mtp_count, "baseline_settings": by_id[BASELINE].get("settings", {}), "candidate_settings_before": by_id[CANDIDATE].get("settings", {}), "repeats": args.repeats}
    (directory / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
    # Only configure the newly installed candidate. Preserve the baseline and defaults.
    client.json(model_url(CANDIDATE, "settings"), {"mtp_enabled": True, "dflash_enabled": False, "vlm_mtp_enabled": False}, method="PUT")
    metadata["candidate_settings"] = next(m for m in client.models() if m["id"] == CANDIDATE).get("settings", {})
    if not metadata["candidate_settings"].get("mtp_enabled"):
        raise RuntimeError("The server did not enable the candidate's Lightning MTP.")
    rows, previous = [], None
    try:
        for repeat in range(args.repeats):
            order = [BASELINE, CANDIDATE] if repeat % 2 == 0 else [CANDIDATE, BASELINE]
            for model in order:
                if previous is not None and previous != model:
                    # Only these benchmark-owned models are unloaded. Other models are untouched.
                    previous_info = next((entry for entry in client.models() if entry["id"] == previous), {})
                    if previous_info.get("loaded"):
                        client.json(model_url(previous, "unload"), {}, timeout=120)
                if model != previous:
                    client.json(model_url(model, "load"), {}, timeout=600)
                    client.complete(model, "Reply with the single word ready.", 16)
                previous = model
                for name, prompt, limit, check in CASES:
                    result = client.complete(model, prompt, limit)
                    result.update(model=model, case=name, prompt=prompt, repeat=repeat + 1, passed=validate_response(result["response"], check, result["finish_reason"]))
                    rows.append(result)
                    with (directory / "runs.jsonl").open("a") as f:
                        f.write(json.dumps(result) + "\n")
                    rate = result["decode_tps"]
                    speed = f"{rate:.2f} tok/s" if rate else "tok/s unavailable"
                    print(f"{model} | {name} | run {repeat+1} | {result['wall_s']:.2f}s | {speed} | passed={result['passed']}", flush=True)
                    if check:
                        print("  " + repr(result["response"]), flush=True)
    finally:
        write_report(directory, rows, metadata)
        print("Results: " + str(directory / "report.md"), flush=True)
    print("Finished. Pi's default model and the baseline's settings were preserved.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped. A download already queued in oMLX continues independently.", file=sys.stderr)
        sys.exit(130)
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(1)
