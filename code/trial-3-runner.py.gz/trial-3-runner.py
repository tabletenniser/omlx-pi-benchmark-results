#!/usr/bin/env python3
"""Trial 3: the audited ten-question suite, sequential and resumable."""
import argparse
import fcntl
import hashlib
import json
import math
import os
import shutil
import subprocess
import threading
import time
from datetime import datetime
from pathlib import Path

import daily_ten_tasks as tasks
import pi_daily_readonly_benchmark as engine
import pi_daily_ten_benchmark as previous
import reasoning_benchmark as reasoning
from daily_readonly_broker import METHODS, SCHEMA_METHODS
from daily_readonly_preflight import run as boundary_preflight
from daily_readonly_sources import PATHS, load_source
from prepare_daily_ten import controls
from qwen38_mtp_benchmark import Client, model_url

HERE = Path(__file__).resolve().parent
PRIOR = HERE / 'daily-ten-20261026-200913'
engine.tasks = tasks


def save(path, value):
    previous.save(path, value)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def stamp():
    return datetime.now().astimezone().isoformat()


def summary(root):
    data = engine.rows(root / 'raw-results.jsonl')
    manifest = json.loads((root / 'manifest.json').read_text())
    result = []
    for model in manifest['models']:
        rows = [r for r in data if r['model'] == model['id']]
        result.append({'model': model['id'], **previous.stats(rows),
                       'total_e2e_s': sum(r['e2e_s'] for r in rows)})
    save(root / 'summary.json', result)
    save(root / 'progress.json', {'updated_at': stamp(), 'status': manifest['status'],
         'completed': len(data), 'planned': 100, 'worker_pid': os.getpid(),
         'current_model': manifest.get('current_model'), 'current_task': manifest.get('current_task')})


def google(root, filename, argv):
    proc = subprocess.run(['/opt/homebrew/bin/gws', *argv], capture_output=True,
                          text=True, timeout=120)
    (root / 'preflight' / (filename + '.stdout')).write_text(proc.stdout)
    (root / 'preflight' / (filename + '.stderr')).write_text(proc.stderr)
    if proc.returncode:
        raise RuntimeError(f'Read-only Google preflight failed: {filename}; see private stderr')
    data = json.loads(proc.stdout)
    if data.get('nextPageToken') and filename != 'gws-drive-largest-fixed':
        raise RuntimeError(f'Preflight reference needs pagination: {filename}')
    return data


def prepare(root, key, client):
    assert not (root / 'manifest.json').exists()
    root.mkdir(mode=0o700, parents=True, exist_ok=True)
    root.chmod(0o700)
    for name in ['preflight', 'runs', 'fixtures', 'source-snapshot']:
        (root / name).mkdir()
    old = json.loads((PRIOR / 'manifest.json').read_text())
    inventory = {m['id']: m for m in client.models()}
    assert tasks.TASKS == old['tasks'], 'Question definitions changed'
    models = [inventory[m['id']] for m in old['models']]
    save(root / 'manifest.json', {'created_at': stamp(), 'status': 'preparing', 'trial': 3,
         'prior_root': str(PRIOR), 'models': models, 'tasks': tasks.TASKS,
         'collection': '100 fresh cases; sequential; no outcome retries',
         'monitor_interval_seconds': 3600, 'worker_pid': os.getpid()})
    save(HERE / 'active-daily-third-benchmark.json', {'root': str(root), 'status': 'preparing'})
    baseline = [PRIOR / p for p in ['manifest.json', 'summary.json', 'completion-audit.json',
                'final-audit.json', 'repeat/raw-results.jsonl', 'added/raw-results.jsonl']]
    save(root / 'baseline-integrity.json', [{'path': str(p), 'sha256': sha(p)} for p in baseline])
    protected = [*PATHS.values(), Path.home() / '.pi/agent/models.json', Path.home() / '.pi/agent/settings.json']
    save(root / 'host-integrity-before.json', [{'path': str(p), 'sha256': sha(p)} for p in protected])
    for p in (PRIOR / 'source-snapshot-final').iterdir():
        if p.is_file() and (HERE / p.name).is_file():
            assert (HERE / p.name).read_bytes() == p.read_bytes(), p.name
            shutil.copy2(HERE / p.name, root / 'source-snapshot' / p.name)
    shutil.copy2(__file__, root / 'source-snapshot' / Path(__file__).name)
    for filename in ['calendar-window.json', 'scheduling-window.json', 'fixtures/frigate-debug-redacted.log']:
        shutil.copy2(PRIOR / 'repeat' / filename, root / filename)
    for name in ['ha-automations', 'frigate-config']:
        save(root / 'preflight' / (name + '-redacted.json'), load_source(name))
    google(root, 'gws-drive-about', ['drive', 'about', 'get', '--params', json.dumps({'fields': 'storageQuota'})])
    google(root, 'gws-drive-largest-fixed', ['drive', 'files', 'list', '--params', json.dumps({
        'q': "'me' in owners and trashed = false", 'pageSize': 5, 'orderBy': 'quotaBytesUsed desc',
        'fields': 'files(id,name,mimeType,size,quotaBytesUsed),nextPageToken'})])
    for filename, windowfile, fields in [
        ('gws-upcoming-events', 'calendar-window.json', 'items(id,summary,start,end,status),nextPageToken,timeZone'),
        ('gws-meeting-events', 'scheduling-window.json', 'items(id,start,end,status),nextPageToken,timeZone')]:
        window = json.loads((root / windowfile).read_text())
        google(root, filename, ['calendar', 'events', 'list', '--params', json.dumps({
            'calendarId': 'primary', 'timeMin': window['timeMin'], 'timeMax': window['timeMax'],
            'singleEvents': True, 'orderBy': 'startTime', 'maxResults': 100, 'fields': fields})])
    safety = boundary_preflight(root, key, client)
    assert safety['passed'], 'OS/broker preflight failed; no model execution'
    # The original controls predate sealed snapshots. Each deliberately changed
    # trusted canary needs a fresh snapshot; scored cases retain immutable seals.
    real_verify = tasks.verify
    def verify_control(task, work, *args, **kwargs):
        assert work.is_relative_to(root / 'preflight/grader-controls')
        metadata = work.parent / 'artifact-snapshot.json'
        if metadata.exists():
            metadata.rename(metadata.with_name(f'artifact-snapshot-control-{time.time_ns()}.json'))
        return real_verify(task, work, *args, **kwargs)
    try:
        tasks.verify = verify_control
        grading = controls(root, key, client)
    finally:
        tasks.verify = real_verify
    save(root / 'grader-controls.json', grading)
    assert grading['passed'], 'Grader controls failed; no model execution'
    save(root / 'preparation.json', {'passed': True, 'prepared_at': stamp(),
        'boundary_checks': safety['checks_passed'], 'grader_checks': grading['checks_passed'],
        'same_frozen_inputs': {p: sha(root / p) == sha(PRIOR / 'repeat' / p) for p in
          ['calendar-window.json', 'scheduling-window.json', 'fixtures/frigate-debug-redacted.log']}})
    print(f"PREFLIGHT PASS boundary={safety['checks_passed']}/{safety['checks_total']} grader={grading['checks_passed']}/{grading['checks_total']}", flush=True)


def audit(root):
    rows = engine.rows(root / 'raw-results.jsonl')
    manifest = json.loads((root / 'manifest.json').read_text())
    checks = []
    def check(name, passed):
        checks.append({'name': name, 'passed': bool(passed)})
    expected = {(m['id'], t['id']) for m in manifest['models'] for t in tasks.TASKS}
    check('100 unique required model/question cases', len(rows) == 100 and {(r['model'], r['task']) for r in rows} == expected)
    for filename in ['baseline-integrity.json', 'host-integrity-before.json']:
        check(filename + ' unchanged', all(sha(x['path']) == x['sha256'] for x in json.loads((root / filename).read_text())))
    for filename in ['safety-preflight.json', 'grader-controls.json', 'integration-probe.json']:
        check(filename + ' passed', json.loads((root / filename).read_text())['passed'])
    prior_rows = {(r['model'], r['task']): r for r in engine.rows(PRIOR / 'repeat/raw-results.jsonl')}
    intervals = []
    for r in rows:
        name = r['model'] + '/' + r['task']
        d = Path(r['directory'])
        cli = engine.rows(d / 'cli-audit/calls.jsonl')
        events = engine.rows(d / 'pi-events.jsonl')
        provider = engine.rows(d / 'provider-audit.jsonl')
        immutable = json.loads((d / 'setup.json').read_text())
        local = json.loads((d / 'local-reference-before.json').read_text()) if r['task'].startswith('mac_') else None
        replay = tasks.verify(r['task'], d / 'work', immutable, cli, events, root, local)
        check(name + ': saved evidence regrades identically', all(replay[k] == r[k] for k in ['verified', 'expected', 'answer', 'checks']))
        check(name + ': full score and counts', r['passed'] == (r['verified'] and not r['error']) and r['checks_passed'] == sum(c['passed'] for c in r['checks']))
        check(name + ': reference fingerprint', r['reference_hash'] == previous.digest(r['expected']))
        check(name + ': exact previous prompt and initial fixtures', (d / 'prompt.txt').read_bytes() == (Path(prior_rows[(r['model'], r['task'])]['directory']) / 'prompt.txt').read_bytes()
              and immutable == json.loads((Path(prior_rows[(r['model'], r['task'])]['directory']) / 'setup.json').read_text()))
        metrics = engine.pi.metrics_from_audit(provider, events)
        check(name + ': native metrics reproduce', all(math.isclose(r[k], v, rel_tol=1e-12) if isinstance(v, (int, float)) else r[k] == v for k, v in metrics.items()))
        requests = [p['payload'] for p in provider if p.get('event') == 'request']
        sampling = {'model': r['model'], 'temperature': .6, 'top_p': .95, 'top_k': 20,
                    'seed': 41001 + 100 * next(i for i, t in enumerate(tasks.TASKS) if t['id'] == r['task']),
                    'max_tokens': 4096, 'thinking_budget': 1024}
        check(name + ': identical sampling and request cap', 0 < len(requests) <= 12 and all(all(p.get(k) == v for k, v in sampling.items()) for p in requests))
        check(name + ': immutable source receipts', all(sha(c[k + '_file']) == c[k + '_sha256'] for c in cli for k in ['stdout', 'stderr']))
        command = json.loads((d / 'command.json').read_text())
        policy = (d / 'policy.sb').read_text()
        check(name + ': actual default-deny scratch-only sandbox', command[:2] == ['/usr/bin/sandbox-exec', '-f'] and command[2] == str(d / 'policy.sb') and '(deny default)' in policy
              and [x for x in policy.splitlines() if x.startswith('(allow file-write')] == ['(allow file-write* (subpath ' + json.dumps(str(d / 'work'), ensure_ascii=False) + ') (literal "/dev/null"))'])
        check(name + ': single loopback capability', len([x for x in policy.splitlines() if x.startswith('(allow network')]) == 1 and '(remote ip "localhost:' in policy)
        intervals.append((d.stat().st_birthtime, (d / 'verification.json').stat().st_birthtime))
    ordered = sorted(intervals)
    check('scored cases never overlap', all(a[1] <= b[0] for a, b in zip(ordered, ordered[1:])))
    calls = [c for p in root.rglob('calls.jsonl') for c in engine.rows(p)]
    mutations = [c for c in calls if c['service'] == 'gws' and c.get('dispatched') and c.get('kind') not in ['help', 'schema'] and tuple(c['argv'][:3]) not in METHODS]
    check('all attempts and controls: zero Google mutations', not mutations)
    check('all attempts and controls: denied requests never dispatched', all(not c.get('dispatched') for c in calls if c.get('policy_denied')))
    check('all attempts and controls: allowlisted schemas', all(c['argv'][1] in SCHEMA_METHODS for c in calls if c['service'] == 'gws' and c.get('dispatched') and c.get('kind') == 'schema'))
    result = {'audited_at': stamp(), 'passed': all(c['passed'] for c in checks), 'scored_trials': len(rows),
              'checks_passed': sum(c['passed'] for c in checks), 'checks_total': len(checks),
              'source_calls_all_attempts': len(calls), 'google_mutation_dispatches': len(mutations),
              'failed_checks': [c for c in checks if not c['passed']], 'checks': checks}
    save(root / 'final-audit.json', result)
    assert result['passed'], 'Final evidence audit failed; do not publish'
    return result


def hourly_monitor(root, stop):
    while not stop.wait(3600):
        manifest = json.loads((root / 'manifest.json').read_text())
        data = engine.rows(root / 'raw-results.jsonl')
        last = (root / 'raw-results.jsonl').stat().st_mtime if data else (root / 'manifest.json').stat().st_mtime
        record = {'checked_at': stamp(), 'completed': len(data), 'status': manifest['status'],
                  'current_model': manifest.get('current_model'), 'current_task': manifest.get('current_task'),
                  'seconds_since_last_result': time.time() - last, 'stalled': time.time() - last > 1800}
        with (root / 'hourly-monitor.jsonl').open('a') as out:
            out.write(json.dumps(record) + '\n')
        print('HOURLY ' + json.dumps(record), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', required=True, type=Path)
    parser.add_argument('--audit-only', action='store_true')
    args = parser.parse_args()
    root = args.root.resolve()
    if args.audit_only:
        audit(root)
        return
    lock = (HERE / 'daily-inference.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    key = json.loads((Path.home() / '.omlx/settings.json').read_text())['auth']['api_key']
    client = Client('http://127.0.0.1:8000', key)
    if not (root / 'manifest.json').exists():
        prepare(root, key, client)
    manifest = json.loads((root / 'manifest.json').read_text())
    assert json.loads((root / 'preparation.json').read_text())['passed']
    manifest.update(status='running', worker_pid=os.getpid(), resumed_at=stamp())
    save(root / 'manifest.json', manifest)
    stop = threading.Event()
    threading.Thread(target=hourly_monitor, args=(root, stop), daemon=True).start()
    try:
        if not (root / 'integration-probe.json').exists():
            info = manifest['models'][0]
            model = info['id']
            force = bool((info.get('settings') or {}).get('force_sampling', False))
            try:
                if force:
                    client.json(model_url(model, 'settings'), {'force_sampling': False}, method='PUT')
                previous.isolate(client, model)
                probe = {'id': 'integration_probe', 'category': 'infrastructure', 'prompt': 'Use bash to run printf "readonly-probe\\n". Then write probe.json containing exactly {"probe":"ok"}. Do not read user data. Keep the final reply brief.'}
                result = engine.run_task(client, key, info, probe, root, probe=True)
                save(root / 'integration-probe.json', result)
                assert result.get('passed'), 'Sandboxed Pi probe failed; no scored cases started'
            finally:
                if force:
                    client.json(model_url(model, 'settings'), {'force_sampling': True}, method='PUT')
                reasoning.unload_one_model(client, model)
            print('PI INTEGRATION PASS', flush=True)
        done = {(r['model'], r['task']) for r in engine.rows(root / 'raw-results.jsonl')}
        for definition in manifest['models']:
            model = definition['id']
            if all((model, task['id']) in done for task in tasks.TASKS):
                continue
            info = next(m for m in client.models() if m['id'] == model)
            force = bool((info.get('settings') or {}).get('force_sampling', False))
            manifest.update(current_model=model, current_task=None)
            save(root / 'manifest.json', manifest)
            print('MODEL START ' + model, flush=True)
            try:
                if force:
                    client.json(model_url(model, 'settings'), {'force_sampling': False}, method='PUT')
                previous.isolate(client, model)
                for task in tasks.TASKS:
                    if (model, task['id']) in done:
                        continue
                    manifest.update(current_task=task['id'], task_started_at=stamp())
                    save(root / 'manifest.json', manifest)
                    summary(root)
                    for attempt in range(3):
                        reasoning.wait_idle(client)
                        if attempt:
                            previous.isolate(client, model)
                        row = engine.run_task(client, key, info, task, root)
                        if not row.get('infrastructure'):
                            break
                        with (root / 'infrastructure-events.jsonl').open('a') as out:
                            out.write(json.dumps(row) + '\n')
                    else:
                        raise reasoning.BenchmarkPaused('Repeated external inference/source changes; valid outcomes retained')
                    row.update(stage='third', trial=3, reference_hash=previous.digest(row['expected']))
                    with (root / 'raw-results.jsonl').open('a') as out:
                        out.write(json.dumps(row, ensure_ascii=False) + '\n')
                        out.flush()
                        os.fsync(out.fileno())
                    done.add((model, task['id']))
                    summary(root)
                    print(f"TASK {len(done)}/100 | {model} | {task['id']} | full={row['passed']} verified={row['verified']} | {row['e2e_s']:.2f}s", flush=True)
            finally:
                if force:
                    client.json(model_url(model, 'settings'), {'force_sampling': True}, method='PUT')
                reasoning.unload_one_model(client, model)
            print('MODEL DONE ' + model, flush=True)
        result = audit(root)
        manifest.update(status='complete', finished_at=stamp(), current_task=None, current_model=None)
        save(root / 'manifest.json', manifest)
        save(HERE / 'active-daily-third-benchmark.json', {'root': str(root), 'status': 'complete', 'scored_trials': 100, 'audit_passed': result['passed']})
        print('FINISHED trial 3; 100/100; final audit PASS', flush=True)
    except BaseException as exc:
        manifest.update(status='interrupted', last_error=repr(exc), interrupted_at=stamp())
        save(root / 'manifest.json', manifest)
        raise
    finally:
        stop.set()
        summary(root)


if __name__ == '__main__':
    main()
